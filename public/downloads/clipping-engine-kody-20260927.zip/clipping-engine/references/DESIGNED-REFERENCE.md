# Kody designed layout reference

**Status:** art-direction concept for review, generated 2026-09-27 with the built-in image generation tool. It is not an approved brand look, a measured Figma revision, or footage ready for a clip.

Patrik accepted the broad direction and requested no faint caption underlines. `kody-designed-reference-v2-source.png` and its review/Instagram JPGs remove the short rule between the two caption lines. The earlier source remains archived for provenance; the mobile review page now shows v2.

## Outputs

| Role | 1080×1920 review image | Instagram check | Generation source |
|---|---|---|---|
| Main speaking frame | `kody-designed-reference-v2.jpg` | `kody-designed-reference-v2-instagram.jpg` | `kody-designed-reference-v2-source.png` |
| Ending | `kody-designed-end.jpg` | `kody-designed-end-instagram.jpg` | `kody-designed-end-source.png` |

Mobile comparison: `https://aheadofmarket.com/design-reviews/kody-figma-trial-20260927/designed-reference.html`.

## Direction to carry into an editable layout

- Retain the speaker/name → caption → supporting image → brand order. The main frame uses the current footage and desert photo as one continuous visual story instead of four unrelated rectangles.
- Name stays in a temporary bubble beside the face. A thin gold seam closes the speaker field; a large editorial serif gives the spoken idea one focal point. Only `110°` gets gold emphasis.
- The desert photo begins under the caption and continues through a compact brand lockup. Essential identity sits above the Instagram bottom-control area.
- The ending keeps Kody prominent, moves through show title and name to one episode CTA, then lets an Arizona image fill the lower space. All actionable words stay above the bottom controls.
- Recreate this with the actual unmodified source frame, licensed photo, and editable type. The generated face and generated ending landscape are concept imagery. Do not use the monogram as an approved logo without checking the prospect's real identity.

## Generation record

Input references: `kody-main-figma-1.jpg` for the main concept, `kody-end-1.jpg` for the ending structure, and the generated main concept for the ending's visual family. Built-in image generation produced 941×1672 sources; the review JPGs are an inspected 1080×1920 fit. The Instagram checks use the same overlay function as the previous Kody proof.

Main prompt: “Edit the provided Kody Romero layout image. Preserve the actual man in the top video still and the actual desert/cactus supporting photo in the lower part; keep his face and clothing recognizably unchanged. Preserve the wireframe's overall content order and relative zones: speaker occupies top ~40%, caption immediately below, large supporting Arizona desert image below caption, small Arizona Living identity near bottom. Keep his name tag near his right shoulder/face, not in the caption band. Reimagine the graphic design to look like a premium Arizona editorial publication: refined deep midnight navy, warm bone-white, restrained sun-gold, subtle desert-sand tint, considered negative space, thin precise dividers, no generic rounded dashboard cards, no busy topographic pattern. Make the photo panels visually connected with elegant crop, clean edges and gentle tonal transition. Typography is the hero: a bold but warm contemporary serif for the primary statement, a clean supporting sans for speaker identity, strong optical alignment, deliberate line breaks, generous but controlled vertical rhythm. Exact on-screen caption text, legible and large: '“It’s a dry heat”' on line 1, 'stops mattering at 110°' on line 2; the 110° should be the gold emphasis. Exact speaker tag: 'Kody Romero' and smaller 'ARIZONA LIVING'. Bottom identity: 'ARIZONA LIVING' with a compact monogram mark. All text must be crisp and accurate. Leave the bottom 15% relatively calm so Instagram controls do not cover essential text. Make this feel like a finished high-end short-form video keyframe, not a template diagram, social quote card, or collage. No extra slogans, no invented statistics, no fake logos, no website, no extra text. Output portrait 9:16.”

Targeted main edit: “Turn the speaker identification near the right side of his face into a compact intentional two-line dark-navy capsule bubble with a thin warm-gold outline; retain exact text 'Kody Romero' and 'ARIZONA LIVING', and keep it clear of the face. Move the bottom AR monogram + ARIZONA LIVING identity lockup upward so all of it is above the bottom 15 percent of the frame, resting gently over the darker lower part of the desert image; leave the bottom 15 percent free of essential text for Instagram controls. Preserve everything else.”

Caption correction: “Remove only the short faint gold horizontal underline centered between the two caption lines, under ‘It’s a dry heat’ and above ‘stops mattering at 110°’. Fill with the existing navy field and preserve the portrait, photo, exact text, bubble, and all other design elements.”

Ending prompt: “Create one polished portrait 9:16 end card for the Arizona Living short-form video. Image 1 is the rough ending wireframe and shows the real Kody Romero portrait to preserve. Image 2 is the polished main-frame style reference: match its midnight navy, bone-white editorial serif, restrained sun-gold, warm Arizona desert photography, and precise spacing. Preserve the wireframe's general order: Kody portrait high in the frame, Arizona Living show identity and his name beneath, one strong FULL EPISODE call to action, compact @KODYROMEROREALTY near the lower part. Design all of this as one cohesive premium editorial composition, not widely separated floating text bands. Use a cropped, subtle Arizona desert image as a lower visual continuation rather than a blank dark lower half. Keep the recognizable real Kody face; do not change his identity. Typography should have clear scale differences and generous controlled rhythm; 'ARIZONA LIVING' is the primary brand line, Kody's name secondary, FULL EPISODE the unmistakable action. Add a thin gold rule or understated outlined capsule only if it helps hierarchy. Exact text only: 'ARIZONA LIVING', 'Kody Romero', 'FULL EPISODE', '@KODYROMEROREALTY'. All essential text must be above the bottom 15 percent reserved for Instagram controls. No extra slogans, no web addresses, no invented logos beyond the small AR monogram already implied by the rough reference. This is a finished design reference, not a wireframe.”
