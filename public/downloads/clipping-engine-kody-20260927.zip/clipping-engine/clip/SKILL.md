---
name: clip
description: Turn a prospect or brand plus one or more videos into a ranked clip opportunity list and a branded demo or full clipping pass. Also handles podcasts, interviews, webinars, raw shoots, and reusable clipping-layout design. Reuses approved brand looks and keeps new designs editable.
---

# Clip

One prospect and one video are enough to begin; a folder or many source videos works too. Inspect the source set, list every viable clip opportunity, prepare the brand, then edit, render, inspect, and assemble the requested run. A **demo** selects 3–4 distinct viable videos by default; a **full pass** makes every viable non-duplicate story. If there are fewer clean stories, report the smaller count rather than padding. Read [run-modes.md](reference/run-modes.md) for the opportunity record, scope rules, and completion contract. A new look stays a draft until Patrik approves it, but do not pause an authorized demo or full pass just to obtain that label. For another episode of an approved brand, reuse its saved design and proceed.

## Choose the workflow

- **Prospect, podcast, interview, webinar, or YouTube sample:** read [prospect-workflow.md](reference/prospect-workflow.md). This owns the job from intake through the finished sample pack.
- **Raw event, job-site, or B-roll shoot:** read [raw-shoot-workflow.md](reference/raw-shoot-workflow.md) and [format-recipes.md](reference/format-recipes.md). Preserve any existing job brief and approved post menu.
- **A specific correction to an existing pack:** make that correction and recheck affected outputs; retain the accepted design and other files.

## Design standard

Read [design-standard.md](reference/design-standard.md) for the brand-independent quality bar. The approved Oak Street samples are a craft reference: a complete story, strong readable hierarchy, useful pictures and graphics, visible speakers, precise captions, restrained motion, and an ending that enters during speech. The Kody designed main/ending pair is a promising art-direction concept, not an approved universal palette. Captions should not receive faint decorative underlines.

Use each client's real brand and GPT design reference. Read [design-contract.md](reference/design-contract.md) before making a new look. Show the design applied to real footage. Save approval with the exact reference files; a generated board, a finished render, or an assistant's praise is not approval.

Choose a structural composition from [layout-library.md](reference/layout-library.md), using a measured Figma wireframe when one exists. The option recipes yield many **draft ideas**, not pre-approved templates; shortlist by what the footage can actually show. The Figma frame defines spacing, crop, layer order, and roles; ChatGPT makes prospect-specific brand and topic assets inside those roles. Keep the Figma frame editable and versioned. If a composition overlaps, resolve its structure in Figma and remeasure it instead of adding one-off renderer offsets. New GPT layouts remain explorations until drawn as wireframes, measured, tested on footage, and chosen.

Plan supporting pictures against the spoken beats. Search free online sources for the actual place, action, or object being discussed, inspect each image and its license page, and save creator/license/source links. Avoid recycling one scenic image across unrelated points. If no accurate picture exists, use a clear graphic rather than a misleading stock photo. Read the image procedure in [prospect-workflow.md](reference/prospect-workflow.md).

Keep one coherent visual family across a prospect's pack. Vary the story and supporting imagery inside that family. A different layout is justified by the source or by user direction, not by a rule that every clip must look different. Full-screen speaker and boxed templates remain options, not automatic replacements for the chosen style.

For new images use [gpt-image-generation.md](reference/gpt-image-generation.md). Preserve the reference's type weight, proportions, spacing, color, and component shapes in the actual render. When a reconstruction loses those qualities, fix that component or use the generated artwork directly before expanding the batch.

## Production

Read [dialogue-production.md](reference/dialogue-production.md) for source timing, ranking, aligned cuts, captions, and audio. A stranger must understand the entire point. Emotional peaks guide discovery; they do not outrank missing context.

- Word timing comes from alignment and is verified against the final audio.
- Faces remain intact and clear of titles throughout motion and speaker changes.
- Introduce each speaker with a readable name/show bubble near their first line, then animate it away after roughly 3–4 seconds. Bring it back only for a real speaker change or a long return; the end card can identify them again. Keep the bubble clear of faces and captions.
- Source overlays and transitions are inspected in moving footage. Held frames over a talking face are not a clean repair.
- End cards enter about 1.2 seconds before the last spoken word, with picture and sound continuing underneath. Reuse the approved mountain/photo or subtle moving-line treatment.
- Inspect the rendered result at phone size, normal speed, and at each transition. Automated checks support that inspection; they do not approve a design.

## Existing tools

Run Python tools through `/usr/bin/python3` on this Mac; it has Pillow and NumPy. Paths below are relative to this skill.

| Task | Tool/reference |
|---|---|
| Rank candidates and find emotion | `scripts/audio_peaks.py`, `scripts/moment_map.py`, `reference/moment-ranking-research.md` |
| Align and verify clean dialogue | `scripts/align_words.py`, `scripts/snapcut.py`, `scripts/check_cuts.py`, `scripts/audit_boundaries.py` |
| Inspect speaker framing | `scripts/find_focus.py` plus actual source frames |
| Branded talking clips | `scripts/render_clip.py CLIP.json`; `--stills 1,5,10` for a cheap proof |
| Oak Street photo-led example | `scripts/render_clip_reference.py` |
| Additional supported formats | `scripts/render.py`, `scripts/stills.py`, `scripts/render_post.py`, `scripts/render_reel.py`; `reference/renderer-styles-and-plans.md` |
| Free reusable pictures | `scripts/find_images.py`; keep `credits.json` and required credits |
| Slice generated component sheets | `scripts/gpt_sheet.py`; inspect every panel and its true dimensions |

A renderer creates only the artifact described in its input. The **agent** runs the end-to-end workflow; none of these commands alone downloads, designs, and delivers an entire pack. State exactly which stages completed.

## Completion

Deliver a review page or clearly organized folder containing the full opportunity list, selected demo/full scope, playable clips, covers, copy, source links, credits, and a short QA record. Keep production plans and approved brand references beside the pack so the next run can continue. User-facing updates are brief. Do not contact a prospect, post content, or claim delivery to them without an explicit instruction.
