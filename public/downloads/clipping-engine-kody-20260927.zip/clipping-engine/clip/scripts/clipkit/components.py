"""Reusable, brand-driven building blocks. Every element animates in (the /clip standard)."""
import math, re
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from .core import (font, fit_font, wrap, text_layer, rounded, mask_round, circle_crop, place, shadow_of,
                   cover, blurred_bg, C, rgb, mix, readable_on, brand_asset, clamp, prog, ease_out,
                   ease_back, ease_in_out, lerp)

# ================================================================ captions
TREATMENTS = {
    # max words per chunk, size, font role, case
    "pop":     dict(max_words=2, max_chars=14, size=116, role="caption", lines=2),
    "karaoke": dict(max_words=4, max_chars=22, size=86, role="caption", lines=2),
    "box":     dict(max_words=5, max_chars=26, size=70, role="caption", lines=2),
    "bar":     dict(max_words=9, max_chars=38, size=50, role="body", lines=2),
}

def _clean(w, case, keep_punct):
    w = w.strip()
    if not keep_punct:
        w = w.rstrip(",.;:")
    if case == "upper":
        return w.upper()
    return w

def chunk_words(words, max_words=3, max_chars=20, pause=0.35):
    chunks, cur = [], []
    for i, w in enumerate(words):
        cur.append(w)
        nxt = words[i + 1] if i + 1 < len(words) else None
        chars = sum(len(x["w"]) + 1 for x in cur)
        brk = (len(cur) >= max_words or chars >= max_chars or w["w"][-1:] in ".?!," or nxt is None
               or nxt["s"] - w["e"] > pause or nxt["spk"] != w["spk"] or nxt["seg"] != w["seg"] and nxt["s"] - w["e"] > 0.12)
        if nxt is not None and not brk and chars + len(nxt["w"]) > max_chars:
            brk = True
        if brk:
            chunks.append({"words": cur, "s": cur[0]["s"], "e": cur[-1]["e"], "spk": w["spk"]}); cur = []
    for i, c in enumerate(chunks):
        nxt = chunks[i + 1]["s"] if i + 1 < len(chunks) else c["e"] + 0.6
        c["until"] = min(nxt, c["e"] + 0.6)
    return chunks

class Captions:
    def __init__(self, ctx, treatment="karaoke", y=1250, max_w=900, size=None, case=None, emphasis=None,
                 keep_punct=None, align="center", on=None):
        self.ctx, self.tr = ctx, treatment
        spec = dict(TREATMENTS[treatment])
        if ctx.brand["style"].get("energy") == "punchy" and treatment == "karaoke":
            spec["max_words"] = 3
        self.spec = spec
        self.y, self.max_w, self.align = y, max_w, align
        self.size = size or spec["size"]
        self.case = case or ("sentence" if treatment == "bar" else ctx.brand["style"].get("caption_case", "upper"))
        self.keep_punct = treatment == "bar" if keep_punct is None else keep_punct
        self.fname = ctx.brand["type"][spec["role"]]
        self.emph = set(e.lower() for e in (emphasis if emphasis is not None else ctx.plan.get("emphasis", [])))
        self.chunks = chunk_words(ctx.tl.words, spec["max_words"], spec["max_chars"])
        self.on = on  # optional fn(t)->bool to suppress captions (e.g. during a stat reveal)
        self._cache = {}

    def active(self, t):
        for c in self.chunks:
            if c["s"] - 0.06 <= t < c["until"]:
                return c
        return None

    def spk_color(self, spk):
        sp = (self.ctx.plan.get("speakers") or {}).get(spk, {})
        col = sp.get("color") or (self.ctx.brand.get("speakers") or {}).get(spk, {}).get("color")
        if col:
            return rgb(C(self.ctx.brand, col) if not str(col).startswith("#") else col)
        order = list((self.ctx.plan.get("speakers") or {"a": {}}).keys())
        return C(self.ctx.brand, "accent" if (order.index(spk) if spk in order else 0) == 0 else "accent2")

    def _layout(self, c):
        f = font(self.fname, self.size)
        toks = [_clean(w["w"], self.case, self.keep_punct) for w in c["words"]]
        lines, cur, curw = [], [], 0
        sp = f.getlength(" ")
        for i, tk in enumerate(toks):
            tw = f.getlength(tk)
            if cur and curw + sp + tw > self.max_w:
                lines.append(cur); cur, curw = [], 0
            cur.append(i); curw += (sp if len(cur) > 1 else 0) + tw
        if cur:
            lines.append(cur)
        while len(lines) > self.spec["lines"] and self.size > 40:  # shrink to fit
            self.size -= 6
            return self._layout(c)
        return f, toks, lines

    def render(self, canvas, t):
        if self.on and not self.on(t):
            return
        c = self.active(t)
        if not c:
            return
        f, toks, lines = self._layout(c)
        ai = max([i for i, w in enumerate(c["words"]) if w["s"] - 0.05 <= t] or [0])
        base = rgb(self.ctx.brand["roles"].get("caption_text", "#FFFFFF"))
        hi = self.spk_color(c["spk"])
        asc, desc = f.getmetrics()
        lh = int((asc + desc) * (1.0 if self.tr != "bar" else 1.15))
        sp = f.getlength(" ")
        widths = [sum(f.getlength(toks[i]) for i in ln) + sp * (len(ln) - 1) for ln in lines]
        pad = 28
        W = int(max(widths)) + pad * 2 + (40 if self.tr in ("bar", "box") else 0)
        H = lh * len(lines) + pad * 2 + (20 if self.tr in ("bar",) else 0)
        L = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        d = ImageDraw.Draw(L)
        if self.tr == "bar":
            bar = rgb(self.ctx.brand["roles"].get("bar", "#000000"))
            d.rounded_rectangle((0, 0, W - 1, H - 1), radius=18, fill=bar + (190,))
        pos = {}
        for li, ln in enumerate(lines):
            x = (W - widths[li]) / 2 if self.align == "center" else pad + 20
            y = pad + li * lh + (10 if self.tr == "bar" else 0)
            for i in ln:
                pos[i] = (x, y, x + f.getlength(toks[i]), y + lh)
                x += f.getlength(toks[i]) + sp
        # active-word box (slides from previous word)
        if self.tr == "box" and ai in pos:
            x0, y0, x1, y1 = pos[ai]
            pw = c["words"][ai - 1]["s"] if ai > 0 else None
            if ai > 0 and (ai - 1) in pos:
                p = ease_out(prog(t, c["words"][ai]["s"] - 0.05, 0.1))
                px0, py0, px1, py1 = pos[ai - 1]
                x0, y0, x1, y1 = lerp(px0, x0, p), lerp(py0, y0, p), lerp(px1, x1, p), lerp(py1, y1, p)
            d.rounded_rectangle((x0 - 14, y0 + lh * 0.02, x1 + 14, y1 - lh * 0.04), radius=16, fill=hi + (255,))
        stroke = self.ctx.brand["style"].get("caption_stroke", 0) if self.tr != "bar" else 0
        shadow = self.tr in ("pop", "karaoke") and self.ctx.brand["style"].get("caption_shadow", True)
        for i, (x, y, _, _) in pos.items():
            tk = toks[i]
            key = re.sub(r"[^a-z0-9$%']", "", c["words"][i]["w"].lower())
            col = base
            if self.tr == "karaoke" and i == ai:
                col = hi
            elif self.tr == "box" and i == ai:
                col = rgb(readable_on(hi))
            elif self.tr == "pop" and key in self.emph:
                col = hi
            elif self.tr in ("karaoke", "bar") and key in self.emph and i != ai:
                col = mix(base, hi, 0.0 if self.tr == "karaoke" else 1.0)
            if self.tr == "bar" and i > ai:
                col = base
            if shadow:
                off = max(3, int(self.size * 0.055))
                d.text((x + off, y + off), tk, font=f, fill=(0, 0, 0, 150))
            d.text((x, y), tk, font=f, fill=col, stroke_width=stroke, stroke_fill=(0, 0, 0))
        if shadow:
            # soft glow shadow under the whole block for legibility on busy video
            sh, spad = shadow_of(L, blur=14, opacity=0.45)
        else:
            sh = None
        # entrance animation per chunk
        p = prog(t, c["s"] - 0.06, 0.18)
        if self.tr == "pop":
            sc, al, dy = lerp(0.72, 1.0, ease_back(p, 2.2)), min(1, p * 3), 0
        elif self.tr == "bar":
            sc, al, dy = 1.0, ease_out(prog(t, c["s"] - 0.06, 0.12)), 0
        else:
            sc, al, dy = lerp(0.94, 1.0, ease_out(p)), min(1, p * 2.5), (1 - ease_out(p)) * 18
        x = self.ctx.W / 2 if self.align == "center" else 60 + W / 2
        if sh is not None:
            place(canvas, sh, x, self.y + dy, "mm", sc, al)
        place(canvas, L, x, self.y + dy, "mm", sc, al)

# ================================================================ backgrounds
class Texture:
    """Brand color that breathes: drifting contour lines + a soft moving light. Precomputed once."""
    def __init__(self, W, H, base, line, light=None, kind="contours", seed=3):
        self.W, self.H, self.base = W, H, rgb(base)
        self.kind = kind
        M = 160
        if kind == "contours":
            yy, xx = np.mgrid[0:H + 2 * M, 0:W + 2 * M].astype(np.float32)
            r = np.random.RandomState(seed)
            fld = np.zeros_like(xx)
            for _ in range(5):
                fx, fy, ph = r.uniform(0.002, 0.006), r.uniform(0.002, 0.006), r.uniform(0, 6.28)
                fld += np.sin(xx * fx + ph) * np.cos(yy * fy - ph * 0.7)
            fr = (fld * 3.2) % 1.0
            a = (np.clip(1 - np.minimum(fr, 1 - fr) / 0.035, 0, 1) * 70).astype(np.uint8)
            lay = Image.new("RGBA", (W + 2 * M, H + 2 * M), rgb(line) + (0,))
            lay.putalpha(Image.fromarray(a))
            self.lines = lay
        elif kind == "halftone":
            # print-style halftone: dot grid whose size follows a slow noise field, plus grit
            r = np.random.RandomState(seed)
            Hh, Ww = H + 2 * M, W + 2 * M
            lay = Image.new("RGBA", (Ww, Hh), (0, 0, 0, 0))
            d = ImageDraw.Draw(lay)
            step = 16
            ph = r.uniform(0, 6.28, 4)
            col = rgb(line)
            for y in range(0, Hh, step):
                for x in range((y // step) % 2 * step // 2, Ww, step):
                    v = (math.sin(x * 0.004 + ph[0]) * math.cos(y * 0.003 + ph[1]) + math.sin((x + y) * 0.0025 + ph[2])) / 2
                    rad = max(0.0, (v + 0.35) * 4.2)
                    if rad > 0.6:
                        d.ellipse((x - rad, y - rad, x + rad, y + rad), fill=col + (90,))
            grit = (r.rand(Hh, Ww) ** 6 * 90).astype(np.uint8)
            g = Image.new("RGBA", (Ww, Hh), (255, 255, 255, 0)); g.putalpha(Image.fromarray(grit))
            lay.alpha_composite(g)
            self.lines = lay
        elif kind == "grain":
            r = np.random.RandomState(seed)
            n = (r.rand(H + 2 * M, W + 2 * M) * 28).astype(np.uint8)
            lay = Image.new("RGBA", (W + 2 * M, H + 2 * M), (255, 255, 255, 0)); lay.putalpha(Image.fromarray(n))
            self.lines = lay
        else:
            self.lines = None
        self.M = M
        g = Image.radial_gradient("L").resize((W + 400, W + 400))
        g = g.point(lambda v: int(max(0, 255 - v) * 0.22))
        self.light = Image.new("RGBA", g.size, rgb(light or line) + (0,)); self.light.putalpha(g)

    def frame(self, t):
        img = Image.new("RGBA", (self.W, self.H), self.base + (255,))
        lx = self.W * 0.5 + math.sin(t * 0.23) * self.W * 0.35
        ly = self.H * 0.35 + math.cos(t * 0.17) * self.H * 0.2
        place(img, self.light, lx, ly)
        if self.lines is not None:
            ox = int(self.M + math.sin(t * 0.11) * self.M * 0.8)
            oy = int(self.M + t * 6 % self.M)
            img.alpha_composite(self.lines.crop((ox, oy, ox + self.W, oy + self.H)))
        return img

def gradient_v(W, H, top, bottom):
    a = np.linspace(0, 1, H)[:, None, None]
    arr = (np.array(rgb(top))[None, None] * (1 - a) + np.array(rgb(bottom))[None, None] * a).astype(np.uint8)
    return Image.fromarray(np.repeat(arr, W, axis=1), "RGB").convert("RGBA")

def scrim(W, H, y0, y1, max_alpha=180, color=(0, 0, 0), up=False):
    """Vertical fade to darken behind text over a video."""
    a = np.zeros((H, 1), np.float32)
    ys = np.arange(H)
    ramp = np.clip((ys - y0) / max(1, (y1 - y0)), 0, 1)
    a[:, 0] = (1 - ramp if up else ramp) * max_alpha
    L = Image.fromarray(np.repeat(a, W, axis=1).astype(np.uint8))
    img = Image.new("RGBA", (W, H), tuple(color) + (0,)); img.putalpha(L); return img

# ================================================================ small components
def chip(text, brand, fill_role="accent", size=30, font_role="body", pad=(22, 10), upper=True):
    f = font(brand["type"][font_role], size)
    fill = C(brand, fill_role)
    tx = text.upper() if upper else text
    w, h = int(f.getlength(tx)) + pad[0] * 2, int(size * 1.25) + pad[1] * 2
    L = rounded((w, h), h / 2, fill + (255,))
    ImageDraw.Draw(L).text((w / 2, h / 2 + 1), tx, font=f, fill=readable_on(fill), anchor="mm")
    return L

def rise_in(canvas, layer, x, y, t, start, anchor="mm", dist=40, dur=0.45, fade_out_at=None):
    p = ease_out(prog(t, start, dur))
    a = min(1, prog(t, start, dur * 0.6))
    if fade_out_at is not None:
        a *= 1 - prog(t, fade_out_at, 0.3)
    place(canvas, layer, x, y + (1 - p) * dist, anchor, 1.0, a)

def pop_in(canvas, layer, x, y, t, start, anchor="mm", dur=0.35, fade_out_at=None):
    p = prog(t, start, dur)
    a = min(1, p * 3)
    if fade_out_at is not None:
        a *= 1 - prog(t, fade_out_at, 0.3)
    place(canvas, layer, x, y, anchor, lerp(0.6, 1.0, ease_back(p, 2.0)), a)

def headline(ctx, text, max_w, size=84, lines=3, color=None, role="headline", highlight=None, upper=None, align="center"):
    b = ctx.brand
    up = b["style"].get("headline_case", "upper") == "upper" if upper is None else upper
    tx = text.upper() if up else text
    f, ls = fit_font(tx, b["type"][role], size, max_w, lines)
    hl = {}
    for w in (highlight if highlight is not None else ctx.plan.get("highlight", [])):
        hl[w.lower()] = C(b, "accent")
    return text_layer(ls, f, color or C(b, "text"), align=align, spacing=1.02, highlights=hl)

def headline_staggered(canvas, ctx, text, x, y_top, t, start=0.0, max_w=920, size=84, lines=3, color=None,
                       highlight=None, fade_out_at=None, align="center", anchor_x="m", role="headline", upper=None):
    """Each line rises in with a 90 ms stagger."""
    b = ctx.brand
    up = b["style"].get("headline_case", "upper") == "upper" if upper is None else upper
    tx = text.upper() if up else text
    f, ls = fit_font(tx, b["type"][role], size, max_w, lines)
    hl = {w.lower(): C(b, "accent") for w in (highlight if highlight is not None else ctx.plan.get("highlight", []))}
    y = y_top
    for i, ln in enumerate(ls):
        L = text_layer([ln], f, color or C(b, "text"), align=align, spacing=1.0, highlights=hl, pad=6)
        rise_in(canvas, L, x, y, t, start + i * 0.09, anchor=anchor_x + "t", dist=36, fade_out_at=fade_out_at)
        y += L.height - 10
    return y

def progress_bar(canvas, ctx, t, x0, x1, y, thick=8, color=None, track=(255, 255, 255, 60)):
    d = ImageDraw.Draw(canvas)
    p = clamp(t / max(0.1, ctx.tl.speech))
    d.rounded_rectangle((x0, y, x1, y + thick), radius=thick // 2, fill=track)
    if p > 0.002:
        d.rounded_rectangle((x0, y, x0 + (x1 - x0) * p, y + thick), radius=thick // 2, fill=(color or C(ctx.brand, "accent")) + (255,))

def lower_third(canvas, ctx, name, sub, x, y, t, start, end=None):
    b = ctx.brand
    fn, fs = font(b["type"]["headline"], 46), font(b["type"]["body"], 30)
    w = int(max(fn.getlength(name), fs.getlength(sub))) + 64
    h = 118
    L = Image.new("RGBA", (w + 12, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(L)
    d.rounded_rectangle((12, 0, w + 11, h - 1), radius=14, fill=C(b, "surface") + (240,))
    d.rectangle((0, 0, 11, h - 1), fill=C(b, "accent") + (255,))
    d.text((40, 16), name, font=fn, fill=C(b, "text"))
    d.text((40, 72), sub, font=fs, fill=mix(C(b, "text"), C(b, "surface"), 0.3))
    p = ease_out(prog(t, start, 0.4))
    a = min(1, prog(t, start, 0.25))
    if end is not None:
        a *= 1 - prog(t, end, 0.3)
    place(canvas, L, x - (1 - p) * 80, y, "lt", 1, a)

def logo_bug(canvas, ctx, x, y, h=64, t=0, start=0.2):
    lg = brand_asset(ctx.brand, "logo")
    if lg is None:
        L = chip(ctx.brand.get("short_name") or ctx.brand.get("client", ""), ctx.brand, "surface", 26)
    else:
        L = lg.resize((max(1, int(lg.width * h / lg.height)), h), Image.LANCZOS)
    rise_in(canvas, L, x, y, t, start, "lt", dist=16)

def face_bubble(canvas, img, cx, cy, d, ring, active=True, t=0, start=0, pulse=False):
    face = circle_crop(img, d)
    ringw = max(6, d // 22)
    R = Image.new("RGBA", (d + ringw * 2 + 4, d + ringw * 2 + 4), (0, 0, 0, 0))
    ImageDraw.Draw(R).ellipse((2, 2, R.width - 3, R.height - 3), fill=rgb(ring) + (255,))
    R.alpha_composite(face, (ringw + 2, ringw + 2))
    sc = 1.0 if active else 0.78
    if pulse and active:
        sc *= 1 + 0.025 * math.sin(t * 6)
    p = ease_back(prog(t, start, 0.4), 1.6)
    al = (1.0 if active else 0.55) * min(1, prog(t, start, 0.2))
    sh, pad = shadow_of(R, 16, 0.35)
    place(canvas, sh, cx, cy + 8, "mm", sc * p, al)
    place(canvas, R, cx, cy, "mm", sc * p, al)

# ================================================================ beats (pattern interrupts)
def fmt_num(v, decimals=0):
    return f"{v:,.{decimals}f}"

def stat_beat(canvas, ctx, beat, t):
    """Big number takes over: dims the frame, counts up with overshoot, label + source line."""
    t0, dur = beat["t"], beat.get("dur", 2.6)
    if not (t0 - 0.05 <= t <= t0 + dur):
        return False
    b, W, H = ctx.brand, ctx.W, ctx.H
    fade = min(prog(t, t0, 0.2), 1 - prog(t, t0 + dur - 0.25, 0.25))
    canvas.alpha_composite(Image.new("RGBA", (W, H), C(b, "bg") + (int(215 * fade),)))
    p = ease_out(prog(t, t0 + 0.05, beat.get("count", 0.9)))
    val = beat["value"] * p
    txt = beat.get("prefix", "") + fmt_num(val, beat.get("decimals", 0)) + beat.get("suffix", "")
    fin = beat.get("prefix", "") + fmt_num(beat["value"], beat.get("decimals", 0)) + beat.get("suffix", "")
    f, _ = fit_font(fin, b["type"]["number"], beat.get("size", 250), W - 140, 1)
    L = text_layer([txt], f, C(b, "accent"), shadow=(0, 0, 0, 120))
    sc = lerp(0.7, 1.0, ease_back(prog(t, t0, 0.35), 2.2)) * (1 + 0.05 * math.exp(-8 * max(0, t - t0 - 0.9)) * (t > t0 + 0.9))
    cy = beat.get("y", H * 0.42)
    place(canvas, L, W / 2, cy, "mm", sc, fade)
    if beat.get("label"):
        lf, ll = fit_font(beat["label"].upper(), b["type"]["headline"], 60, W - 200, 2)
        rise_in(canvas, text_layer(ll, lf, C(b, "text")), W / 2, cy + L.height / 2 + 20, t, t0 + 0.35, "mt",
                fade_out_at=t0 + dur - 0.25)
    if beat.get("source"):
        sf = font(b["type"]["body"], 28)
        rise_in(canvas, text_layer([beat["source"]], sf, C(b, "muted")), W / 2, cy + L.height / 2 + 190, t,
                t0 + 0.5, "mt", fade_out_at=t0 + dur - 0.25)
    return True

def list_panel(canvas, ctx, beat, t, x, y, w, row_h=112, size=46, show_title=True, dim_done=True):
    """Numbered points build on their spoken cue; current item full, earlier items dim."""
    b = ctx.brand
    items, cues = beat["items"], beat["cues"]
    yy = y
    if show_title and beat.get("title"):
        yy = headline_staggered(canvas, ctx, beat["title"], x, y, t, beat.get("title_t", 0.0), w, 68, 2,
                                align="left", anchor_x="l") + 26
    cur = max([i for i, c in enumerate(cues) if t >= c] or [-1])
    for i, (it, c) in enumerate(zip(items, cues)):
        if t < c - 0.05:
            break
        badge = Image.new("RGBA", (76, 76), (0, 0, 0, 0))
        ImageDraw.Draw(badge).ellipse((0, 0, 75, 75), fill=C(b, "accent") + (255,))
        bf = font(b["type"]["headline"], 44)
        ImageDraw.Draw(badge).text((38, 40), str(i + 1), font=bf, fill=readable_on(C(b, "accent")), anchor="mm")
        f, ls = fit_font(it, b["type"]["caption"], size, w - 110, 2, 30)
        L = text_layer(ls, f, C(b, "text"), align="left", spacing=1.0, pad=4)
        al = 1.0 if (i == cur or not dim_done) else 0.5
        pop_in(canvas, badge, x + 38, yy + 38, t, c)
        p = ease_out(prog(t, c + 0.05, 0.35))
        place(canvas, L, x + 100 - (1 - p) * 40, yy + 38, "lm", 1, al * min(1, p * 2))
        if i == cur:
            d = ImageDraw.Draw(canvas)
            ul = (w - 110) * ease_out(prog(t, c + 0.2, 0.4))
            d.rectangle((x + 100, yy + 38 + L.height / 2 + 4, x + 100 + min(ul, L.width), yy + 38 + L.height / 2 + 9),
                        fill=C(b, "accent") + (255,))
        yy += max(row_h, L.height + 30)
    return yy

def post_card(ctx, text, name, handle, avatar, w=920, size=50, dark=False):
    b = ctx.brand
    bg, fg = ((22, 24, 28), (245, 245, 245)) if dark else ((255, 255, 255), (20, 20, 22))
    f, ls = fit_font(text, b["type"]["body"], size, w - 100, 7, 34)
    body = text_layer(ls, f, fg, align="left", spacing=1.18, pad=0)
    h = 60 + 96 + 30 + body.height + 50
    card = rounded((w, h), 34, bg + (247,))
    d = ImageDraw.Draw(card)
    if avatar is not None:
        card.alpha_composite(circle_crop(avatar, 96), (48, 48))
    else:
        d.ellipse((48, 48, 144, 144), fill=C(b, "accent"))
    d.text((166, 56), name, font=font(b["type"]["headline"], 42), fill=fg)
    d.text((166, 110), handle, font=font(b["type"]["body"], 30), fill=mix(fg, bg, 0.45))
    d.rectangle((w - 70, 70, w - 48, 92), fill=C(b, "accent"))  # brand dot, not a platform logo
    card.alpha_composite(body, (50, 176))
    return card

# ================================================================ end card
def end_card(canvas, ctx, t, bg_img=None, faces=None):
    """Blurred story frame under brand color; logo, faces from the sides, follow + link lines, staggered."""
    b, W, H = ctx.brand, ctx.W, ctx.H
    te = t - ctx.tl.speech
    if te < 0:
        return
    a = ease_out(prog(te, 0, 0.35))
    base = blurred_bg(bg_img, W, H, darken=0.2) if bg_img is not None else Image.new("RGBA", (W, H), C(b, "bg") + (255,))
    tint = Image.new("RGBA", (W, H), C(b, "bg") + (205,))
    base.alpha_composite(tint)
    if ctx.texture is not None:
        tx = ctx.texture.frame(t)
        tx.putalpha(tx.getchannel("A").point(lambda v: int(v * 0.5)))
        base.alpha_composite(tx)
    base.putalpha(int(255 * a))
    canvas.alpha_composite(base)
    ec = b.get("end_card", {})
    cy = H * (0.36 if H > W * 1.5 else 0.30)
    lg = brand_asset(b, "logo")
    if lg is not None:
        s = min(420 / lg.width, 240 / lg.height)
        L = lg.resize((int(lg.width * s), int(lg.height * s)), Image.LANCZOS)
        pop_in(canvas, L, W / 2, cy, te, 0.15)
        cy += L.height / 2 + 40
    else:
        L = headline(ctx, b.get("client", ""), W - 200, 90, 2)
        pop_in(canvas, L, W / 2, cy, te, 0.15); cy += L.height / 2 + 40
    if faces:
        n = len(faces)
        for i, (img, name) in enumerate(faces):
            fx = W / 2 + (i - (n - 1) / 2) * 300
            side = -1 if fx < W / 2 else 1
            p = ease_back(prog(te, 0.3 + i * 0.1, 0.45), 1.4)
            face_bubble(canvas, img, lerp(fx + side * 500, fx, p), cy + 130, 210, C(b, "accent"), True, te, 0.3 + i * 0.1)
            nf = font(b["type"]["body"], 30)
            rise_in(canvas, text_layer([name], nf, C(b, "text")), fx, cy + 260, te, 0.5 + i * 0.1, "mt", 20)
        cy += 340
    fl = headline(ctx, ec.get("follow_line", "Follow for more"), W - 160, 88, 1, color=C(b, "accent"))
    rise_in(canvas, fl, W / 2, cy + 20, te, 0.55, "mt")
    y2 = cy + 20 + fl.height + 10
    if b.get("show"):
        sf, sl = fit_font(b["show"], b["type"]["headline"], 58, W - 200, 2)
        L2 = text_layer(sl, sf, C(b, "text"))
        rise_in(canvas, L2, W / 2, y2, te, 0.7, "mt"); y2 += L2.height + 10
    if ec.get("link_line"):
        L3 = text_layer([ec["link_line"]], font(b["type"]["body"], 36), mix(C(b, "text"), C(b, "bg"), 0.2))
        rise_in(canvas, L3, W / 2, y2 + 10, te, 0.85, "mt")


# ================================================================ print-poster kit (Ambition-style social series)
def grade(img, shadow, highlight, amount=0.55, keep_red=True):
    """Duotone-ish grade toward brand shadow/highlight colors; saturated reds survive (accent pops)."""
    im = img.convert("RGB")
    a = np.asarray(im).astype(np.float32) / 255
    lum = (0.299 * a[..., 0] + 0.587 * a[..., 1] + 0.114 * a[..., 2])[..., None]
    lum = np.clip((lum - 0.04) * 1.12, 0, 1) ** 1.1
    sh, hi = np.array(rgb(shadow)) / 255, np.array(rgb(highlight)) / 255
    duo = sh * (1 - lum) + hi * lum
    out = a * (1 - amount) + duo * amount
    if keep_red:
        red = np.clip((a[..., 0] - np.maximum(a[..., 1], a[..., 2]) - 0.18) * 3, 0, 1)[..., None]
        out = out * (1 - red) + a * red
    return Image.fromarray((np.clip(out, 0, 1) * 255).astype(np.uint8))

def cta_box(text, brand, size=40, pad=(26, 14), fill_role="accent"):
    f = font(brand["type"].get("cta", brand["type"]["headline"]), size)
    tx = text.upper()
    w, h = int(f.getlength(tx)) + pad[0] * 2, int(size * 1.15) + pad[1] * 2
    L = Image.new("RGBA", (w, h), C(brand, fill_role) + (255,))
    ImageDraw.Draw(L).text((w / 2, h / 2 + 2), tx, font=f, fill=readable_on(C(brand, fill_role)), anchor="mm")
    return L

def badge_footer(canvas, brand, cx, bottom, d=150, url=None):
    """Round badge centered, URL under it (Ambition series signature)."""
    lg = brand_asset(brand, "logo")
    uf = font(brand["type"]["body"], max(22, d // 6))
    url = url or brand.get("url", "")
    uh = uf.size + 10 if url else 0
    if lg is not None:
        L = lg.resize((d, int(d * lg.height / lg.width)), Image.LANCZOS)
        sh, _ = shadow_of(L, 12, 0.5)
        place(canvas, sh, cx, bottom - uh - L.height / 2 + 6)
        place(canvas, L, cx, bottom - uh - L.height / 2)
    if url:
        place(canvas, text_layer([url], uf, C(brand, "text")), cx, bottom, "mb")

def hero_headline(text, brand, max_w, size=170, lines=4, red_words=(), align="left", spacing=0.9):
    tx = text.upper()
    f, ls = fit_font(tx, brand["type"]["headline"], size, max_w, lines, 60)
    hl = {w.lower().strip(".,!?"): C(brand, "accent") for w in red_words}
    hl.update({w.lower(): C(brand, "accent") for w in red_words})
    return text_layer(ls, f, C(brand, "text"), align=align, spacing=spacing, highlights=hl, pad=6)
