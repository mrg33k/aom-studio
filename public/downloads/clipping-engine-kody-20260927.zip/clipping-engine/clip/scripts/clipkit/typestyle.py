"""Type styles: rebuild a GPT-designed headline look in code so every clip can set new text in it for free.

A client's brand.json carries a "type_style" block, matched once against their approved GPT posts
(see reference/type-style.md). Example (Ambition):

  "type_style": {
    "font": "BarlowCondensed-BlackItalic", "skew": 0.05, "squash": 1.04, "tracking": 0.0,
    "fill": "#F4F4F4", "fill_bottom": "#C9CDD4", "distress": 0.16, "seed": 7,
    "slab": {"color": "#D8261F", "skew": 0.04, "rough": 5, "wear": 0.10, "pad": [34, 14]},
    "line_gap": -0.06,
    "sentence": {"font": "Inter-SemiBold", "size": 44, "bar": "#D8261F"}
  }

Headline = list of lines; a line with slab=True sits on the torn banner (the key words).
Each line is sized to fill the same measure, the way the GPT posts stack them.
"""
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from .core import font, rgb, place, prog, ease_out, ease_back, lerp, clamp

DEFAULT = {"font": "BarlowCondensed-BlackItalic", "skew": 0.05, "squash": 1.0, "tracking": 0.0,
           "fill": "#F4F4F4", "fill_bottom": "#C9CDD4", "distress": 0.16, "seed": 7,
           "slab": {"color": "#D8261F", "skew": 0.03, "rough": 3, "wear": 0.08, "pad": [30, 10]},
           "line_gap": 0.02, "second_line_width": 0.94, "sentence": {"font": "Inter-SemiBold", "size": 40, "bar": "#D8261F"}}

def style_of(brand):
    ts = dict(DEFAULT)
    ts.update(brand.get("type_style", {}))
    sl = dict(DEFAULT["slab"]); sl.update(ts.get("slab", {})); ts["slab"] = sl
    se = dict(DEFAULT["sentence"]); se.update(ts.get("sentence", {})); ts["sentence"] = se
    return ts

# ---------------------------------------------------------------- textures
def _noise(w, h, scale, seed):
    r = np.random.RandomState(seed)
    small = (r.rand(max(2, h // scale), max(2, w // scale)) * 255).astype(np.uint8)
    return np.asarray(Image.fromarray(small).resize((w, h), Image.BICUBIC)).astype(np.float32) / 255

def wear_mask(w, h, amount, seed):
    """1 = keep ink. Fine specks + a few scuffs + short horizontal scratches, like print wear."""
    if amount <= 0:
        return np.ones((h, w), np.float32)
    n = 0.55 * _noise(w, h, 2, seed) + 0.3 * _noise(w, h, 9, seed + 1) + 0.15 * _noise(w, h, 45, seed + 2)
    keep = np.clip((n - amount * 0.55) * 6, 0, 1)
    r = np.random.RandomState(seed + 3)
    for _ in range(int(w * h / 14000 * amount * 4)):
        y, x, L = r.randint(0, h), r.randint(0, w), r.randint(6, 40)
        keep[y:y + 1, x:x + L] *= 0.15
    return keep

# ---------------------------------------------------------------- pieces
def text_ink(text, ts, size, target_w=None):
    """White gritty italic line as RGBA, trimmed. If target_w, size is solved so the line fills it."""
    if target_w:
        f = font(ts["font"], 200)
        w200 = f.getlength(text) * ts["squash"] + 200 * ts["skew"]
        size = max(24, int(200 * target_w / max(1, w200)))
    f = font(ts["font"], size)
    asc, desc = f.getmetrics()
    W = int(f.getlength(text) + size * (0.6 + len(text) * max(0, ts["tracking"])))
    H = asc + desc + size // 4
    L = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(L)
    if ts["tracking"]:
        x = size * 0.2
        for ch in text:
            d.text((x, size * 0.08), ch, font=f, fill=255); x += f.getlength(ch) + size * ts["tracking"]
    else:
        d.text((size * 0.2, size * 0.08), text, font=f, fill=255)
    if abs(ts["squash"] - 1) > 0.005:
        L = L.resize((max(1, int(W * ts["squash"])), H), Image.LANCZOS)
    if ts["skew"]:
        L = L.transform((L.width + int(H * ts["skew"]), H), Image.AFFINE, (1, ts["skew"], -ts["skew"] * H, 0, 1, 0), Image.BICUBIC)
    bb = L.getbbox() or (0, 0, 1, 1)
    L = L.crop(bb)
    a = np.asarray(L).astype(np.float32) / 255 * wear_mask(L.width, L.height, ts["distress"], ts["seed"] + len(text))
    top, bot = np.array(rgb(ts["fill"]), np.float32), np.array(rgb(ts.get("fill_bottom", ts["fill"])), np.float32)
    g = np.linspace(0, 1, L.height)[:, None, None]
    col = top * (1 - g) + bot * g
    col = np.broadcast_to(col, (L.height, L.width, 3)) * (0.94 + 0.06 * _noise(L.width, L.height, 2, 3))[..., None]
    return Image.fromarray(np.dstack([col, a * 255]).clip(0, 255).astype(np.uint8), "RGBA")

def slab(w, h, ts):
    """Torn banner: slanted, ragged top and bottom edges, slightly worn."""
    s = ts["slab"]
    rough, sk = s["rough"], s["skew"]
    pad = rough * 3
    W, H = int(w + pad * 2 + h * sk), int(h + pad * 2)
    m = Image.new("L", (W, H), 0)
    r = np.random.RandomState(ts["seed"] + w)
    step = max(6, rough * 2)
    top = [(pad + h * sk + x, pad + r.randint(-rough, rough + 1)) for x in range(0, int(w) + 1, step)]
    bot = [(pad + x, pad + h + r.randint(-rough, rough + 1)) for x in range(int(w), -1, -step)]
    ImageDraw.Draw(m).polygon(top + bot, fill=255)
    m = m.filter(ImageFilter.GaussianBlur(0.7))
    a = np.asarray(m).astype(np.float32) / 255 * wear_mask(W, H, s["wear"], ts["seed"] + 11)
    shade = 0.88 + 0.12 * _noise(W, H, 25, ts["seed"])
    col = np.stack([np.full((H, W), c, np.float32) * shade for c in rgb(s["color"])], -1)
    return Image.fromarray(np.dstack([col, a * 255]).clip(0, 255).astype(np.uint8), "RGBA"), pad

# ---------------------------------------------------------------- headline block
class Headline:
    """Stack of lines filling one measure. lines: [{"text": "WARM AIR", "slab": True}, {"text": "FROM THE VENTS?"}]
    size_ratio lets the slab line run larger (GPT posts: the key line is the biggest)."""
    def __init__(self, brand, lines, measure=940, slab_scale=1.0, max_size=240):
        self.ts = style_of(brand)
        self.parts = []
        for i, ln in enumerate(lines):
            if i and not ln.get("slab") and "width" not in ln:
                ln = dict(ln, width=self.ts["second_line_width"])
            txt = ln["text"].upper()
            tw = measure * ln.get("width", 1.0) * (slab_scale if ln.get("slab") else 1.0) - (sum(self.ts["slab"]["pad"]) if ln.get("slab") else 0)
            ink = text_ink(txt, self.ts, None, tw)
            if ink.height > max_size:  # short lines would get huge; cap them
                ink = text_ink(txt, self.ts, int(max_size * 0.82))
            if ln.get("slab"):
                px, py = self.ts["slab"]["pad"]
                bg, bpad = slab(ink.width + px * 2, ink.height + py * 2, self.ts)
                self.parts.append({"ink": ink, "slab": bg, "bpad": bpad, "pad": (px, py)})
            else:
                self.parts.append({"ink": ink, "slab": None})
        gap = int(self.ts["line_gap"] * np.mean([p["ink"].height for p in self.parts]))
        y = 0
        for p in self.parts:
            p["y"] = y
            h = p["slab"].height - p["bpad"] * 2 if p["slab"] else p["ink"].height
            p["h"] = h
            y += h + gap + (12 if p["slab"] else 0)
        self.height = y - gap
        self.width = max((p["slab"].width if p["slab"] else p["ink"].width) for p in self.parts)

    def draw(self, canvas, x, y, t=None, start=0.0, stagger=0.12):
        """Static if t is None; else animated: slab wipes in left->right, words punch in, lines stagger."""
        for i, p in enumerate(self.parts):
            t0 = start + i * stagger
            py = y + p["y"]
            if p["slab"]:
                S = p["slab"]
                if t is not None:
                    w = ease_out(prog(t, t0, 0.22))
                    if w <= 0:
                        continue
                    S = S.crop((0, 0, max(1, int(S.width * w)), S.height))
                place(canvas, S, x - p["bpad"], py - p["bpad"], "lt")
                ix, iy = x + p["pad"][0], py + p["pad"][1]
                t0 += 0.1
            else:
                ix, iy = x, py
            if t is None:
                place(canvas, p["ink"], ix, iy, "lt")
            else:
                q = prog(t, t0, 0.2)
                if q <= 0:
                    continue
                sc = lerp(1.18, 1.0, ease_back(q, 1.4))
                place(canvas, p["ink"], ix + p["ink"].width / 2, iy + p["ink"].height / 2, "mm", sc, min(1, q * 3))

def sentence_block(canvas, brand, text, x, y, max_w, t=None, start=0.0):
    """Red side bar + short white sentence (the GPT series' supporting line)."""
    from .core import fit_font, text_layer
    ts_ = style_of(brand); se = ts_["sentence"]
    if se.get("case") == "upper":
        text = text.upper()
    f, ls = fit_font(text, se["font"], se["size"], max_w - 40, se.get("max_lines", 3), 26)
    if se.get("ink"):  # same gritty white-to-grey fill + print wear as the headline, just smaller
        sub = dict(ts_, font=se["font"], skew=se.get("skew", 0.0), squash=se.get("squash", 1.0),
                   distress=se.get("distress", ts_["distress"] * 0.6), tracking=se.get("tracking", 0.0))
        inks = [text_ink(l, sub, f.size) for l in ls]
        gap = int(f.size * se.get("leading", 0.16))
        L = Image.new("RGBA", (max(i.width for i in inks), sum(i.height for i in inks) + gap * (len(inks) - 1)), (0, 0, 0, 0))
        yy = 0
        for i in inks:
            L.alpha_composite(i, (0, yy)); yy += i.height + gap
    else:
        L = text_layer(ls, f, (238, 238, 238), align="left", spacing=1.15, pad=2)
    bar_h = L.height
    d = ImageDraw.Draw(canvas)
    if t is None:
        d.rectangle((x, y, x + 6, y + bar_h), fill=rgb(se["bar"]))
        place(canvas, L, x + 28, y, "lt")
    else:
        p = ease_out(prog(t, start, 0.3))
        if p > 0:
            d.rectangle((x, y, x + 6, y + bar_h * p), fill=rgb(se["bar"]))
        q = prog(t, start + 0.12, 0.35)
        place(canvas, L, x + 28 - (1 - ease_out(q)) * 30, y, "lt", 1, min(1, q * 2))
    return bar_h
