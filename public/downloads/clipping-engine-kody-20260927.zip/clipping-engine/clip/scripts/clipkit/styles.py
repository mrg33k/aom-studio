"""Style registry. Each style = a layout recipe researched from what performs (see reference/style-library.md),
re-skinned by the client's brand.json. A style draws the base frame; beats (stat, list, before/after, b-roll)
and the end card are layered on top generically so every style gets them for free."""
import math
from PIL import Image, ImageDraw
from .core import (C, rgb, mix, cover, contain, blurred_bg, mask_round, place, shadow_of, clamp, prog, ease_out,
                   ease_in_out, lerp, font, fit_font, text_layer, rounded, readable_on, brand_asset, Source)
from .components import (Captions, Texture, scrim, chip, rise_in, pop_in, headline, headline_staggered,
                         progress_bar, lower_third, logo_bug, face_bubble, stat_beat, list_panel, post_card,
                         end_card)

def make_texture(brand, W, H):
    tex = brand["style"].get("texture", "contours")
    if tex == "none":
        return None
    return Texture(W, H, C(brand, "bg"), mix(C(brand, "bg"), C(brand, "accent"), 0.55),
                   mix(C(brand, "bg"), C(brand, "text"), 0.35), tex)

ASPECTS = {"9:16": (1080, 1920), "4:5": (1080, 1350), "1:1": (1080, 1080)}

# ---------------------------------------------------------------- context
class Ctx:
    def __init__(self, plan, brand, tl, sources, aspect="9:16", fps=30):
        self.plan, self.brand, self.tl, self.fps = plan, brand, tl, fps
        self.W, self.H = ASPECTS[aspect]
        self.aspect = aspect
        self.sources = sources
        for k, s in sources.items():
            s.setdefault("reader", Source(s["path"], fps))
        tex = brand["style"].get("texture", "contours")
        self.texture = make_texture(brand, self.W, self.H)
        self.cache = {}
        self._broll = {}
        # safe zones (platform UI): text lives between top..bottom
        if aspect == "9:16":
            self.top, self.bottom, self.right = 220, 1400, 960
        else:
            self.top, self.bottom, self.right = 60, self.H - 60, self.W - 40

    # -- frames
    def src_frame(self, t):
        s, st = self.tl.src_time(min(t, self.tl.speech - 1e-3))
        src = self.sources[s.get("src", "main")]
        return src["reader"].frame(st - src.get("offset", 0)), s

    def broll_at(self, t):
        for bt in self.plan.get("beats", []):
            if bt["type"] == "broll" and bt["t"] <= t < bt["t"] + bt.get("dur", 2.5):
                key = bt["src"]
                if key not in self._broll:
                    self._broll[key] = Source(key, self.fps)
                p = (t - bt["t"]) / bt.get("dur", 2.5)
                img = self._broll[key].frame(bt.get("src_t", 0) + (t - bt["t"]))
                return img, bt, p
        return None

    def main(self, t, w, h, zoom=None, focus=None):
        """The main picture for a region: b-roll if a broll beat is live (Ken Burns), else the source crop."""
        br = self.broll_at(t)
        if br:
            img, bt, p = br
            return cover(img, w, h, bt.get("focus", (0.5, 0.5)), lerp(1.0, 1.12, ease_in_out(p)))
        img, seg = self.src_frame(t)
        return cover(img, w, h, focus or self.focus(seg), zoom if zoom is not None else self.zoom(t))

    def focus(self, seg):
        if seg.get("focus"):
            return seg["focus"]
        sp = (self.plan.get("speakers") or {}).get(seg.get("speaker", "a"), {})
        return sp.get("focus", (0.5, 0.42))

    def zoom(self, t):
        """Motion kit: alternate push-in per cut (jump-cut feel) + punch on emphasis words + slow drift."""
        e = self.brand["style"].get("energy", "standard")
        if e == "calm":
            return 1.0 + 0.04 * clamp(t / max(1, self.tl.speech))
        s = self.tl.seg_at(min(t, self.tl.speech - 1e-3))
        base = 1.0 + (0.07 if s["k"] % 2 else 0.0) + 0.02 * ease_in_out(prog(t, s["t0"], s["t1"] - s["t0"]))
        amp = 0.09 if e == "punchy" else 0.05
        for w in self.emph_words():
            if w["s"] - 0.05 <= t <= w["s"] + 1.0:
                u = t - w["s"] + 0.05
                base += amp * (ease_out(u / 0.12) if u < 0.12 else math.exp(-(u - 0.12) * 3.2))
        return base

    def emph_words(self):
        if "emph" not in self.cache:
            em = set(e.lower() for e in self.plan.get("emphasis", []))
            self.cache["emph"] = [w for w in self.tl.words if w["w"].lower().strip(".,!?") in em]
        return self.cache["emph"]

    def face_img(self, spk):
        sp = (self.plan.get("speakers") or {}).get(spk, {})
        if sp.get("image"):
            return Image.open(sp["image"]).convert("RGB")
        segs = [s for s in self.tl.segs if s.get("speaker", "a") == spk] or self.tl.segs
        s = segs[0]
        src = self.sources[s.get("src", "main")]
        img = Source(src["path"], self.fps).frame((s["a"] + s["b"]) / 2 - src.get("offset", 0))
        f = s.get("focus") or sp.get("focus", (0.5, 0.4))
        side = int(min(img.size) * sp.get("face_size", 0.5))
        x, y = f[0] * img.width, f[1] * img.height
        x0, y0 = int(clamp(x - side / 2, 0, img.width - side)), int(clamp(y - side / 2, 0, img.height - side))
        return img.crop((x0, y0, x0 + side, y0 + side))

    def caps(self, key, **kw):
        if key not in self.cache:
            kw.setdefault("on", lambda t: not self.takeover(t))
            self.cache[key] = Captions(self, **kw)
        return self.cache[key]

    def takeover(self, t):
        for bt in self.plan.get("beats", []):
            if bt["type"] in ("stat", "list_takeover", "before_after") and bt["t"] - 0.05 <= t <= bt["t"] + bt.get("dur", 2.6):
                return True
        return False

    def hook(self):
        return self.plan.get("hook") or ""

    def spk_name(self, spk):
        return ((self.plan.get("speakers") or {}).get(spk) or {}).get("name", "")

def canvas(ctx, t, kind="texture"):
    if kind == "texture" and ctx.texture is not None:
        return ctx.texture.frame(t)
    return Image.new("RGBA", (ctx.W, ctx.H), C(ctx.brand, "bg") + (255,))

def video_card(ctx, cv, t, x, y, w, h, radius=None, zoom=None, focus=None, shadow=True):
    r = ctx.brand["style"].get("radius", 26) if radius is None else radius
    img = ctx.main(t, w, h, zoom=zoom, focus=focus).convert("RGBA")
    card = mask_round(img, r)
    if shadow:
        sh, pad = shadow_of(card, 22, 0.45)
        place(cv, sh, x + w / 2, y + h / 2 + 12)
    cv.alpha_composite(card, (int(x), int(y)))

def hook_block(cv, ctx, t, y, until=3.4, size=92, max_w=920, box=False):
    """0-3 s hook: big claim, rises in by line, leaves at `until` (None = stays)."""
    if not ctx.hook() or (until is not None and t > until + 0.35):
        return
    if box:
        b = ctx.brand
        tx = ctx.hook().upper()
        f, ls = fit_font(tx, b["type"]["headline"], size, max_w - 60, 3)
        L = text_layer(ls, f, C(b, "ink"), spacing=1.0, pad=6)
        bx = rounded((L.width + 60, L.height + 44), 14, C(b, "paper") + (255,))
        bx.alpha_composite(L, (30, 22))
        rise_in(cv, bx, ctx.W / 2, y, t, 0.0, "mt", 30, fade_out_at=until)
        return
    headline_staggered(cv, ctx, ctx.hook(), ctx.W / 2, y, t, 0.0, max_w, size, 3, fade_out_at=until)

# ================================================================ styles
def s_bold_pop(ctx, t):
    """Full-bleed face, 1-2 word pop captions, zoom punches (Hormozi/Submagic family, brand-first)."""
    W, H = ctx.W, ctx.H
    cv = ctx.main(t, W, H).convert("RGBA")
    cv.alpha_composite(scrim(W, H, int(H * 0.5), H, 150))
    if ctx.hook():
        cv.alpha_composite(scrim(W, H, 0, int(H * 0.36), 140, up=True)) if t < 3.8 else None
    hook_block(cv, ctx, t, ctx.top + 20, 3.4, 96)
    if t > 3.4:
        logo_bug(cv, ctx, 60, ctx.top - 40 if ctx.aspect == "9:16" else 50, 60, t, 3.5)
    ctx.caps("pop", treatment="pop", y=int(H * (0.655 if ctx.aspect == "9:16" else 0.72))).render(cv, t)
    return cv

def s_podcast_cut(ctx, t):
    """Full-bleed active-speaker cuts + payoff banner for the first ~5 s + per-speaker caption color (DOAC family).
    plan.question -> persistent question card (street-interview variant)."""
    W, H = ctx.W, ctx.H
    cv = ctx.main(t, W, H, zoom=ctx.zoom(t) if ctx.brand["style"]["energy"] != "calm" else 1.0).convert("RGBA")
    cv.alpha_composite(scrim(W, H, int(H * 0.52), H, 130))
    banner = ctx.plan.get("banner") or ctx.hook()
    if banner and t < 5.9:
        hook_block_text = ctx.plan.get("banner") or ctx.hook()
        b = ctx.brand
        f, ls = fit_font(hook_block_text.upper(), b["type"]["headline"], 60, W - 220, 2)
        L = text_layer(ls, f, C(b, "ink"), spacing=1.02, pad=4)
        bx = rounded((W - 120, L.height + 48), 12, C(b, "paper") + (250,))
        bx.alpha_composite(L, ((bx.width - L.width) // 2, 24))
        ImageDraw.Draw(bx).rectangle((0, bx.height - 10, (bx.width) * ease_out(prog(t, 0.3, 5.2)), bx.height),
                                     fill=C(b, "accent"))
        rise_in(cv, bx, W / 2, ctx.top + 30, t, 0.0, "mt", 30, fade_out_at=5.5)
    if ctx.plan.get("question") and t >= 5.6:
        b = ctx.brand
        q = chip(ctx.plan.get("question_label", "Q"), b, "accent", 28)
        f, ls = fit_font(ctx.plan["question"], b["type"]["headline"], 56, W - 220, 2)
        L = text_layer(ls, f, C(b, "ink"))
        bx = rounded((W - 120, L.height + 40), 16, C(b, "paper") + (245,))
        bx.alpha_composite(L, ((bx.width - L.width) // 2, 20))
        rise_in(cv, bx, W / 2, ctx.top + 30, t, 5.6, "mt", 30)
        rise_in(cv, q, 90, ctx.top + 12, t, 5.7, "lt", 20)
    ctx.caps("kar", treatment="karaoke", y=int(H * (0.66 if ctx.aspect == "9:16" else 0.74))).render(cv, t)
    return cv

def s_split_stack(ctx, t):
    """Two panes, both people always visible; active pane gets a brand border, other dims. Captions on the seam.
    With one speaker: top = wide context, bottom = tight face."""
    W, H = ctx.W, ctx.H
    ph = H // 2
    spks = list((ctx.plan.get("speakers") or {"a": {}}).keys())
    cv = Image.new("RGBA", (W, H), C(ctx.brand, "bg") + (255,))
    act = ctx.tl.speaker_at(t)
    panes = ctx.plan.get("panes")
    for i in range(2):
        if panes:
            pz = panes[i]
            img = ctx.main(t, W, ph, zoom=pz.get("zoom", 1.0), focus=pz.get("focus"))
            spk = pz.get("speaker", spks[min(i, len(spks) - 1)])
        elif len(spks) >= 2:
            spk = spks[i]
            f = ctx.plan["speakers"][spk].get("focus", (0.25 + 0.5 * i, 0.4))
            img = ctx.main(t, W, ph, zoom=1.0 + (0.03 if spk == act else 0), focus=f)
        else:
            spk = spks[0]
            img = ctx.main(t, W, ph, zoom=1.0 if i == 0 else 1.9)
        pane = img.convert("RGBA")
        is_act = (spk == act) if len(spks) >= 2 or panes else i == 1
        if not is_act:
            pane.alpha_composite(Image.new("RGBA", pane.size, (0, 0, 0, 70)))
        cv.alpha_composite(pane, (0, i * ph))
        if is_act and (len(spks) >= 2 or panes):
            ImageDraw.Draw(cv).rectangle((0, i * ph, W - 1, i * ph + ph - 1), outline=C(ctx.brand, "accent"), width=8)
        nm = ctx.spk_name(spk)
        if nm and (len(spks) >= 2 or panes):
            rise_in(cv, chip(nm, ctx.brand, "surface", 28), 60, i * ph + (ctx.top + 10 if i == 0 else 40), t, 0.3 + i * 0.15, "lt", 16)
    # seam line draws from center
    p = ease_out(prog(t, 0.1, 0.5))
    ImageDraw.Draw(cv).rectangle((W / 2 - W / 2 * p, ph - 3, W / 2 + W / 2 * p, ph + 3), fill=C(ctx.brand, "accent"))
    hook_block(cv, ctx, t, ctx.top + 20, 3.2, 80, box=True)
    ctx.caps("box", treatment="box", y=ph, size=64).render(cv, t)
    return cv

def s_letterbox(ctx, t):
    """16:9 picture on a breathing brand field, persistent headline above, captions below. Best for LinkedIn
    and low-res sources (no upscaling)."""
    W, H = ctx.W, ctx.H
    b = ctx.brand
    cv = canvas(ctx, t)
    img0, _ = ctx.src_frame(t)
    ar = clamp(img0.width / img0.height, 1.0, 16 / 9)
    cw = W - 80
    ch = int(cw / ar)
    top_pad = ctx.top if ctx.aspect == "9:16" else 60
    head_h = 330 if ctx.aspect == "9:16" else 300
    cy = top_pad + head_h + 30
    if ctx.aspect != "9:16":
        ch = min(ch, H - cy - 230); cw = int(ch * ar)
    show = b.get("show") or b.get("client")
    if show:
        rise_in(cv, chip(show, b, "accent", 26), W / 2, top_pad + 4, t, 0.0, "mt", 16)
    headline_staggered(cv, ctx, ctx.plan.get("headline") or ctx.hook(), W / 2, top_pad + 70, t, 0.1,
                       W - 120, 78 if ctx.aspect == "9:16" else 66, 3)
    p = ease_out(prog(t, 0.0, 0.5))
    zoom = 1.0 + 0.05 * ease_in_out(clamp(t / max(1, ctx.tl.speech)))
    x = (W - cw) / 2
    video_card(ctx, cv, t, x, cy + (1 - p) * 60, cw, ch, zoom=zoom)
    progress_bar(cv, ctx, t, x + 24, x + cw - 24, cy + ch - 26, 8)
    ctx.caps("kar", treatment="karaoke", y=int(cy + ch + (130 if ctx.aspect == "9:16" else 95)),
             size=72 if ctx.aspect == "9:16" else 60).render(cv, t)
    return cv

def s_post_card(ctx, t):
    """Platform-neutral post card states the take; the clip plays beneath. Uses the client's real name/face."""
    W, H = ctx.W, ctx.H
    b = ctx.brand
    cv = canvas(ctx, t)
    spk = list((ctx.plan.get("speakers") or {"a": {}}).keys())[0]
    key = "postcard"
    if key not in ctx.cache:
        av = None
        try:
            av = ctx.face_img(spk)
        except Exception:
            pass
        name = ctx.plan.get("post_name") or ctx.spk_name(spk) or b.get("client", "")
        ctx.cache[key] = post_card(ctx, ctx.plan.get("post") or ctx.hook(), name,
                                   b.get("handle", ""), av, W - 120, 50 if ctx.aspect == "9:16" else 44)
    card = ctx.cache[key]
    y0 = ctx.top if ctx.aspect == "9:16" else 50
    p = ease_out(prog(t, 0.0, 0.55))
    sh, pad = shadow_of(card, 24, 0.4)
    place(cv, sh, W / 2, y0 + card.height / 2 + 14 + (1 - p) * 40, "mm", 1, p)
    place(cv, card, W / 2, y0 + card.height / 2 + (1 - p) * 40, "mm", 1, min(1, p * 1.5))
    vy = y0 + card.height + 36
    img0, _ = ctx.src_frame(t)
    ar = clamp(img0.width / img0.height, 1.0, 16 / 9)
    cw = W - 120
    ch = min(int(cw / ar), (ctx.bottom - 150) - vy)
    cw = int(min(cw, ch * ar))
    q = ease_out(prog(t, 0.35, 0.5))
    video_card(ctx, cv, t, (W - cw) / 2, vy + (1 - q) * 50, cw, ch, zoom=1.0 + 0.04 * clamp(t / 30))
    ctx.caps("bar", treatment="bar", y=int(min(vy + ch + 95, H - 110)), size=46, max_w=W - 180).render(cv, t)
    return cv

def s_newsroom(ctx, t):
    """Editorial grammar: category chip, headline, lower third, citation. Brand's own system, never a network look."""
    W, H = ctx.W, ctx.H
    b = ctx.brand
    cv = ctx.main(t, W, H, zoom=1.0 + 0.03 * ease_in_out(clamp(t / max(1, ctx.tl.speech)))).convert("RGBA")
    cv.alpha_composite(scrim(W, H, 0, int(H * 0.42), 200, up=True))
    cv.alpha_composite(scrim(W, H, int(H * 0.55), H, 150))
    y = ctx.top if ctx.aspect == "9:16" else 60
    cat = ctx.plan.get("category", "ON THE JOB")
    L = chip(cat, b, "accent", 28)
    p = ease_out(prog(t, 0, 0.35))
    place(cv, L, 60 - (1 - p) * 60, y, "lt", 1, p)
    headline_staggered(cv, ctx, ctx.plan.get("headline") or ctx.hook(), 60, y + L.height + 18, t, 0.15, W - 150,
                       70 if ctx.aspect == "9:16" else 60, 3, align="left", anchor_x="l")
    spk = ctx.tl.speaker_at(t)
    sp = (ctx.plan.get("speakers") or {}).get(spk, {})
    if sp.get("name"):
        lt_y = int(H * (0.585 if ctx.aspect == "9:16" else 0.6))
        lower_third(cv, ctx, sp["name"], sp.get("title", ""), 60, lt_y, t, 1.2, 6.5)
    if ctx.plan.get("source_line"):
        sf = font(b["type"]["body"], 26)
        rise_in(cv, text_layer([ctx.plan["source_line"]], sf, C(b, "muted")), 60, ctx.bottom - 10, t, 1.0, "lb", 10)
    ctx.caps("box", treatment="box", y=int(H * (0.69 if ctx.aspect == "9:16" else 0.8)), size=62,
             case="sentence").render(cv, t)
    return cv

def s_listicle(ctx, t):
    """'3 signs...' numbered points build on their spoken cue over a brand panel; speaker below."""
    W, H = ctx.W, ctx.H
    b = ctx.brand
    split = int(H * 0.52)
    cv = canvas(ctx, t)
    vid = ctx.main(t, W, H - split, zoom=ctx.zoom(t) * 1.0).convert("RGBA")
    cv.alpha_composite(vid, (0, split))
    ImageDraw.Draw(cv).rectangle((0, split - 4, W * ease_out(prog(t, 0, 0.5)), split + 4), fill=C(b, "accent"))
    lb = next((x for x in ctx.plan.get("beats", []) if x["type"] == "list"), None)
    y0 = ctx.top if ctx.aspect == "9:16" else 50
    if lb:
        list_panel(cv, ctx, lb, t, 70, y0, W - 140, 104, 46 if ctx.aspect == "9:16" else 38)
        n = sum(1 for c in lb["cues"] if t >= c)
        if n:
            L = chip(f"{n}/{len(lb['items'])}", b, "surface", 26)
            place(cv, L, W - 70, y0 + 6, "rt")
    else:
        headline_staggered(cv, ctx, ctx.hook(), W / 2, y0 + 40, t, 0, W - 140, 80, 4)
    cv.alpha_composite(scrim(W, H, split, H, 140))
    ctx.caps("kar", treatment="karaoke", y=int(split + (H - split) * 0.55), size=66).render(cv, t)
    return cv

def s_linkedin_minimal(ctx, t):
    """Calm, professional: brand header bar with the thesis, sentence-case subtitle bar, progress bar. 4:5 default."""
    W, H = ctx.W, ctx.H
    b = ctx.brand
    hb = 200 if ctx.aspect != "9:16" else 430
    cv = Image.new("RGBA", (W, H), C(b, "bg") + (255,))
    vid = ctx.main(t, W, H - hb, zoom=1.0 + 0.04 * clamp(t / max(1, ctx.tl.speech))).convert("RGBA")
    cv.alpha_composite(vid, (0, hb))
    if ctx.texture is not None:
        cv.paste(ctx.texture.frame(t).crop((0, 0, W, hb)), (0, 0))
    ty = 36 if ctx.aspect != "9:16" else ctx.top + 10
    lg = brand_asset(b, "logo")
    maxw = W - (260 if lg is not None else 120)
    headline_staggered(cv, ctx, ctx.plan.get("headline") or ctx.hook(), 60, ty, t, 0.05, maxw, 54, 2,
                       align="left", anchor_x="l", upper=False)
    if lg is not None:
        s = 110 / lg.height
        L = lg.resize((int(lg.width * s), 110))
        rise_in(cv, L, W - 60 - L.width / 2, ty + 55, t, 0.3, "mm", 10)
    progress_bar(cv, ctx, t, 0, W, hb - 4, 8, track=(255, 255, 255, 40))
    ctx.caps("bar", treatment="bar", y=int(H - (170 if ctx.aspect != "9:16" else 560)), size=48, max_w=W - 200).render(cv, t)
    return cv

def s_signature(ctx, t):
    """The Oak Street look, generalized: breathing brand field, hook up top, rounded story picture,
    face bubbles for every speaker (active full size, other dims), speaker-colored karaoke captions."""
    W, H = ctx.W, ctx.H
    b = ctx.brand
    cv = canvas(ctx, t)
    headline_staggered(cv, ctx, ctx.plan.get("headline") or ctx.hook(), W / 2, ctx.top, t, 0.0, W - 120, 76, 2)
    img0, _ = ctx.src_frame(t)
    ar = clamp(img0.width / img0.height, 1.0, 16 / 9)
    cw = W - 80
    ch = int(cw / ar)
    y = ctx.top + 210
    p = ease_out(prog(t, 0.1, 0.5))
    video_card(ctx, cv, t, 40, y + (1 - p) * 60, cw, ch, zoom=ctx.zoom(t))
    spks = list((ctx.plan.get("speakers") or {"a": {}}).keys())
    act = ctx.tl.speaker_at(t)
    by = min(ctx.bottom - 90, y + ch + 330)
    if "faces" not in ctx.cache:
        ctx.cache["faces"] = {s: ctx.face_img(s) for s in spks}
    for i, s in enumerate(spks[:2]):
        side = (ctx.plan["speakers"][s].get("side") if ctx.plan.get("speakers") else None) or ("left" if i == 0 else "right")
        x = 170 if side == "left" else W - 170
        cap = ctx.caps("kar", treatment="karaoke", y=int(y + ch + 115), size=70, max_w=W - 140)
        face_bubble(cv, ctx.cache["faces"][s], x, by, 190, cap.spk_color(s), s == act or len(spks) == 1, t, 0.4 + i * 0.1,
                    pulse=bool(ctx.plan["speakers"][s].get("image")) if ctx.plan.get("speakers") else False)
    ctx.caps("kar", treatment="karaoke", y=int(y + ch + 115), size=70, max_w=W - 140).render(cv, t)
    return cv

def s_screen_top(ctx, t):
    """Content on top (slide, listing, job photo, screen), speaker below; captions on the seam."""
    W, H = ctx.W, ctx.H
    b = ctx.brand
    cv = canvas(ctx, t)
    y0 = ctx.top if ctx.aspect == "9:16" else 40
    content = ctx.plan.get("content")
    ch = int((W - 80) * 9 / 16)
    if content:
        key = "content_src"
        if key not in ctx.cache:
            ctx.cache[key] = Source(content, ctx.fps)
        img = cover(ctx.cache[key].frame(t), W - 80, ch, (0.5, 0.5), 1.0 + 0.1 * ease_in_out(clamp(t / 20)))
        card = mask_round(img.convert("RGBA"), b["style"]["radius"])
        rise_in(cv, card, W / 2, y0 + 60, t, 0.0, "mt", 40)
    else:
        video_card(ctx, cv, t, 40, y0 + 60, W - 80, ch, zoom=1.0, focus=(0.5, 0.5))
    lab = ctx.plan.get("content_label", "")
    if lab:
        rise_in(cv, chip(lab, b, "accent", 26), 60, y0, t, 0.2, "lt", 16)
    split = int(H * 0.5)
    vid = ctx.main(t, W, H - split, zoom=1.6).convert("RGBA")
    cv.alpha_composite(vid, (0, split))
    ImageDraw.Draw(cv).rectangle((0, split - 3, W, split + 3), fill=C(b, "accent"))
    ctx.caps("box", treatment="box", y=split, size=62).render(cv, t)
    return cv

STYLES = {
    "bold-pop":         dict(fn=s_bold_pop, aspects=["9:16", "4:5"], family="full-bleed face, word-pop captions"),
    "podcast-cut":      dict(fn=s_podcast_cut, aspects=["9:16", "4:5"], family="active-speaker cuts + payoff banner"),
    "split-stack":      dict(fn=s_split_stack, aspects=["9:16"], family="two stacked panes, seam captions"),
    "letterbox":        dict(fn=s_letterbox, aspects=["9:16", "4:5", "1:1"], family="16:9 on brand field + headline"),
    "post-card":        dict(fn=s_post_card, aspects=["9:16", "4:5"], family="text post card over clip"),
    "newsroom":         dict(fn=s_newsroom, aspects=["9:16", "4:5"], family="chip + headline + lower third"),
    "listicle":         dict(fn=s_listicle, aspects=["9:16", "4:5"], family="numbered build over brand panel"),
    "linkedin-minimal": dict(fn=s_linkedin_minimal, aspects=["4:5", "9:16", "1:1"], family="header bar + subtitle bar"),
    "signature":        dict(fn=s_signature, aspects=["9:16"], family="brand field, story card, face bubbles"),
    "screen-top":       dict(fn=s_screen_top, aspects=["9:16", "4:5"], family="content on top, speaker below"),
}

# ================================================================ beats on top of any style
def before_after_beat(cv, ctx, bt, t):
    t0, dur = bt["t"], bt.get("dur", 3.0)
    if not (t0 - 0.05 <= t <= t0 + dur):
        return
    W, H = ctx.W, ctx.H
    key = ("ba", bt["before"], bt["after"])
    if key not in ctx.cache:
        ctx.cache[key] = (Source(bt["before"], ctx.fps), Source(bt["after"], ctx.fps))
    sb, sa = ctx.cache[key]
    lt = t - t0
    bimg = cover(sb.frame(bt.get("before_t", 0) + lt), W, H).convert("RGBA")
    aimg = cover(sa.frame(bt.get("after_t", 0) + lt), W, H, zoom=lerp(1.0, 1.06, prog(lt, 0.8, dur))).convert("RGBA")
    fade = min(prog(lt, 0, 0.15), 1 - prog(lt, dur - 0.2, 0.2))
    wipe = ease_in_out(prog(lt, bt.get("wipe_at", 0.9), bt.get("wipe", 1.4)))
    x = int(W * wipe)
    frame = bimg.copy()
    if x > 0:
        frame.paste(aimg.crop((0, 0, x, H)), (0, 0))
    d = ImageDraw.Draw(frame)
    if 0 < wipe < 1:
        d.rectangle((x - 3, 0, x + 3, H), fill=(255, 255, 255))
        d.ellipse((x - 34, H / 2 - 34, x + 34, H / 2 + 34), fill=C(ctx.brand, "accent"), outline=(255, 255, 255), width=5)
    frame.putalpha(int(255 * fade))
    cv.alpha_composite(frame)
    b = ctx.brand
    lb = chip(bt.get("before_label", "BEFORE"), b, "surface", 34)
    la = chip(bt.get("after_label", "AFTER"), b, "accent", 34)
    y = ctx.top + 10
    if wipe < 0.5:
        pop_in(cv, lb, 60 + lb.width / 2, y + lb.height / 2, lt, 0.1, fade_out_at=bt.get("wipe_at", 0.9) + 0.5)
    else:
        pop_in(cv, la, W - 60 - la.width / 2, y + la.height / 2, lt, bt.get("wipe_at", 0.9) + 0.6, fade_out_at=dur - 0.25)
    if bt.get("spec"):
        f, ls = fit_font(bt["spec"], b["type"]["body"], 44, W - 200, 2)
        L = text_layer(ls, f, C(b, "text"))
        bx = rounded((L.width + 50, L.height + 30), 16, (0, 0, 0, 170))
        bx.alpha_composite(L, (25, 15))
        rise_in(cv, bx, W / 2, ctx.bottom - 60, lt, bt.get("wipe_at", 0.9) + 1.0, "mb", 20, fade_out_at=dur - 0.25)

def list_takeover(cv, ctx, bt, t):
    t0, dur = bt["t"], bt.get("dur", 4.0)
    if not (t0 - 0.05 <= t <= t0 + dur):
        return
    fade = min(prog(t, t0, 0.2), 1 - prog(t, t0 + dur - 0.25, 0.25))
    cv.alpha_composite(Image.new("RGBA", cv.size, C(ctx.brand, "bg") + (int(225 * fade),)))
    if fade > 0.5:
        list_panel(cv, ctx, dict(bt, title_t=t0), t, 80, ctx.top + 40, ctx.W - 160)

def apply_beats(cv, ctx, t):
    for bt in ctx.plan.get("beats", []):
        if bt["type"] == "stat":
            stat_beat(cv, ctx, bt, t)
        elif bt["type"] == "before_after":
            before_after_beat(cv, ctx, bt, t)
        elif bt["type"] == "list_takeover":
            list_takeover(cv, ctx, bt, t)

def render_frame(ctx, style, t):
    fn = STYLES[style]["fn"]
    ts = min(t, ctx.tl.speech - 1.0 / ctx.fps)
    if t >= ctx.tl.speech and "last_frame" in ctx.cache:
        cv = ctx.cache["last_frame"].copy()
    else:
        cv = fn(ctx, ts)
        apply_beats(cv, ctx, ts)
        if t >= ctx.tl.speech - 1.5 / ctx.fps:
            ctx.cache["last_frame"] = cv.copy()
    if t >= ctx.tl.speech and ctx.plan.get("end_card", True):
        if "end_bg" not in ctx.cache:
            ctx.cache["end_bg"] = ctx.src_frame(ctx.tl.speech * 0.5)[0]
            spk = list((ctx.plan.get("speakers") or {}).keys())
            ctx.cache["end_faces"] = [(ctx.face_img(s), ctx.spk_name(s)) for s in spk[:2]
                                      if ctx.plan["speakers"][s].get("end_card", True) and ctx.spk_name(s)]
        end_card(cv, ctx, t, ctx.cache["end_bg"], ctx.cache["end_faces"])
    return cv
