"""clipkit core: fonts, brand, easing, text layers, video sources, timeline, audio, encoding.

Everything here is portable: no hard-coded user paths. Works with the stock
/usr/bin/python3 on macOS (numpy + Pillow) and on Linux.
"""
import json, math, os, shutil, subprocess
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

SKILL_DIR = Path(__file__).resolve().parents[2]
FFMPEG = shutil.which("ffmpeg") or "/opt/homebrew/bin/ffmpeg"
FFPROBE = shutil.which("ffprobe") or "/opt/homebrew/bin/ffprobe"

# ---------------------------------------------------------------- easing
def clamp(x, a=0.0, b=1.0):
    return a if x < a else b if x > b else x

def prog(t, start, dur):
    """0..1 progress of an animation that starts at `start` and lasts `dur`."""
    return clamp((t - start) / dur) if dur > 0 else float(t >= start)

def ease_out(p):  # cubic
    p = clamp(p); return 1 - (1 - p) ** 3

def ease_in_out(p):
    p = clamp(p); return 3 * p * p - 2 * p * p * p

def ease_back(p, s=1.7):  # overshoot then settle
    p = clamp(p) - 1; return 1 + p * p * ((s + 1) * p + s)

def lerp(a, b, p):
    return a + (b - a) * p

# ---------------------------------------------------------------- color
def rgb(c, alpha=None):
    if isinstance(c, (tuple, list)):
        t = tuple(int(v) for v in c)
    else:
        c = c.lstrip("#")
        t = tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))
    if alpha is None:
        return t[:3] if len(t) >= 3 else t
    return t[:3] + (int(alpha),)

def mix(c1, c2, p):
    a, b = rgb(c1), rgb(c2)
    return tuple(int(lerp(a[i], b[i], p)) for i in range(3))

def luminance(c):
    r, g, b = [v / 255 for v in rgb(c)]
    f = lambda v: v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)

def readable_on(bg, light="#FFFFFF", dark="#111111"):
    return light if luminance(bg) < 0.4 else dark

# ---------------------------------------------------------------- fonts
FONT_DIRS = [SKILL_DIR / "fonts", Path.home() / "Library/Fonts", Path("/Library/Fonts"),
             Path("/System/Library/Fonts/Supplemental"), Path("/System/Library/Fonts"),
             Path("/usr/share/fonts"), Path("/usr/local/share/fonts")]
_font_index, _font_cache = None, {}

def _index_fonts():
    global _font_index
    if _font_index is None:
        _font_index = {}
        for d in FONT_DIRS:
            if d.exists():
                for p in d.rglob("*"):
                    if p.suffix.lower() in (".ttf", ".otf", ".ttc"):
                        _font_index.setdefault(p.stem.lower().replace(" ", ""), str(p))
    return _font_index

def font_path(name):
    """Resolve 'Anton', 'Inter-Black', 'Rockwell.ttc#2' or a path to a font file."""
    if not name:
        name = "Inter-Black"
    idx = 0
    if "#" in name:
        name, i = name.split("#"); idx = int(i)
    if os.path.exists(name):
        return name, idx
    key = name.lower().replace(" ", "")
    ix = _index_fonts()
    if key in ix:
        return ix[key], idx
    for k in sorted(ix):  # 'anton' -> 'anton-regular'
        if k.startswith(key):
            return ix[k], idx
    return ix.get("inter-black") or next(iter(ix.values())), 0

def font(name, size):
    k = (name, int(size))
    if k not in _font_cache:
        p, idx = font_path(name)
        _font_cache[k] = ImageFont.truetype(p, int(size), index=idx)
    return _font_cache[k]

# ---------------------------------------------------------------- brand
DEFAULT_STYLE = {"energy": "standard", "radius": 26, "texture": "contours", "caption_case": "upper",
                 "caption_stroke": 0, "caption_shadow": True}

def load_brand(path):
    path = Path(path)
    b = json.loads(path.read_text())
    b["_dir"] = str(path.parent)
    roles = b.setdefault("roles", {})
    cols = b.get("colors", {})
    first = list(cols.values())
    roles.setdefault("bg", first[0] if first else "#111827")
    roles.setdefault("surface", first[1] if len(first) > 1 else "#1F2937")
    roles.setdefault("accent", first[2] if len(first) > 2 else "#F59E0B")
    roles.setdefault("accent2", roles["accent"])
    roles.setdefault("text", "#FFFFFF")
    roles.setdefault("ink", "#111111")
    roles.setdefault("paper", "#FFFFFF")
    roles.setdefault("muted", "#9CA3AF")
    f = b.setdefault("type", {})
    f.setdefault("display", "Anton")
    f.setdefault("headline", f["display"])
    f.setdefault("caption", "Montserrat-Black")
    f.setdefault("body", "Inter-SemiBold")
    f.setdefault("number", f["headline"])
    s = b.setdefault("style", {})
    for k, v in DEFAULT_STYLE.items():
        s.setdefault(k, v)
    b.setdefault("end_card", {}).setdefault("follow_line", "Follow for more")
    return b

def brand_asset(brand, key):
    """Open a brand image (logo etc.) by key in brand['assets'] or top-level; None if missing."""
    rel = (brand.get("assets") or {}).get(key) or brand.get(key)
    if isinstance(rel, dict):
        rel = rel.get("logo")
    if not rel:
        return None
    p = Path(brand["_dir"]) / rel
    return Image.open(p).convert("RGBA") if p.exists() else None

def C(brand, role):
    return rgb(brand["roles"].get(role) or brand.get("colors", {}).get(role) or role)

# ---------------------------------------------------------------- text + layers
def wrap(text, fnt, max_w):
    lines, line = [], ""
    for word in text.split():
        test = (line + " " + word).strip()
        if line and fnt.getlength(test) > max_w:
            lines.append(line); line = word
        else:
            line = test
    if line:
        lines.append(line)
    return lines

def fit_font(text, name, size, max_w, max_lines=2, min_size=28):
    """Largest size <= size so text wraps into <= max_lines within max_w."""
    s = size
    while s > min_size:
        f = font(name, s)
        ls = wrap(text, f, max_w)
        if len(ls) <= max_lines and all(f.getlength(l) <= max_w for l in ls):
            return f, ls
        s -= 4
    f = font(name, min_size)
    return f, wrap(text, f, max_w)

def text_layer(lines, fnt, fill, align="center", spacing=1.08, stroke=0, stroke_fill=(0, 0, 0),
               shadow=None, pad=None, highlights=None):
    """Render lines to a tight RGBA layer. highlights: {word_lower: color} recolors whole words."""
    if isinstance(lines, str):
        lines = [lines]
    asc, desc = fnt.getmetrics()
    lh = int((asc + desc) * spacing)
    pad = pad if pad is not None else stroke + (int(fnt.size * 0.12) if shadow else 0) + 4
    w = int(max(fnt.getlength(l) for l in lines)) + 2 * pad
    h = lh * len(lines) + 2 * pad
    img = Image.new("RGBA", (max(w, 2), max(h, 2)), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for i, l in enumerate(lines):
        lw = fnt.getlength(l)
        x = pad + (0 if align == "left" else (w - 2 * pad - lw) / 2 if align == "center" else w - 2 * pad - lw)
        y = pad + i * lh
        words = l.split(" ")
        cx = x
        for wi, word in enumerate(words):
            col = fill
            if highlights:
                key = word.lower().strip(".,!?:;\"'")
                col = highlights.get(key, fill)
            if shadow:
                off = max(2, int(fnt.size * 0.06))
                d.text((cx + off, y + off), word, font=fnt, fill=shadow)
            d.text((cx, y), word, font=fnt, fill=col, stroke_width=stroke, stroke_fill=stroke_fill)
            cx += fnt.getlength(word + " ")
    if shadow and not stroke:
        pass
    return img

def rounded(size, radius, fill):
    img = Image.new("RGBA", (int(size[0]), int(size[1])), (0, 0, 0, 0))
    ImageDraw.Draw(img).rounded_rectangle((0, 0, size[0] - 1, size[1] - 1), radius=int(radius), fill=fill)
    return img

def mask_round(img, radius):
    m = Image.new("L", img.size, 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, img.size[0] - 1, img.size[1] - 1), radius=int(radius), fill=255)
    out = img.convert("RGBA"); out.putalpha(m); return out

def circle_crop(img, d):
    img = img.convert("RGB").resize((d, d), Image.BILINEAR)
    m = Image.new("L", (d * 2, d * 2), 0)
    ImageDraw.Draw(m).ellipse((0, 0, d * 2 - 1, d * 2 - 1), fill=255)
    m = m.resize((d, d), Image.LANCZOS)
    out = img.convert("RGBA"); out.putalpha(m); return out

def place(canvas, layer, x, y, anchor="mm", scale=1.0, alpha=1.0, rot=0.0):
    """Alpha-composite `layer` onto canvas. anchor: 'mm' center, 'lt' top-left, 'mt' top-center, 'mb', 'lb'."""
    if layer is None or alpha <= 0.003 or scale <= 0.01:
        return
    L = layer
    if abs(scale - 1) > 0.002:
        L = L.resize((max(1, int(L.width * scale)), max(1, int(L.height * scale))), Image.BILINEAR)
    if rot:
        L = L.rotate(rot, resample=Image.BICUBIC, expand=True)
    if alpha < 0.999:
        a = L.getchannel("A").point(lambda v: int(v * alpha))
        L = L.copy(); L.putalpha(a)
    w, h = L.size
    ox = {"l": 0, "m": w / 2, "r": w}[anchor[0]]
    oy = {"t": 0, "m": h / 2, "b": h}[anchor[1]]
    canvas.alpha_composite(L, (int(round(x - ox)), int(round(y - oy)))) if _inside(canvas, L, x - ox, y - oy) else \
        _composite_clipped(canvas, L, int(round(x - ox)), int(round(y - oy)))

def _inside(c, L, x, y):
    return x >= 0 and y >= 0 and x + L.width <= c.width and y + L.height <= c.height

def _composite_clipped(canvas, L, x, y):
    x0, y0 = max(0, x), max(0, y)
    x1, y1 = min(canvas.width, x + L.width), min(canvas.height, y + L.height)
    if x1 <= x0 or y1 <= y0:
        return
    canvas.alpha_composite(L.crop((x0 - x, y0 - y, x1 - x, y1 - y)), (x0, y0))

def shadow_of(layer, blur=18, opacity=0.35, grow=0):
    a = layer.getchannel("A")
    pad = blur * 2 + grow
    sh = Image.new("RGBA", (layer.width + 2 * pad, layer.height + 2 * pad), (0, 0, 0, 0))
    m = Image.new("L", sh.size, 0); m.paste(a, (pad, pad))
    m = m.filter(ImageFilter.GaussianBlur(blur)).point(lambda v: int(v * opacity))
    sh.putalpha(m)
    return sh, pad

# ---------------------------------------------------------------- crops
def cover(img, out_w, out_h, focus=(0.5, 0.5), zoom=1.0):
    """Crop img to out_w:out_h around focus (normalized), zoom>1 crops tighter; returns resized RGB."""
    W, H = img.size
    ar = out_w / out_h
    cw, ch = (H * ar, H) if W / H > ar else (W, W / ar)
    cw, ch = cw / zoom, ch / zoom
    cx = clamp(focus[0] * W, cw / 2, W - cw / 2)
    cy = clamp(focus[1] * H, ch / 2, H - ch / 2)
    box = (int(cx - cw / 2), int(cy - ch / 2), int(cx + cw / 2), int(cy + ch / 2))
    return img.crop(box).resize((int(out_w), int(out_h)), Image.BILINEAR)

def contain(img, out_w, out_h):
    W, H = img.size
    s = min(out_w / W, out_h / H)
    return img.resize((int(W * s), int(H * s)), Image.BILINEAR)

def blurred_bg(img, W, H, darken=0.55, blur=10):
    small = cover(img, max(8, W // 12), max(8, H // 12))
    small = small.filter(ImageFilter.GaussianBlur(blur / 3))
    big = small.resize((W, H), Image.BILINEAR).convert("RGBA")
    if darken:
        big.alpha_composite(Image.new("RGBA", (W, H), (0, 0, 0, int(255 * darken))))
    return big

# ---------------------------------------------------------------- video sources
def probe(path):
    out = subprocess.run([FFPROBE, "-v", "error", "-select_streams", "v:0", "-show_entries",
                          "stream=width,height,r_frame_rate:format=duration", "-of", "json", path],
                         capture_output=True, text=True).stdout
    j = json.loads(out)
    s = j["streams"][0]
    num, den = s["r_frame_rate"].split("/")
    return int(s["width"]), int(s["height"]), float(num) / float(den), float(j["format"]["duration"])

class Source:
    """Sequential frame reader with seek-on-jump. Images are supported as static sources."""
    def __init__(self, path, fps=30, max_w=1920):
        self.path, self.fps = str(path), fps
        self.is_image = Path(path).suffix.lower() in (".png", ".jpg", ".jpeg", ".webp")
        if self.is_image:
            self.img = Image.open(path).convert("RGB")
            self.w, self.h = self.img.size
            return
        w, h, _, self.duration = probe(self.path)
        s = min(1.0, max_w / w)
        self.w, self.h = (int(w * s) // 2) * 2, (int(h * s) // 2) * 2
        self.proc, self.t, self.last = None, None, None

    def _open(self, t):
        if self.proc:
            self.proc.kill()
        self.proc = subprocess.Popen([FFMPEG, "-v", "error", "-ss", f"{max(0, t):.3f}", "-i", self.path,
                                      "-vf", f"fps={self.fps},scale={self.w}:{self.h}", "-f", "rawvideo",
                                      "-pix_fmt", "rgb24", "-"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=10 ** 8)
        self.t, self.last = max(0, t) - 1 / self.fps, None

    def _read(self):
        n = self.w * self.h * 3
        buf = self.proc.stdout.read(n)
        if len(buf) < n:
            return self.last
        self.t += 1 / self.fps
        self.last = Image.frombytes("RGB", (self.w, self.h), buf)
        return self.last

    def frame(self, t):
        if self.is_image:
            return self.img
        t = clamp(t, 0, self.duration - 1 / self.fps)
        if self.proc is None or t < self.t - 0.5 / self.fps or t > self.t + 2.0:
            self._open(t)
        while self.t < t - 0.5 / self.fps or self.last is None:
            if self._read() is None:
                break
        return self.last

    def close(self):
        if not self.is_image and self.proc:
            self.proc.kill()

# ---------------------------------------------------------------- transcript + timeline
def load_words(path):
    j = json.loads(Path(path).read_text())
    if isinstance(j, dict) and "segments" in j:
        ws = [w for s in j["segments"] for w in s.get("words", [])]
    elif isinstance(j, dict) and "words" in j:
        ws = j["words"]
    else:
        ws = j
    out = []
    for w in ws:
        txt = (w.get("word") or w.get("w") or w.get("text") or "").strip()
        s = w.get("start", w.get("s")); e = w.get("end", w.get("e"))
        if txt and s is not None and e is not None:
            out.append({"w": txt, "s": float(s), "e": float(e)})
    return out

class Timeline:
    """Maps output time <-> (segment, source time). Segments are in transcript time."""
    def __init__(self, plan, words):
        self.segs, t0 = [], 0.0
        for k, sg in enumerate(plan["segments"]):
            a, b = float(sg["in"]), float(sg["out"])
            self.segs.append(dict(sg, k=k, a=a, b=b, t0=t0, t1=t0 + b - a))
            t0 += b - a
        self.speech = t0
        self.tail = float(plan.get("end_card_seconds", 3.2 if plan.get("end_card", True) else 0.4))
        self.duration = self.speech + self.tail
        self.words = []
        for s in self.segs:
            for w in words:
                mid = (w["s"] + w["e"]) / 2
                if s["a"] - 0.02 <= mid <= s["b"] + 0.02:
                    self.words.append({"w": w["w"], "s": max(s["t0"], w["s"] - s["a"] + s["t0"]),
                                       "e": min(s["t1"], w["e"] - s["a"] + s["t0"]),
                                       "spk": s.get("speaker", "a"), "seg": s["k"]})

    def seg_at(self, t):
        for s in self.segs:
            if t < s["t1"]:
                return s
        return self.segs[-1]

    def src_time(self, t):
        s = self.seg_at(t)
        return s, s["a"] + clamp(t - s["t0"], 0, s["b"] - s["a"])

    def speaker_at(self, t):
        return self.seg_at(min(t, self.speech - 1e-3)).get("speaker", "a")

    def cut_times(self):
        return [s["t0"] for s in self.segs[1:]]

# ---------------------------------------------------------------- audio + encode
def build_audio(plan, tl, sources, out_wav, loudnorm=True):
    """atrim each segment inside the filter graph (never -ss + afade), short fades, pad for end card."""
    paths = []
    for s in tl.segs:
        p = sources[s.get("src", "main")]["path"]
        if p not in paths:
            paths.append(p)
    args = [FFMPEG, "-v", "error", "-y"]
    for p in paths:
        args += ["-i", p]
    fl, labels = [], []
    for s in tl.segs:
        src = sources[s.get("src", "main")]
        i = paths.index(src["path"])
        a, b = s["a"] - src.get("offset", 0), s["b"] - src.get("offset", 0)
        d = b - a
        fi, fo = s.get("fade_in", 0.02), s.get("fade_out", 0.03)
        fl.append(f"[{i}:a]atrim=start={a:.3f}:end={b:.3f},asetpts=PTS-STARTPTS,aformat=sample_rates=48000:channel_layouts=stereo,"
                  f"afade=t=in:st=0:d={fi},afade=t=out:st={max(0, d - fo):.3f}:d={fo}[s{s['k']}]")
        labels.append(f"[s{s['k']}]")
    fl.append("".join(labels) + f"concat=n={len(labels)}:v=0:a=1[cat]")
    post = f"apad=whole_dur={tl.duration:.3f}"
    if loudnorm:
        post = "loudnorm=I=-14:TP=-1.5:LRA=11," + post
    fl.append(f"[cat]{post}[out]")
    args += ["-filter_complex", ";".join(fl), "-map", "[out]", "-ar", "48000", "-t", f"{tl.duration:.3f}", out_wav]
    subprocess.run(args, check=True)

class Encoder:
    def __init__(self, out, W, H, fps, audio=None, crf=18):
        args = [FFMPEG, "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}",
                "-r", str(fps), "-i", "-"]
        if audio:
            args += ["-i", audio, "-c:a", "aac", "-b:a", "192k", "-shortest"]
        args += ["-c:v", "libx264", "-preset", "medium", "-crf", str(crf), "-pix_fmt", "yuv420p",
                 "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709",
                 "-movflags", "+faststart", out]
        self.p = subprocess.Popen(args, stdin=subprocess.PIPE)

    def write(self, img):
        self.p.stdin.write(img.convert("RGB").tobytes())

    def close(self):
        self.p.stdin.close(); self.p.wait()
