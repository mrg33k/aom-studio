#!/usr/bin/env python3
"""Find free, commercial-use images for clip beats (no account or API key needed).

usage: /usr/bin/python3 find_images.py "search words" OUT_DIR [--n 8]

Searches Openverse (Flickr, Wikimedia and 50+ other sources) and Wikimedia Commons.
Keeps only licenses OK for commercial client work: CC0, public domain, CC BY, CC BY-SA.
(BY / BY-SA need a credit line; it's saved per image.)
Writes OUT_DIR/<n>.jpg (1600px wide max), OUT_DIR/credits.json, and OUT_DIR/sheet.jpg to pick from.
Rules for client clips: no logos/trademarks, no identifiable strangers' faces, prefer >= 1000px.
"""
import json, os, re, sys, urllib.parse, urllib.request, io
from PIL import Image, ImageDraw, ImageFont

UA = {"User-Agent": "AOM-clip/0.3 (hello@aom-inhouse.com)"}
q, out = sys.argv[1], sys.argv[2]
n = int(sys.argv[sys.argv.index("--n") + 1]) if "--n" in sys.argv else 8
os.makedirs(out, exist_ok=True)
OK = {"cc0", "pdm", "by", "by-sa"}

def get(url):
    return urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=30).read()
def strip(html): return re.sub("<[^>]+>", "", html or "").strip()

cands = []
try:
    d = json.loads(get("https://api.openverse.org/v1/images/?" + urllib.parse.urlencode(
        {"q": q, "license": ",".join(OK), "page_size": 20, "mature": "false"})))
    for r in d.get("results", []):
        if (r.get("width") or 0) < 900: continue
        cands.append({"src": "openverse", "title": r["title"], "url": r["url"], "license": r["license"],
                      "license_version": r.get("license_version", ""), "creator": r.get("creator") or "unknown",
                      "page": r.get("foreign_landing_url"), "w": r.get("width"), "h": r.get("height")})
except Exception as e:
    print("openverse failed:", e)
try:
    d = json.loads(get("https://commons.wikimedia.org/w/api.php?" + urllib.parse.urlencode(
        {"action": "query", "generator": "search", "gsrsearch": q + " filetype:bitmap", "gsrnamespace": 6, "gsrlimit": 15,
         "prop": "imageinfo", "iiprop": "url|extmetadata|size", "iiurlwidth": 1600, "format": "json"})))
    for p in d.get("query", {}).get("pages", {}).values():
        ii = p["imageinfo"][0]; m = ii.get("extmetadata", {})
        lic = (m.get("LicenseShortName", {}).get("value") or "").lower()
        key = "cc0" if "cc0" in lic else "pdm" if "public domain" in lic else "by-sa" if "by-sa" in lic else "by" if re.search(r"cc by\b|cc-by\b|cc by \d", lic) else None
        if not key or ii["width"] < 900: continue
        cands.append({"src": "wikimedia", "title": p["title"].replace("File:", ""), "url": ii.get("thumburl") or ii["url"], "license": key,
                      "license_version": m.get("LicenseShortName", {}).get("value", ""), "creator": strip(m.get("Artist", {}).get("value")) or "unknown",
                      "page": ii.get("descriptionurl"), "w": ii["width"], "h": ii["height"]})
except Exception as e:
    print("wikimedia failed:", e)

# relevance: title must share a real word with the query; interleave sources in their own relevance order
qw = [w for w in re.findall(r"[a-z0-9]+", q.lower()) if len(w) > 3 or w.isdigit()]
PEOPLE = re.compile(r"\b(portrait|man|woman|boy|girl|worker|irrigator|family|children|mr|mrs)\b", re.I)
def relevant(c):
    t = c["title"].lower()
    return any(w in t for w in qw) and not PEOPLE.search(c["title"])
ov = [c for c in cands if c["src"] == "openverse" and relevant(c)]; wm = [c for c in cands if c["src"] == "wikimedia" and relevant(c)]
mixed = [x for pair in zip(ov, wm) for x in pair] + ov[len(wm):] + wm[len(ov):]
seen, cands = set(), []
for c in mixed:
    stem = re.sub(r"\.(jpe?g|png|tiff?|webp)$", "", c["title"].lower()).strip()
    if stem in seen: continue
    seen.add(stem); cands.append(c)
saved = []
for c in cands:
    if len(saved) >= n: break
    try:
        im = Image.open(io.BytesIO(get(c["url"]))).convert("RGB")
    except Exception:
        continue
    if im.width > 1600: im = im.resize((1600, int(im.height * 1600 / im.width)), Image.LANCZOS)
    k = len(saved) + 1; fn = os.path.join(out, f"{k}.jpg"); im.save(fn, quality=92)
    lic = c["license"]
    c["credit"] = "" if lic in ("cc0", "pdm") else f"Photo: {c['creator']}, CC {lic.upper()} {c['license_version'].split()[-1] if c['license_version'] else ''}".strip()
    c["file"] = fn; saved.append(c)
    print(f"{k}. [{lic}] {im.width}x{im.height} {c['title'][:60]}  {c['credit']}")
json.dump(saved, open(os.path.join(out, "credits.json"), "w"), indent=1)
if saved:  # numbered contact sheet
    th = [Image.open(c["file"]) for c in saved]; th = [t.resize((int(t.width * 260 / t.height), 260)) for t in th]
    sheet = Image.new("RGB", (sum(t.width for t in th) + 10 * len(th), 300), "white"); x = 0; d_ = ImageDraw.Draw(sheet)
    for k, t in enumerate(th):
        sheet.paste(t, (x, 0)); d_.text((x + 6, 268), f"{k + 1}. {saved[k]['license']}", fill="black"); x += t.width + 10
    sheet.save(os.path.join(out, "sheet.jpg"))
