#!/usr/bin/env python3
"""Stitch the audio for a cut list and re-transcribe it, to prove no word got clipped.

usage: /usr/bin/python3 check_cuts.py SOURCE_MEDIA CUTS.json OUT_PREFIX
Writes OUT_PREFIX.wav (48k stereo, 20 ms fades, no fade across back-to-back segments) and prints
planned text vs heard text per segment and for the whole stitch.
"""
import json, subprocess, sys, re, os

src, cuts_p, pre = sys.argv[1:4]
cuts = json.load(open(cuts_p))
parts = []
for k, c in enumerate(cuts):
    a, b = c["a"], c["b"]
    joined_prev = k > 0 and abs(cuts[k - 1]["b"] - a) < 0.03
    joined_next = k + 1 < len(cuts) and abs(cuts[k + 1]["a"] - b) < 0.03
    af = f"atrim={a:.3f}:{b:.3f},asetpts=PTS-STARTPTS"
    if not joined_prev: af += ",afade=t=in:d=0.02"
    if not joined_next: af += f",afade=t=out:st={b - a - 0.02:.3f}:d=0.02"
    fn = f"{pre}_p{k}.wav"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", src, "-vn", "-af", af, "-ar", "48000", "-ac", "2", fn], check=True)
    parts.append(fn)
lst = f"{pre}_list.txt"
open(lst, "w").write("".join(f"file '{os.path.abspath(p)}'\n" for p in parts))
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", lst, f"{pre}.wav"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{pre}.wav", "-ac", "1", "-ar", "16000", f"{pre}_16k.wav"], check=True)
subprocess.run(["mlx_whisper", f"{pre}_16k.wav", "--model", "mlx-community/whisper-large-v3-turbo",
                "--condition-on-previous-text", "False", "--output-format", "txt", "--output-dir", os.path.dirname(os.path.abspath(pre))],
               capture_output=True)
heard = open(f"{pre}_16k.txt").read().strip()
planned = " ".join(w["w"] for c in cuts for w in c["words"])
norm = lambda s: re.sub(r"[^a-z0-9 ]", "", s.lower().replace("-", " ").replace("\n", " ")).split()
print("PLANNED:", planned)
print("HEARD:  ", heard)
p, h = norm(planned), norm(heard)
missing = [w for w in p if w not in h]
extra = [w for w in h if w not in p]
print("missing words:", missing or "none")
print("extra words:  ", extra or "none")
