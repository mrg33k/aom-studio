#!/usr/bin/env python3
"""Moment map: the transcript as numbered sentences, each tagged with how it was SAID (energy, pitch,
pace vs the speaker's own baseline), whether it is a safe place to cut in/out, and optional emotion labels.
This is what Claude reads in pipeline step 4 (emotional highs/lows + audience lens).

  python3 moment_map.py MEDIA TRANSCRIPT.json [--offset 0] [--out moment_map] [--emotion]

MEDIA: video or audio. TRANSCRIPT: whisper/whisperX json (word timestamps). --offset: transcript time of
media t=0. Writes moment_map.json + moment_map.md. --emotion runs emotion2vec+ (pip install funasr modelscope;
weights download once) if available; otherwise it is skipped with a note.

Audio numbers are HINTS for where a story peaks, never a reason to drop a calm, high-value moment.
"""
import argparse, json, subprocess, shutil, sys
from pathlib import Path
import numpy as np

SR = 16000
HOP = 160  # 10 ms
DANGLING = {"and", "the", "a", "an", "but", "so", "to", "of", "because", "or", "with", "for", "in", "that", "is"}
CONNECTIVES = {"and", "so", "but", "because", "or", "then", "also", "which"}

def load_audio(path):
    ff = shutil.which("ffmpeg") or "/opt/homebrew/bin/ffmpeg"
    raw = subprocess.run([ff, "-v", "error", "-i", path, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"],
                         capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32)

def words_of(tj):
    j = json.load(open(tj))
    ws = [w for s in j["segments"] for w in s.get("words", [])] if "segments" in j else j.get("words", j)
    out = []
    for w in ws:
        t = (w.get("word") or w.get("w") or "").strip()
        if t:
            out.append({"w": t, "s": float(w.get("start", w.get("s"))), "e": float(w.get("end", w.get("e"))),
                        "spk": w.get("speaker", w.get("spk", "?"))})
    return out

def sentences(ws):
    out, cur = [], []
    for i, w in enumerate(ws):
        cur.append(w)
        nxt = ws[i + 1] if i + 1 < len(ws) else None
        gap = (nxt["s"] - w["e"]) if nxt else 9
        end_p = w["w"][-1:] in ".?!"
        spk_change = nxt is not None and nxt["spk"] != w["spk"]
        if nxt is None or end_p or spk_change or (gap > 0.7 and w["w"].lower().strip(",.") not in DANGLING):
            out.append(cur); cur = []
    res = []
    for k, c in enumerate(out):
        prev_e = out[k - 1][-1]["e"] if k else c[0]["s"] - 2
        next_s = out[k + 1][0]["s"] if k + 1 < len(out) else c[-1]["e"] + 2
        res.append({"id": k, "s": c[0]["s"], "e": c[-1]["e"], "spk": c[0]["spk"],
                    "text": " ".join(w["w"] for w in c), "n": len(c),
                    "pause_before": round(c[0]["s"] - prev_e, 2), "pause_after": round(next_s - c[-1]["e"], 2)})
    return res

def frame_feats(y):
    n = len(y) // HOP
    fr = y[:n * HOP].reshape(n, HOP)
    db = 20 * np.log10(np.sqrt((fr ** 2).mean(1)) + 1e-6)
    try:
        import librosa
        f0 = librosa.yin(y, fmin=70, fmax=400, sr=SR, frame_length=1024, hop_length=HOP)[:n]
        f0 = np.where(db[:len(f0)] > np.percentile(db, 40), f0, np.nan)
    except Exception:
        f0 = np.full(n, np.nan)
    return db, f0

def zs(vals):
    v = np.array(vals, float)
    m, s = np.nanmedian(v), np.nanstd(v) + 1e-6
    return (v - m) / s

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("media"); ap.add_argument("transcript")
    ap.add_argument("--offset", type=float, default=0.0)
    ap.add_argument("--out", default="moment_map")
    ap.add_argument("--emotion", action="store_true")
    a = ap.parse_args()
    y = load_audio(a.media)
    dur = len(y) / SR
    ws = [w for w in words_of(a.transcript) if a.offset <= w["s"] and w["e"] <= a.offset + dur]
    S = sentences(ws)
    db, f0 = frame_feats(y)
    semi = 12 * np.log2(f0 / 100.0)
    floor = np.percentile(db, 10)
    for s in S:
        i0, i1 = int((s["s"] - a.offset) * 100), max(int((s["s"] - a.offset) * 100) + 1, int((s["e"] - a.offset) * 100))
        seg_db = db[i0:i1]; voiced = seg_db[seg_db > floor + 10]
        s["loud"] = float(np.mean(voiced)) if len(voiced) else np.nan
        p = semi[i0:i1]; p = p[~np.isnan(p)]
        s["pitch"] = float(np.median(p)) if len(p) > 5 else np.nan
        s["prange"] = float(np.percentile(p, 90) - np.percentile(p, 10)) if len(p) > 5 else np.nan
        s["pace"] = s["n"] / max(0.3, s["e"] - s["s"])
        # cut safety: is there real silence around the sentence edges?
        def quiet(t0, t1):
            j0, j1 = int((t0 - a.offset) * 100), int((t1 - a.offset) * 100)
            seg = db[max(0, j0):max(j0 + 1, j1)]
            return bool(len(seg) and np.min(seg) < floor + 12)
        s["safe_in"] = s["pause_before"] >= 0.25 and quiet(s["s"] - min(0.3, s["pause_before"]), s["s"] - 0.02)
        s["safe_out"] = s["pause_after"] >= 0.3 and quiet(s["e"] + 0.04, s["e"] + min(0.4, s["pause_after"]))
        s["starts_on_connective"] = s["text"].split()[0].lower().strip(",.") in CONNECTIVES
    # z vs each speaker's own baseline
    for spk in set(s["spk"] for s in S):
        grp = [s for s in S if s["spk"] == spk]
        for key in ("loud", "pitch", "prange", "pace"):
            z = zs([g[key] for g in grp])
            for g, v in zip(grp, z):
                g[key + "_z"] = None if np.isnan(v) else round(float(v), 2)
    for s in S:
        g = lambda k: np.clip(s.get(k + "_z") or 0, -3, 3)
        s["arousal"] = round(float(0.40 * g("loud") + 0.30 * g("pitch") + 0.15 * g("prange") + 0.15 * g("pace")), 2)
    if a.emotion:
        try:
            from funasr import AutoModel
            m = AutoModel(model="iic/emotion2vec_plus_large", disable_update=True)
            import tempfile, wave
            for s in S:
                i0, i1 = int((s["s"] - a.offset) * SR), int((s["e"] - a.offset) * SR)
                with tempfile.NamedTemporaryFile(suffix=".wav") as f:
                    with wave.open(f.name, "wb") as w:
                        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
                        w.writeframes((np.clip(y[i0:i1], -1, 1) * 32767).astype(np.int16).tobytes())
                    r = m.generate(f.name, granularity="utterance", extract_embedding=False)[0]
                    lab = [l.split("/")[-1] for l in r["labels"]]
                    top = int(np.argmax(r["scores"]))
                    s["emotion"] = lab[top]; s["emotion_p"] = round(float(r["scores"][top]), 2)
        except Exception as e:
            print("emotion2vec skipped:", e, file=sys.stderr)
    for s in S:
        for k in ("loud", "pitch", "prange"):
            s[k] = None if s[k] is None or (isinstance(s[k], float) and np.isnan(s[k])) else round(s[k], 2)
    Path(a.out + ".json").write_text(json.dumps(S, indent=1))
    # readable map for the LLM pass
    def mmss(t): return f"{int(t // 60):02d}:{t % 60:04.1f}"
    lines = [f"# Moment map: {Path(a.media).name}", "",
             "Tags: E = arousal (energy+pitch+pace vs this speaker's baseline; >= +1.0 is a peak, <= -1.0 a low). "
             "IN/OUT = safe cut edge (real pause). CONN = starts on a connective (needs a rewrite or an earlier IN).", ""]
    for s in S:
        tags = [f"E{s['arousal']:+.1f}"]
        if s.get("emotion") and s["emotion"] not in ("neutral", "<unk>", "other"):
            tags.append(f"{s['emotion'].upper()} {s['emotion_p']}")
        tags += [x for x, ok in (("IN", s["safe_in"]), ("OUT", s["safe_out"]), ("CONN", s["starts_on_connective"])) if ok]
        lines.append(f"S{s['id']:03d} [{mmss(s['s'])}-{mmss(s['e'])}] {s['spk']} | {' '.join(tags)} | {s['text']}")
    peaks = sorted(S, key=lambda s: -s["arousal"])[:8]
    lines += ["", "## Highest-energy sentences", ""] + [f"- S{s['id']:03d} E{s['arousal']:+.1f}: {s['text'][:110]}" for s in peaks]
    lows = sorted(S, key=lambda s: s["arousal"])[:5]
    lines += ["", "## Lowest-energy sentences (possible vulnerable/quiet moments, or dead air)", ""] + \
             [f"- S{s['id']:03d} E{s['arousal']:+.1f}: {s['text'][:110]}" for s in lows]
    Path(a.out + ".md").write_text("\n".join(lines) + "\n")
    print(f"{len(S)} sentences -> {a.out}.json / {a.out}.md")

if __name__ == "__main__":
    main()
