#!/usr/bin/env python3
"""Snap planned cuts to clean word boundaries (no clipped words).

usage: /usr/bin/python3 snapcut.py AUDIO_16k_mono.wav WHISPER.json PLAN.json OUT.json

PLAN.json: [{"a": first_word_whisper_start, "b": last_word_whisper_end, "spk": "tim"}, ...]
  a/b are the Whisper start of the first word you want and the Whisper end of the last word you want.

Recipe (see reference/boundary-audit-oak-fire.md):
  - Whisper gives the words; wav2vec2 forced alignment gives the timing (word ends +80 ms).
  - Search the gap between words for the quietest point; prefer a real pause.
  - Flag any cut that lands >25 dB above the noise floor (probably inside speech).
OUT.json: [{"a", "b", "spk", "words": [{"w", "s", "e"}], "flags": [...]}, ...]  (source-time seconds)
"""
import json, re, sys, wave
import numpy as np, torch, torchaudio

AUDIO, WJ, PLAN, OUT = sys.argv[1:5]
SR = 16000
with wave.open(AUDIO) as wf:
    assert wf.getframerate() == SR and wf.getnchannels() == 1, "need 16 kHz mono wav"
    x = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32) / 32768
wav = torch.from_numpy(x.copy())

W = [dict(w) for s in json.load(open(WJ))["segments"] for w in s.get("words", [])]
# glue whisper fragments like "$80" ",000." or "30" "%" back into one word
_m = []
for w in W:
    t = w["word"].strip()
    if _m and (t.startswith(",") or t.startswith("%")) and re.search(r"\d", _m[-1]["word"]):
        _m[-1]["word"] = _m[-1]["word"].rstrip() + t; _m[-1]["end"] = w["end"]
    else: _m.append(w)
W = _m
plan = json.load(open(PLAN))

bundle = torchaudio.pipelines.WAV2VEC2_ASR_BASE_960H
model = bundle.get_model().eval(); labels = bundle.get_labels(); lab = {c: i for i, c in enumerate(labels)}

ONES = "ZERO ONE TWO THREE FOUR FIVE SIX SEVEN EIGHT NINE TEN ELEVEN TWELVE THIRTEEN FOURTEEN FIFTEEN SIXTEEN SEVENTEEN EIGHTEEN NINETEEN".split()
TENS = "_ _ TWENTY THIRTY FORTY FIFTY SIXTY SEVENTY EIGHTY NINETY".split()
def say(n):
    if n < 20: return ONES[n]
    if n < 100: return TENS[n // 10] + ("" if n % 10 == 0 else " " + ONES[n % 10])
    if n < 1000: return ONES[n // 100] + " HUNDRED" + ("" if n % 100 == 0 else " " + say(n % 100))
    for big, name in [(10**9, "BILLION"), (10**6, "MILLION"), (1000, "THOUSAND")]:
        if n >= big: return say(n // big) + " " + name + ("" if n % big == 0 else " " + say(n % big))
def spoken(tok):
    t = tok.strip().upper()
    if re.fullmatch(r"(19|20)\d\d[.,?!]*", t):
        y = int(t[:4]); return say(y // 100) + " " + say(y % 100)
    m = re.fullmatch(r"\$?([\d,]+)(%?)[.,?!]*", t)
    if m:
        s = say(int(m.group(1).replace(",", "")))
        if m.group(2): s += " PERCENT"
        if t.startswith("$"): s += " DOLLARS"
        return s
    return t
def tokens(word):
    return [p for p in (re.sub(r"[^A-Z']", "", q) for q in spoken(word).replace("-", " ").split()) if p]

def align(a, b):
    ws = [w for w in W if w["end"] > a - 1.5 and w["start"] < b + 1.5]
    t0 = max(0.0, ws[0]["start"] - 0.4); t1 = min(len(x) / SR, ws[-1]["end"] + 0.4)
    chunk = wav[int(t0 * SR):int(t1 * SR)].unsqueeze(0)
    with torch.inference_mode():
        em, _ = model(chunk); em = torch.log_softmax(em, -1)
    toks, owner = [], []
    for k, w in enumerate(ws):
        ts = tokens(w["word"])
        nxt = ws[k + 1]["word"].strip().strip(".,?!").upper() if k + 1 < len(ws) else ""
        if ts and ts[-1] == "DOLLARS" and nxt == "DOLLARS": ts = ts[:-1]  # "$80,000 dollars" said once
        for p in ts: toks.append(p); owner.append(k)
    tgt = torch.tensor([[lab[c] for c in "|".join(toks)]], dtype=torch.int32)
    al, sc = torchaudio.functional.forced_align(em, tgt, blank=0)
    spans = torchaudio.functional.merge_tokens(al[0], sc[0].exp())
    groups, cur = [], []
    for s in spans:
        if labels[s.token] == "|":
            if cur: groups.append(cur); cur = []
        else: cur.append(s)
    if cur: groups.append(cur)
    ratio = chunk.shape[1] / em.shape[1] / SR
    out = [None] * len(ws)
    for g, k in zip(groups, owner):
        s_, e_ = t0 + g[0].start * ratio, t0 + g[-1].end * ratio
        if out[k] is None: out[k] = {"w": ws[k]["word"].strip(), "s": s_, "e": e_, "ws": ws[k]["start"], "we": ws[k]["end"]}
        else: out[k]["e"] = e_
    return [o for o in out if o]

# energy in 10 ms frames
HOP = SR // 100
fr = np.sqrt(np.mean(x[:len(x) // HOP * HOP].reshape(-1, HOP) ** 2, axis=1) + 1e-12)
db = 20 * np.log10(fr)
floor = np.percentile(db, 10)
def dbat(t): return db[min(len(db) - 1, max(0, int(t * 100)))] - floor
def quietest(lo, hi):
    if hi <= lo: return (lo + hi) / 2
    i0, i1 = int(lo * 100), max(int(lo * 100) + 1, int(hi * 100))
    return (i0 + int(np.argmin(db[i0:i1]))) / 100 + 0.005

result = []
for seg in plan:
    a, b, spk = seg["a"], seg["b"], seg.get("spk", "main")
    aw = align(a, b)
    for k in range(len(aw) - 1):  # pad word ends +80 ms, never past the next word
        aw[k]["e"] = min(aw[k]["e"] + 0.08, aw[k + 1]["s"] - 0.01)
    aw[-1]["e"] += 0.08
    i = min(range(len(aw)), key=lambda k: abs(aw[k]["ws"] - a))
    j = min(range(len(aw)), key=lambda k: abs(aw[k]["we"] - b))
    first, last = aw[i], aw[j]
    prev_e = aw[i - 1]["e"] if i > 0 else first["s"] - 0.5
    next_s = aw[j + 1]["s"] if j + 1 < len(aw) else last["e"] + 0.5
    flags = []
    # IN
    lo, hi = max(prev_e + 0.04, first["s"] - 0.30), first["s"] - 0.02
    if hi - lo >= 0.03 and dbat(max(lo, first["s"] - 0.05)) < 14:
        cin = max(lo, first["s"] - 0.05)
    else:
        cin = quietest(lo, hi) if hi > lo else first["s"] - 0.01
        if hi <= lo: flags.append("IN: no gap before first word (continuous speech)")
    if dbat(cin) > 25: flags.append(f"IN at {cin:.2f} is {dbat(cin):.0f} dB above floor")
    # OUT
    lo, hi = last["e"] - 0.02, min(next_s - 0.02, last["e"] + 0.30)
    if hi - lo >= 0.03 and dbat(last["e"]) < 14:
        cout = min(last["e"], hi)
    else:
        cout = quietest(lo, hi) if hi > lo else last["e"]
        if hi <= lo: flags.append("OUT: no gap after last word (continuous speech)")
    if dbat(cout) > 25: flags.append(f"OUT at {cout:.2f} is {dbat(cout):.0f} dB above floor")
    words = [{"w": w["w"], "s": round(w["s"], 3), "e": round(w["e"], 3)} for w in aw[i:j + 1]]
    result.append({"a": round(cin, 3), "b": round(cout, 3), "spk": spk, "words": words, "flags": flags})
    print(f"{cin:8.2f}-{cout:8.2f} [{spk}] {' '.join(w['w'] for w in words)}" + (f"   !! {'; '.join(flags)}" if flags else ""))
json.dump(result, open(OUT, "w"), indent=1)
