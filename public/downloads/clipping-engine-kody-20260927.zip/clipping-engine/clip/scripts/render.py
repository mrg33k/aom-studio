#!/usr/bin/env python3
"""Render a clip plan in any style with any brand.

  python3 render.py PLAN.json --brand BRAND.json --style bold-pop [--aspect 9:16] --out clip.mp4
  python3 render.py PLAN.json --brand BRAND.json --styles all --times 1,4,9 --out frames.jpg   # style-frame sheet
  python3 render.py PLAN.json --brand BRAND.json --style letterbox --times 1,4 --out dir/      # stills of one style
  python3 render.py --list                                                                      # list styles

Plan format: see reference/clip-plan.md. Paths in the plan are relative to the plan file.
"""
import argparse, json, os, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from PIL import Image, ImageDraw
from clipkit.core import load_brand, load_words, Timeline, build_audio, Encoder, font
from clipkit.styles import Ctx, STYLES, render_frame

def load_plan(path):
    p = Path(path).resolve()
    plan = json.loads(p.read_text())
    base = p.parent
    fix = lambda v: str((base / v).resolve()) if v and not os.path.isabs(v) else v
    for s in plan["sources"].values():
        s["path"] = fix(s["path"])
    plan["transcript"] = fix(plan["transcript"])
    for k in ("content",):
        if plan.get(k):
            plan[k] = fix(plan[k])
    for sp in (plan.get("speakers") or {}).values():
        if sp.get("image"):
            sp["image"] = fix(sp["image"])
    for bt in plan.get("beats", []):
        for k in ("src", "before", "after"):
            if bt.get(k):
                bt[k] = fix(bt[k])
    return plan

def make_ctx(plan, brand, aspect, fps):
    words = load_words(plan["transcript"])
    tl = Timeline(plan, words)
    sources = {k: dict(v) for k, v in plan["sources"].items()}
    return Ctx(plan, brand, tl, sources, aspect, fps)

def sheet(images, labels, cols, out, cell_w=360):
    ims = [im.convert("RGB").resize((cell_w, int(cell_w * im.height / im.width))) for im in images]
    ch = max(i.height for i in ims) + 44
    rows = (len(ims) + cols - 1) // cols
    S = Image.new("RGB", (cols * (cell_w + 12) + 12, rows * (ch + 12) + 12), (24, 24, 24))
    d = ImageDraw.Draw(S)
    f = font("Inter-SemiBold", 22)
    for i, (im, lab) in enumerate(zip(ims, labels)):
        x, y = 12 + (i % cols) * (cell_w + 12), 12 + (i // cols) * (ch + 12)
        S.paste(im, (x, y + 40))
        d.text((x + 4, y + 8), lab, font=f, fill=(235, 235, 235))
    S.save(out, quality=90)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("plan", nargs="?")
    ap.add_argument("--brand")
    ap.add_argument("--style", default="bold-pop")
    ap.add_argument("--styles", help="comma list or 'all' for a style-frame sheet")
    ap.add_argument("--aspect", default=None)
    ap.add_argument("--times", help="comma list of seconds -> stills instead of video")
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--out", required=False)
    ap.add_argument("--no-audio", action="store_true")
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()
    if a.list:
        for k, v in STYLES.items():
            print(f"{k:18s} {','.join(v['aspects']):14s} {v['family']}")
        return
    plan = load_plan(a.plan)
    brand = load_brand(a.brand)
    times = [float(x) for x in a.times.split(",")] if a.times else None

    if a.styles:  # style-frame sheet: rows = styles, cols = times
        names = list(STYLES) if a.styles == "all" else a.styles.split(",")
        imgs, labs = [], []
        for n in names:
            asp = a.aspect if a.aspect in STYLES[n]["aspects"] else STYLES[n]["aspects"][0]
            ctx = make_ctx(plan, brand, asp, a.fps)
            for t in times:
                imgs.append(render_frame(ctx, n, t)); labs.append(f"{n} {asp} @{t:g}s")
        sheet(imgs, labs, len(times), a.out)
        print("wrote", a.out)
        return

    asp = a.aspect or STYLES[a.style]["aspects"][0]
    ctx = make_ctx(plan, brand, asp, a.fps)
    if times:
        os.makedirs(a.out, exist_ok=True)
        for t in times:
            p = os.path.join(a.out, f"{a.style}-{asp.replace(':', 'x')}-{t:06.2f}.png")
            render_frame(ctx, a.style, t).convert("RGB").save(p); print("wrote", p)
        return
    tmp = tempfile.mkdtemp()
    wav = None
    if not a.no_audio:
        wav = os.path.join(tmp, "a.wav")
        build_audio(plan, ctx.tl, ctx.sources, wav)
    enc = Encoder(a.out, ctx.W, ctx.H, a.fps, wav)
    n = int(round(ctx.tl.duration * a.fps))
    t0 = time.time()
    for i in range(n):
        enc.write(render_frame(ctx, a.style, i / a.fps))
        if i % (a.fps * 5) == 0:
            print(f"  {i}/{n} frames  {time.time() - t0:.0f}s", flush=True)
    enc.close()
    print(f"wrote {a.out}  ({ctx.tl.duration:.1f}s, {time.time() - t0:.0f}s render)")

if __name__ == "__main__":
    main()
