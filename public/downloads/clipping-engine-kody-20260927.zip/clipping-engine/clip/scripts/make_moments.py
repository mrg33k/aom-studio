#!/usr/bin/env python3
"""Export Moments from camera originals: graded, cropped, slow push-in, seamless loop.

  /usr/bin/python3 scripts/make_moments.py moments.json SRC_ROOT OUT_DIR [--size 1080x1350] [--only m01,m02]

moments.json: [{"id","src" (relative to SRC_ROOT),"in","dur","cx" (crop center 0-1 of width),
                "cy" (optional, 0-1), "lift" (optional gamma, e.g. 1.35 for dark interiors), "log": true|false (optional; auto: Ronin paths = log), "zoom": 0.06}]

- Grade: log sources (Ronin 4D D-Log) get the manufacturer-neutral LUT first, then a light brand
  look (cool shadows, warm highlights). Rec709 sources (Lumix S5IIX) skip the LUT. MEASURE with
  signalstats if unsure: log reads SATAVG ~20 and YMAX ~750/1023; Rec709 reads SATAVG 100+ and YMAX 1023.
- Push-in: zoom 1.0 -> 1+zoom over the Moment, from a 1.2x oversampled crop (no soft upscales).
- Loop: renders dur + XF seconds and blends the tail into the head, so the last frame flows into the
  first. The loop point is a soft crossfade (zoom included), never a jump.
- Picture only: no audio (crew audio is often unusable; add music at the post level).
"""
import argparse, json, os, subprocess, sys
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, "../../../.."))
LOG_LUT = os.path.join(REPO, "corner/users/aom/missions/aom-lut/research/luts/Neutral_4D8K_65x.cube")
LOOK = "colorbalance=rs=-0.05:gs=-0.01:bs=0.07:rh=0.04:gh=0.01:bh=-0.03"
XF = 0.6  # loop crossfade seconds
OVERSAMPLE = 1.2


def probe(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                          "stream=width,height,r_frame_rate", "-of", "json", path], capture_output=True, text=True).stdout
    s = json.loads(out)["streams"][0]
    n, d = s["r_frame_rate"].split("/")
    return s["width"], s["height"], float(n) / float(d)


def export(m, root, out_dir, W, H):
    src = os.path.join(root, m["src"])
    sw, sh, fps = probe(src)
    fps = 24.0 if abs(fps - 24) < 0.1 else fps
    log = m.get("log", "ronin" in m["src"].lower())
    aspect = W / H
    ch = sh if sw / sh >= aspect else int(sw / aspect)
    cw = int(ch * aspect) // 2 * 2; ch = ch // 2 * 2
    x = int(min(max(m.get("cx", 0.5) * sw - cw / 2, 0), sw - cw)) // 2 * 2
    y = int(min(max(m.get("cy", 0.5) * sh - ch / 2, 0), sh - ch)) // 2 * 2
    OW, OH = int(W * OVERSAMPLE) // 2 * 2, int(H * OVERSAMPLE) // 2 * 2
    grade = (f"lut3d='{LOG_LUT}'," if log else "") + LOOK + (",eq=contrast=1.08:saturation=1.06" if log else ",eq=contrast=1.03:saturation=0.9")
    if m.get("lift"):  # gamma > 1 brightens mids (dark interiors)
        grade += f",eq=gamma={m['lift']}"
    vf = f"{grade},crop={cw}:{ch}:{x}:{y},scale={OW}:{OH}:flags=lanczos,fps={fps}"
    total = m["dur"] + XF
    cmd = ["ffmpeg", "-v", "error", "-ss", str(m["in"]), "-i", src, "-t", f"{total:.3f}", "-map", "0:v:0",
           "-vf", vf, "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]
    raw = subprocess.run(cmd, capture_output=True, check=True).stdout
    fsz = OW * OH * 3
    frames = [np.frombuffer(raw[i:i + fsz], np.uint8).reshape(OH, OW, 3) for i in range(0, len(raw) - fsz + 1, fsz)]
    N = len(frames); L = int(round(m["dur"] * fps)); X = N - L
    if X < 2:
        sys.exit(f"{m['id']}: source too short for loop ({N} frames)")
    zoom = m.get("zoom", 0.06)

    def zoomed(k):
        z = 1 + zoom * k / (N - 1)
        w, h = OW / z, OH / z
        l, t = (OW - w) / 2, (OH - h) / 2
        return np.asarray(Image.fromarray(frames[k]).resize((W, H), Image.LANCZOS, box=(l, t, l + w, t + h)), np.float32)

    out = os.path.join(out_dir, f"{m['id']}.mp4")
    enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}",
                            "-r", str(fps), "-i", "-", "-c:v", "libx264", "-crf", "16", "-preset", "slow",
                            "-pix_fmt", "yuv420p", "-color_primaries", "bt709", "-color_trc", "bt709",
                            "-colorspace", "bt709", "-movflags", "+faststart", out], stdin=subprocess.PIPE)
    for t in range(L):
        f = zoomed(t)
        if t < X:  # head of the loop: fade in from the frames that follow the tail
            w = t / X
            f = (1 - w) * zoomed(L + t) + w * f
        enc.stdin.write(np.clip(f, 0, 255).astype(np.uint8).tobytes())
    enc.stdin.close(); enc.wait()
    # poster frame for contact sheets
    Image.fromarray(np.clip(zoomed(L // 2), 0, 255).astype(np.uint8)).save(os.path.join(out_dir, f"{m['id']}.jpg"), quality=88)
    return out, L / fps


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("plan"); ap.add_argument("root"); ap.add_argument("out")
    ap.add_argument("--size", default="1080x1350"); ap.add_argument("--only", default="")
    a = ap.parse_args()
    W, H = map(int, a.size.split("x"))
    os.makedirs(a.out, exist_ok=True)
    only = set(filter(None, a.only.split(",")))
    for m in json.load(open(a.plan)):
        if only and m["id"] not in only:
            continue
        path, secs = export(m, a.root, a.out, W, H)
        print(f"{m['id']} {secs:.2f}s -> {path}", flush=True)


if __name__ == "__main__":
    main()
