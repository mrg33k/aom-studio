"""Audio arousal curve + transcript pace -> top peaks. /usr/bin/python3 audio_peaks.py a.wav a.json"""
import sys, json, numpy as np, librosa
wav, tj = sys.argv[1], sys.argv[2]
y, sr = librosa.load(wav, sr=16000, mono=True)
HOP = 1600  # 0.1 s frames
rms = librosa.feature.rms(y=y, frame_length=3200, hop_length=HOP, center=True)[0]
db = 20*np.log10(rms + 1e-6)
f0, vflag, vprob = librosa.pyin(y, fmin=70, fmax=400, sr=sr, frame_length=2048, hop_length=HOP, max_transition_rate=10)
n = min(len(db), len(f0)); db, f0, vflag = db[:n], f0[:n], vflag[:n]
t = np.arange(n)*HOP/sr
semi = 12*np.log2(np.where(vflag & ~np.isnan(f0), f0, np.nan)/100.0)
speech = db > np.percentile(db, 30)  # crude VAD
# word pace
d = json.load(open(tj)); words = [w for s in d['segments'] for w in s.get('words', [])]
wt = np.array([(w['start']+w['end'])/2 for w in words])
WIN, STEP = 10.0, 1.0
starts = np.arange(0, t[-1]-WIN, STEP)
rows = []
for s0 in starts:
    m = (t >= s0) & (t < s0+WIN)
    sp = m & speech
    loud = np.mean(db[sp]) if sp.sum() > 20 else np.nan
    ps = semi[m]; ps = ps[~np.isnan(ps)]
    pitch = np.median(ps) if len(ps) > 15 else np.nan
    prange = (np.percentile(ps, 90)-np.percentile(ps, 10)) if len(ps) > 15 else np.nan
    pace = ((wt >= s0) & (wt < s0+WIN)).sum()/WIN*60
    rows.append((s0, loud, pitch, prange, pace))
R = np.array(rows)
def local_z(x, span=180):  # z vs +-90 s neighbourhood, so a speaker's own baseline is used
    out = np.full_like(x, np.nan)
    for i in range(len(x)):
        lo, hi = max(0, i-span//2), min(len(x), i+span//2)
        w = x[lo:hi]; w = w[~np.isnan(w)]
        if len(w) > 10 and not np.isnan(x[i]):
            out[i] = (x[i]-np.median(w))/(np.std(w)+1e-6)
    return out
zl, zp, zr, zs = (local_z(R[:, k]) for k in (1, 2, 3, 4))
def g(z): return np.nan_to_num(np.clip(z, -3, 3))
arousal = 0.40*g(zl) + 0.30*g(zp) + 0.15*g(zr) + 0.15*g(zs)
# global loudness too (a loud stretch in a loud section still matters)
gl = (R[:, 1]-np.nanmedian(R[:, 1]))/np.nanstd(R[:, 1])
score = arousal + 0.25*g(gl)
def text_at(a, b):
    return ' '.join(w['word'].strip() for w in words if w['start'] >= a and w['end'] <= b)
order = np.argsort(-score); picked = []
for i in order:
    if all(abs(R[i, 0]-R[j, 0]) >= 30 for j in picked): picked.append(i)
    if len(picked) == 8: break
print("TOP 8 AUDIO PEAKS (10 s windows, 30 s apart)")
for rank, i in enumerate(picked, 1):
    s0 = R[i, 0]
    print(f"\n#{rank} {s0:.0f}-{s0+WIN:.0f}s ({int(s0//60)}:{int(s0%60):02d}) score={score[i]:.2f} loudZ={zl[i]:.1f} pitchZ={zp[i]:.1f} rangeZ={zr[i]:.1f} paceZ={zs[i]:.1f} wpm={R[i,4]:.0f}")
    print("   ", text_at(s0-2, s0+WIN+2))
pct = lambda v: (score < v).mean()*100
print("\nOUR CHOSEN MOMENTS (mean / max window score, percentile of max)")
for name, a, b in [("fire/insurance", 935, 1200), ("houses save water", 385, 414), ("build-to-rent $1000", 645, 672)]:
    m = (R[:, 0] >= a) & (R[:, 0] <= b-WIN)
    print(f"  {name:22s} mean={score[m].mean():.2f} max={score[m].max():.2f} at {R[m,0][np.argmax(score[m])]:.0f}s  pct_of_max={pct(score[m].max()):.0f}  mean_pct={pct(score[m].mean()):.0f}")
print(f"\nepisode score median={np.median(score):.2f} p90={np.percentile(score,90):.2f}")
np.save('/tmp/mr/curve.npy', np.c_[R, score])
