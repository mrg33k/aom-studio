#!/usr/bin/env python3
"""Cut a bulk GPT image (a grid of panels) into single panels, and find the chroma-green video windows in each.

  python3 gpt_sheet.py SHEET.png OUT_DIR [--rows R --cols C] [--names a,b,c]

- Panels: split on the thin dark gutters GPT draws between panels (auto-detected), or pass --rows/--cols
  to force an even grid.
- Windows: every flat #00FF00-ish region >= 2% of a panel is reported as a video window (bbox + 4 corners),
  so the renderer can key footage into it. Written to OUT_DIR/panels.json.
- Also writes <panel>_plate.png with the green window made transparent (ready to lay over video).

Stock /usr/bin/python3 on the Mac is enough (numpy + Pillow).
"""
import argparse, json, os
import numpy as np
from PIL import Image

def runs(mask, max_len):
    """Runs of True that are thin (<= max_len) -> (start, end)."""
    idx = np.where(mask)[0]
    out, cur = [], []
    for i in idx:
        if cur and i != cur[-1] + 1:
            out.append(cur); cur = []
        cur.append(i)
    if cur:
        out.append(cur)
    return [(r[0], r[-1]) for r in out if len(r) <= max_len]

def split(img, rows=None, cols=None):
    a = np.asarray(img.convert("L")).astype(np.float32)
    H, W = a.shape
    if rows and cols:
        return [(int(c * W / cols), int(r * H / rows), int((c + 1) * W / cols), int((r + 1) * H / rows))
                for r in range(rows) for c in range(cols)]
    # a gutter is a thin line that is uniform along the whole panel edge (solid black or white divider)
    def edges(std, mean, n):
        line = (std < 10) & ((mean < 35) | (mean > 215))
        g = [x for x in runs(line, max(4, int(n * 0.03))) if x[0] > n * 0.05 and x[1] < n * 0.95]
        merged = []
        for s0, e0 in g:
            if merged and s0 - merged[-1][1] < n * 0.05:
                merged[-1] = (merged[-1][0], e0)
            else:
                merged.append((s0, e0))
        cuts = [0] + [v for (s0, e0) in merged for v in (s0, e0 + 1)] + [n]
        return [(cuts[i], cuts[i + 1]) for i in range(0, len(cuts), 2)]
    xs, ys = edges(a.std(axis=0), a.mean(axis=0), W), edges(a.std(axis=1), a.mean(axis=1), H)
    return [(x0, y0, x1, y1) for (y0, y1) in ys for (x0, x1) in xs if x1 - x0 > W * 0.1 and y1 - y0 > H * 0.1]

def green_mask(img):
    a = np.asarray(img.convert("RGB")).astype(np.int16)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    return (g > 150) & (g - r > 60) & (g - b > 60)

def windows(img, min_frac=0.02):
    m = green_mask(img)
    H, W = m.shape
    out = []
    seen = np.zeros_like(m)
    ys, xs = np.where(m)
    if not len(xs):
        return out
    # simple connected components on a downsampled mask
    step = 4
    sm = m[::step, ::step]
    lab = np.zeros(sm.shape, np.int32); n = 0
    for y in range(sm.shape[0]):
        for x in range(sm.shape[1]):
            if sm[y, x] and not lab[y, x]:
                n += 1; stack = [(y, x)]; lab[y, x] = n
                while stack:
                    cy, cx = stack.pop()
                    for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        ny, nx = cy + dy, cx + dx
                        if 0 <= ny < sm.shape[0] and 0 <= nx < sm.shape[1] and sm[ny, nx] and not lab[ny, nx]:
                            lab[ny, nx] = n; stack.append((ny, nx))
    for k in range(1, n + 1):
        yy, xx = np.where(lab == k)
        if len(xx) * step * step < min_frac * W * H:
            continue
        x0, x1, y0, y1 = xx.min() * step, (xx.max() + 1) * step, yy.min() * step, (yy.max() + 1) * step
        pts = np.stack([xx * step, yy * step], 1)
        s, d = pts.sum(1), pts[:, 0] - pts[:, 1]
        corners = [pts[s.argmin()], pts[d.argmax()], pts[s.argmax()], pts[d.argmin()]]  # tl, tr, br, bl
        fill = len(xx) * step * step / max(1, (x1 - x0) * (y1 - y0))
        out.append({"bbox": [int(x0), int(y0), int(x1), int(y1)],
                    "corners": [[int(p[0]), int(p[1])] for p in corners],
                    "rect": bool(fill > 0.93), "aspect": round((x1 - x0) / max(1, y1 - y0), 3)})
    return sorted(out, key=lambda w: (w["bbox"][1], w["bbox"][0]))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("sheet"); ap.add_argument("out")
    ap.add_argument("--rows", type=int); ap.add_argument("--cols", type=int)
    ap.add_argument("--names")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    img = Image.open(a.sheet).convert("RGB")
    boxes = split(img, a.rows, a.cols)
    names = a.names.split(",") if a.names else [f"panel-{i + 1:02d}" for i in range(len(boxes))]
    res = []
    for name, box in zip(names, boxes):
        p = img.crop(box)
        p.save(os.path.join(a.out, f"{name}.png"))
        ws = windows(p)
        if ws:
            plate = p.convert("RGBA")
            m = green_mask(p)
            al = np.asarray(plate.getchannel("A")).copy(); al[m] = 0
            plate.putalpha(Image.fromarray(al))
            plate.save(os.path.join(a.out, f"{name}_plate.png"))
        res.append({"name": name, "box": list(map(int, box)), "size": list(p.size), "windows": ws})
        print(f"{name}: {p.size[0]}x{p.size[1]}, {len(ws)} video window(s) {[w['bbox'] for w in ws]}")
    json.dump(res, open(os.path.join(a.out, "panels.json"), "w"), indent=1)

if __name__ == "__main__":
    main()
