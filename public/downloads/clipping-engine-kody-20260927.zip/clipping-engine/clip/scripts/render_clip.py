#!/usr/bin/env python3
"""General branded 9:16 clip renderer (live-speaker layout).

usage: /usr/bin/python3 render_clip.py CLIP.json

CLIP.json keys:
  source        video file (source time = seconds in this file)
  cuts          cuts json from snapcut.py (segments + aligned words + speaker)
  brand         brand.json
  out           output mp4
  hook          [line1, line2]
  top_crop      [x, y, w, h] region of the source shown live in the top panel (the main speaker)
  faces         {spk: {"img": path, "crop": [x,y,w,h]}} stills for end-card bubbles
  beats         list of bottom-panel graphics, each {"type", "at": "word" (first match after previous beat), ...}
                types: quote{text}, stat{label, prefix, value, suffix}, bars{label, rows:[[name, pct, text]]},
                       badge{title, sub, chips:[[word, text]]}, checklist{title, items:[[word, text]]}, pin{label}
Everything animates in; backgrounds drift; captions color the active word per speaker.
"""
import glob, json, math, os, random, subprocess, sys, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageOps

cfg = json.load(open(sys.argv[1]))
HERE = os.path.dirname(os.path.abspath(__file__))
brand = json.load(open(cfg["brand"])); BDIR = os.path.dirname(os.path.abspath(cfg["brand"]))
hx = lambda h: tuple(int(h.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4))
C = {k: hx(v) for k, v in brand["colors"].items()}
FOREST, MID, LIME, SAGE, NEAR, CREAM, TANK = C["forest"], C["mid_green"], C["lime_accent"], C["sage"], C["near_black"], C["cream"], C["tan"]
SPK_COL = {k: C[v["active_word"]] for k, v in brand["speakers"].items()}
FPS, W, H = 30, 1080, 1920
RB = brand.get("render", {})   # per-brand look knobs; defaults = the Oak Street look
SKILL = os.path.dirname(HERE)
def _font(p, default):
    if not p: return default
    for base in ("", BDIR, SKILL):
        q = os.path.join(base, p.split("#")[0]) if base else p.split("#")[0]
        if os.path.exists(q): return q + ("#" + p.split("#")[1] if "#" in p else "")
    return default
SERIF = _font(RB.get("headline_font"), "/System/Library/Fonts/Supplemental/Rockwell.ttc#2")
XB = _font(RB.get("caption_font"), "/Users/aom-inhouse/Library/Fonts/Poppins-ExtraBold.ttf")
UP_HEAD = RB.get("headline_upper", False); UP_CAP = RB.get("caption_upper", False)
TEXTURE = RB.get("texture", "contours")
BAR = C.get(RB.get("caption_bar", "near_black"), None) or C["near_black"]
SFX = "/Users/aom-inhouse/aom-studio-transfer/AOM-EA/corner/users/aom/agents/content-agent/audio/sfx/"
PANEL_TOP, PANEL_H = 250, 760
BOT_Y = PANEL_TOP + PANEL_H + 20
TAIL = float(cfg.get("tail_after_speech", 2.6))  # shorten when the CTA already reads during speech
END_LEAD = 1.2    # end card starts sliding in this long BEFORE the last word ends (no dead cut)

_fc = {}
def fnt(p, s):
    k = (p, s)
    if k not in _fc: _fc[k] = ImageFont.truetype(p.split("#")[0], s, index=int(p.split("#")[1]) if "#" in p else 0)
    return _fc[k]
def ease(x): x = max(0, min(1, x)); return 1 - (1 - x) ** 3
def back(x): x = max(0, min(1, x)); c = 1.9; return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2
def fit(img, w, h): return ImageOps.fit(img, (w, h), Image.LANCZOS)
def spaced(d, xy, s_, font, fill, track, anchor="mm"):
    ws = [d.textlength(ch, font=font) for ch in s_]; tot = sum(ws) + track * (len(s_) - 1)
    x = xy[0] - tot / 2 if anchor == "mm" else xy[0]
    for ch, w in zip(s_, ws): d.text((x, xy[1]), ch, font=font, fill=fill, anchor="lm"); x += w + track
def rise(c, fn, size, pos, p, dist=30):
    if p <= 0: return
    lay = Image.new("RGBA", size, (0, 0, 0, 0)); fn(ImageDraw.Draw(lay))
    if p < 1: lay.putalpha(lay.getchannel("A").point(lambda v: int(v * p)))
    c.alpha_composite(lay, (int(pos[0]), int(pos[1] + (1 - p) * dist)))
def pop(c, img, center, p):
    if p <= 0.02: return
    w, h = int(img.width * p), int(img.height * p)
    if w > 3 and h > 3: c.alpha_composite(img.resize((w, h), Image.LANCZOS), (int(center[0] - w / 2), int(center[1] - h / 2)))
def wrap(d, text, font, maxw):
    lines, cur = [], ""
    for w in text.split():
        t = (cur + " " + w).strip()
        if d.textlength(t, font=font) > maxw and cur: lines.append(cur); cur = w
        else: cur = t
    return lines + [cur]

# ---- drifting contour texture -------------------------------------------------
_yy, _xx = np.mgrid[0:1400, 0:1400].astype(np.float32) / 1400.0
_f = np.sin(_xx * 7.1 + 1.3) + np.sin(_yy * 5.3 + 0.4) + 0.7 * np.sin((_xx + _yy) * 9.7) + 0.5 * np.sin((_xx - _yy) * 12.9 + 2.0)
TEX = Image.fromarray(np.where(np.abs(((_f * 3.2) % 1.0) - 0.5) < 0.035, 26, 0).astype(np.uint8), "L").filter(ImageFilter.GaussianBlur(0.8))
_STRIPES = Image.new("L", (2800, 2800), 0); _sd = ImageDraw.Draw(_STRIPES)
for _k in range(-30, 60): _sd.polygon([(_k * 120, 0), (_k * 120 + 46, 0), (_k * 120 + 46 - 2800, 2800), (_k * 120 - 2800, 2800)], fill=34)
_rng = np.random.default_rng(7); _DOTS = [(float(_rng.uniform(0, 1400)), float(_rng.uniform(0, 1400)), float(_rng.uniform(0, 6.28)), float(_rng.uniform(1.5, 3.5))) for _ in range(260)]
def textured(base, w, h, t, speed=14):
    img = Image.new("RGBA", (w, h), base + (255,))
    if TEXTURE == "stripes":   # slow diagonal bands in the second brand color
        o = int((t * speed * 2) % 120); m = _STRIPES.crop((o, 0, o + w, h))
        img.alpha_composite(Image.merge("RGBA", (*Image.new("RGB", (w, h), TANK).split(), m)))
    elif TEXTURE == "dots":    # twinkling city-light dots drifting up
        m = Image.new("L", (w, h), 0); md = ImageDraw.Draw(m)
        for x_, y_, ph, r in _DOTS:
            if x_ < w:
                yy_ = (y_ - t * speed * 0.5) % 1400
                if yy_ < h: md.ellipse((x_ - r, yy_ - r, x_ + r, yy_ + r), fill=int(60 + 70 * (0.5 + 0.5 * math.sin(t * 2 + ph))))
        img.alpha_composite(Image.merge("RGBA", (*Image.new("RGB", (w, h), LIME).split(), m)))
    else:
        ox = int((t * speed) % (1400 - w)) if w < 1400 else 0; oy = int((t * speed * 0.6) % (1400 - h)) if h < 1400 else 0
        m = TEX.crop((ox, oy, ox + w, oy + h)) if (w < 1400 and h < 1400) else TEX.resize((w, h))
        img.alpha_composite(Image.merge("RGBA", (*Image.new("RGB", (w, h), LIME).split(), m)))
    cx = w * (0.3 + 0.4 * math.sin(t * 0.35)); cy = h * (0.4 + 0.2 * math.cos(t * 0.27))
    g = Image.new("L", (w, h), 0); ImageDraw.Draw(g).ellipse((cx - w * .5, cy - w * .5, cx + w * .5, cy + w * .5), fill=22)
    g = g.resize((max(1, w // 8), max(1, h // 8))).filter(ImageFilter.GaussianBlur(12)).resize((w, h), Image.BILINEAR)
    img.alpha_composite(Image.merge("RGBA", (*Image.new("RGB", (w, h), (255, 255, 240)).split(), g)))
    return img

# ---- timeline -----------------------------------------------------------------
cuts = json.load(open(cfg["cuts"]))
words, t0 = [], 0.0
for c in cuts:
    for w in c["words"]:
        words.append({"w": w["w"], "s": w["s"] - c["a"] + t0, "e": w["e"] - c["a"] + t0, "spk": c["spk"]})
    t0 += c["b"] - c["a"]
SPEECH = t0; DUR = SPEECH + TAIL; N = int(DUR * FPS)
def clean(w): return w.lower().strip(".,?!%$").replace("'s", "")
cursor = 0.0
for bt in cfg["beats"]:
    key = bt["at"].lower()
    hit = next((w for w in words if w["s"] >= cursor - 0.01 and clean(w["w"]).startswith(key)), None)
    if hit is None: raise SystemExit(f"beat word not found: {bt['at']}")
    bt["t"] = hit["s"] - 0.15; cursor = hit["s"]
    for lst in ("chips", "items"):
        if lst in bt:
            cur2 = cursor; bt[lst + "_t"] = []
            for wd, _ in bt[lst]:
                h2 = next((w for w in words if w["s"] >= cur2 - 0.01 and clean(w["w"]).startswith(wd.lower())), None)
                bt[lst + "_t"].append((h2["s"] if h2 else cur2 + 0.6) - 0.1); cur2 = h2["s"] if h2 else cur2 + 0.6
if cfg.get("template") and cfg["beats"] and cfg["beats"][0]["t"] > 0.4: cfg["beats"][0]["t"] = 0.35
chunks, cur = [], []
for i, w in enumerate(words):
    cur.append(w)
    nx = words[i + 1] if i + 1 < len(words) else None
    if len(cur) == 4 or sum(len(x["w"]) + 1 for x in cur) > 18 or w["w"][-1] in ".,!?" or nx is None or nx["spk"] != w["spk"] or nx["s"] - w["e"] > 0.6:
        chunks.append(cur); cur = []

# ---- source frames (streamed in order) ------------------------------------------
FB = cfg.get("layout") == "fullbleed"
if FB: TX, TY, TW, TH = cfg["fb_crop"]
else: TX, TY, TW, TH = cfg["top_crop"]
VSRC = cfg.get("fb_source", cfg["source"]) if FB else cfg["source"]
OUT_W, OUT_H = (W, H) if FB else (W, PANEL_H)
def frame_stream():
    for c in cuts:
        n = int(round((c["b"] - c["a"]) * FPS))
        p = subprocess.Popen(["ffmpeg", "-v", "error", "-ss", f"{max(0, c['a'] - 3):.3f}", "-i", VSRC, "-ss", f"{min(3, c['a']):.3f}",
                              "-t", f"{c['b'] - c['a']:.3f}", "-vf", f"fps={FPS},crop={TW}:{TH}:{TX}:{TY},scale={OUT_W}:{OUT_H}:flags=lanczos,eq=contrast=1.05:saturation=1.06",
                              "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], stdout=subprocess.PIPE)
        last = None
        for _ in range(n):
            buf = p.stdout.read(OUT_W * OUT_H * 3)
            if len(buf) == OUT_W * OUT_H * 3: last = Image.frombytes("RGB", (OUT_W, OUT_H), buf)
            yield last
        p.stdout.close(); p.wait()
    while True: yield last
frames = frame_stream()

faces = {k: fit(Image.open(v["img"]).convert("RGB").crop(tuple(v["crop"][:2]) + (v["crop"][0] + v["crop"][2], v["crop"][1] + v["crop"][3])), 400, 400)
         for k, v in cfg["faces"].items()}
MASK = Image.new("L", (400, 400), 0); ImageDraw.Draw(MASK).ellipse((0, 0, 399, 399), fill=255)
LOGO = Image.open(os.path.join(BDIR, brand["end_card"]["logo"])).convert("RGBA") if brand.get("end_card", {}).get("logo") else None
if LOGO is not None and RB.get("logo_circle"):
    _m = Image.new("L", LOGO.size, 0); ImageDraw.Draw(_m).ellipse((2, 2, LOGO.width - 3, LOGO.height - 3), fill=255)
    _a = LOGO.getchannel("A"); LOGO.putalpha(Image.fromarray(np.minimum(np.array(_a), np.array(_m))))
ICON = Image.open(os.path.join(BDIR, RB.get("icon", "tree-icon-lime.png"))).convert("RGBA") if RB.get("icon", "tree-icon-lime.png") and os.path.exists(os.path.join(BDIR, RB.get("icon", "tree-icon-lime.png") or "")) else None
BG_IMG = Image.open(cfg["end_bg"]).convert("RGB") if cfg.get("end_bg") else None

def bubble(img, d, ring):
    r = Image.new("RGBA", (d + 20, d + 20), (0, 0, 0, 0)); rd = ImageDraw.Draw(r)
    rd.ellipse((0, 0, d + 19, d + 19), fill=ring); rd.ellipse((6, 6, d + 13, d + 13), fill=CREAM)
    r.paste(img.resize((d, d), Image.LANCZOS), (10, 10), MASK.resize((d, d))); return r

# ---- beat drawers (draw on bottom panel 'p', local time since beat start 'u') ----------
TS = 1.28 if cfg.get("template") else 1.0   # text beats fill their window in template mode
def draw_quote(p, b, u):
    f = fnt(SERIF, int(b.get("size", 78) * TS)); d = ImageDraw.Draw(p); lines = wrap(d, b["text"], f, 960)
    y0 = PANEL_H / 2 - len(lines) * f.size * 0.62 + 40
    for n, ln in enumerate(lines):
        rise(p, lambda dd, ln=ln: dd.text((W / 2, 60), ln, font=f, fill=CREAM, anchor="mm"), (W, 120), (0, y0 + n * f.size * 1.2 - 60), ease((u - 0.1 - n * 0.15) / 0.4))
    lw = 120 * ease((u - 0.3) / 0.4)
    if lw > 1: d.line((W / 2 - lw, y0 - 70, W / 2 + lw, y0 - 70), fill=LIME, width=5)
def draw_stat(p, b, u):
    d = ImageDraw.Draw(p)
    rise(p, lambda dd: spaced(dd, (W / 2, 40), b["label"], fnt(XB, int(34 * TS)), CREAM, 9), (W, 80), (0, 175), ease((u - 0.05) / 0.4))
    lw = 150 * ease((u - 0.25) / 0.45)
    if lw > 1: d.line((W / 2 - lw, 255, W / 2 + lw, 255), fill=LIME, width=5)
    v = b["value"] * ease((u - 0.2) / 1.2) if b.get("count_up", True) else b["value"]
    txt = b.get("prefix", "") + f"{int(round(v)):,}" + b.get("suffix", "")
    lay = Image.new("RGBA", (W, 230), (0, 0, 0, 0)); ImageDraw.Draw(lay).text((W / 2, 115), txt, font=fnt(SERIF, b.get("size", 150)), fill=CREAM, anchor="mm")
    pop(p, lay, (W / 2, 385), back((u - 0.15) / 0.45))
    if b.get("note"):
        rise(p, lambda dd: dd.text((W / 2, 30), b["note"], font=fnt(XB, 40), fill=SAGE, anchor="mm"), (W, 60), (0, 500), ease((u - 1.0) / 0.4))
def draw_bars(p, b, u):
    d = ImageDraw.Draw(p)
    rise(p, lambda dd: spaced(dd, (80, 40), b["label"], fnt(XB, 34), TANK, 8, anchor="lm"), (W, 80), (0, 150), ease((u - 0.05) / 0.4))
    for n, (name, pct, text) in enumerate(b["rows"]):
        y = 300 + n * 170; g = ease((u - 0.35 - n * 0.5) / 0.9)
        rise(p, lambda dd, name=name: dd.text((80, 25), name, font=fnt(XB, 42), fill=CREAM, anchor="lm"), (W, 50), (0, y - 70), ease((u - 0.2 - n * 0.5) / 0.35))
        d.rounded_rectangle((80, y, 80 + 900, y + 70), 16, fill=NEAR)
        wbar = int(900 * pct / 100 * g)
        if wbar > 20: d.rounded_rectangle((80, y, 80 + wbar, y + 70), 16, fill=LIME if n else SAGE)
        if g > 0.6: d.text((80 + max(wbar, 60) + 20 if wbar < 700 else 80 + wbar - 20, y + 36), text, font=fnt(XB, 40), fill=CREAM if wbar < 700 else NEAR, anchor="lm" if wbar < 700 else "rm")
def draw_badge(p, b, u):
    d = ImageDraw.Draw(p); f = fnt(SERIF, int(b.get("size", 70) * TS)); lines = wrap(d, b["title"], f, 960)
    for n, ln in enumerate(lines):
        rise(p, lambda dd, ln=ln: dd.text((W / 2, 60), ln, font=f, fill=CREAM, anchor="mm"), (W, 120), (0, 160 + n * f.size * 1.15), ease((u - 0.05 - n * 0.15) / 0.4))
    yb = 160 + len(lines) * f.size * 1.15 + 80
    lw = 140 * ease((u - 0.3) / 0.4)
    if lw > 1: d.line((W / 2 - lw, yb - 30, W / 2 + lw, yb - 30), fill=LIME, width=5)
    if b.get("sub"): rise(p, lambda dd: dd.text((W / 2, 30), b["sub"], font=fnt(XB, int(38 * TS)), fill=SAGE, anchor="mm"), (W, 70), (0, yb), ease((u - 0.45) / 0.4))
    chips = b.get("chips", []); ts = b.get("chips_t", [])
    if chips:
        cf = fnt(XB, 40); widths = [d.textlength(t, font=cf) + 60 for _, t in chips]; tot = sum(widths) + 24 * (len(chips) - 1); x = (W - tot) / 2
        for (wd, t), cw, ct in zip(chips, widths, ts):
            chip = Image.new("RGBA", (int(cw), 80), (0, 0, 0, 0)); cd = ImageDraw.Draw(chip)
            cd.rounded_rectangle((0, 0, cw - 1, 79), 40, fill=MID); cd.text((cw / 2, 41), t, font=cf, fill=CREAM, anchor="mm")
            pop(p, chip, (x + cw / 2, yb + 130), back((u - (ct - b["t"])) / 0.35)); x += cw + 24
def check_path(d, x0, y0, q):
    pts = [(x0 + 17, y0 + 38), (x0 + 31, y0 + 53), (x0 + 57, y0 + 21)]
    l1, l2 = math.dist(pts[0], pts[1]), math.dist(pts[1], pts[2]); L = (l1 + l2) * max(0, min(1, q))
    if L <= 0: return
    if L <= l1: d.line((pts[0], (pts[0][0] + (pts[1][0] - pts[0][0]) * L / l1, pts[0][1] + (pts[1][1] - pts[0][1]) * L / l1)), fill=FOREST, width=9)
    else:
        k = (L - l1) / l2; d.line((pts[0], pts[1], (pts[1][0] + (pts[2][0] - pts[1][0]) * k, pts[1][1] + (pts[2][1] - pts[1][1]) * k)), fill=FOREST, width=9, joint="curve")
def draw_checklist(p, b, u):
    d = ImageDraw.Draw(p)
    rise(p, lambda dd: spaced(dd, (80, 40), b["title"], fnt(XB, int(36 * TS)), TANK, 8, anchor="lm"), (W, 80), (0, 145), ease((u - 0.1) / 0.4))
    hl = 180 * ease((u - 0.3) / 0.4)
    if hl > 1: d.line((80, 222, 80 + hl, 222), fill=LIME, width=4)
    for n, ((wd, label), ct) in enumerate(zip(b["items"], b["items_t"])):
        lu = u - (ct - b["t"]); y = 310 + n * 115
        bx = Image.new("RGBA", (74, 74), (0, 0, 0, 0)); bd = ImageDraw.Draw(bx); bd.rounded_rectangle((0, 0, 73, 73), 14, fill=LIME); check_path(bd, 0, 0, (lu - 0.15) / 0.3)
        pop(p, bx, (117, y), back(lu / 0.35))
        rise(p, lambda dd, label=label: dd.text((185, 50), label, font=fnt(XB, int(52 * TS)), fill=CREAM, anchor="lm"), (W, 100), (0, y - 50), ease(lu / 0.3))
def draw_pin(p, b, u):
    d = ImageDraw.Draw(p); cx, cy = W / 2, 330
    rl = ease((u - 0.05) / 0.5)  # two roads draw in
    d.line((cx - 420 * rl, cy + 40, cx + 420 * rl, cy + 40), fill=SAGE, width=46)
    d.line((cx + 60, cy + 40 - 230 * rl, cx + 60, cy + 40 + 150 * rl), fill=SAGE, width=46)
    if rl > 0.9:
        for k in range(-8, 9): d.line((cx - 400 + k * 50, cy + 40, cx - 380 + k * 50, cy + 40), fill=FOREST, width=4)
    pp = back((u - 0.55) / 0.45); drop = (1 - ease((u - 0.55) / 0.45)) * -160
    if pp > 0:
        pin = Image.new("RGBA", (120, 170), (0, 0, 0, 0)); pd = ImageDraw.Draw(pin)
        pd.ellipse((10, 0, 110, 100), fill=LIME); pd.polygon([(22, 72), (98, 72), (60, 165)], fill=LIME); pd.ellipse((40, 30, 80, 70), fill=FOREST)
        pop(p, pin, (cx + 60 + 70, cy - 60 + drop), min(pp, 1.1))
    rise(p, lambda dd: [dd.text((W / 2, 30 + n * 56), ln, font=fnt(XB, 44), fill=CREAM, anchor="mm") for n, ln in enumerate(wrap(dd, b["label"], fnt(XB, 44), 900))],
         (W, 140), (0, 560), ease((u - 0.9) / 0.4))
BOXES = []           # overlays drawn this frame: (name, x0, y0, x1, y1)
CLASHES = {}         # (a, b) -> [times]
def reg(name, box): BOXES.append((name,) + tuple(int(v) for v in box))
def check_clashes(t):
    for i in range(len(BOXES)):
        for j in range(i + 1, len(BOXES)):
            a, b = BOXES[i], BOXES[j]
            if a[1] < b[3] and b[1] < a[3] and a[2] < b[4] and b[2] < a[4]:
                CLASHES.setdefault((a[0], b[0]), []).append(round(t, 2))
def report_layout():
    if CLASHES:
        for (a, b), ts in CLASHES.items():
            print(f"CLASH: {a} overlaps {b} in {len(ts)} frames, {ts[0]}s-{ts[-1]}s")
        raise SystemExit(2)
    print("layout check: no registered overlapping overlays; visual review still required")
_IMG = {}
def img(path):
    if path not in _IMG: _IMG[path] = Image.open(path).convert("RGB")
    return _IMG[path]
def photo_layer(path, u, dim=0.0, zoom_from=1.10, zoom_to=1.0, pan=(0.5, 0.5)):
    """Ken Burns photo filling the panel; dim>0 lays brand forest over it for text beats"""
    z = zoom_from + (zoom_to - zoom_from) * ease(u / 6.0)
    src = fit(img(path), int(W * 1.12), int(PANEL_H * 1.12))
    w, h = int(W * z), int(PANEL_H * z); im = src.resize((w, h), Image.BILINEAR)
    x0 = int((w - W) * pan[0]); y0 = int((h - PANEL_H) * pan[1])
    lay = im.crop((x0, y0, x0 + W, y0 + PANEL_H)).convert("RGBA")
    if dim > 0:
        ov = Image.new("RGBA", (W, PANEL_H), FOREST + (int(255 * dim),)); lay.alpha_composite(ov)
    else:  # soft bottom gradient so a credit / tag reads
        gr = Image.linear_gradient("L").resize((W, PANEL_H)).point(lambda v: int(v * 0.55))
        lay.alpha_composite(Image.merge("RGBA", (*Image.new("RGB", (W, PANEL_H), NEAR).split(), gr)))
    return lay
def draw_credit(p, b):
    if b.get("credit"): ImageDraw.Draw(p).text((W - 24, PANEL_H - 22), b["credit"], font=fnt(XB, 22), fill=CREAM + (200,), anchor="rs")
def draw_photo(p, b, u):
    tag = b.get("tag")
    if tag:
        f = fnt(XB, 42); d = ImageDraw.Draw(p); tw = d.textlength(tag, font=f)
        t_ = Image.new("RGBA", (int(tw + 48), 74), (0, 0, 0, 0)); td = ImageDraw.Draw(t_)
        td.rounded_rectangle((0, 0, tw + 47, 73), 12, fill=TANK); td.text((24, 38), tag, font=f, fill=NEAR, anchor="lm")
        pop(p, t_, (40 + t_.width / 2, 170), back((u - 0.35) / 0.35))
        if u > 0.35: reg("photo tag", (40, BOT_Y + 133, 40 + t_.width, BOT_Y + 207))
    if b.get("title"):
        f = fnt(SERIF, 64); lines = wrap(ImageDraw.Draw(p), b["title"], f, 960)
        for n, ln in enumerate(lines):
            rise(p, lambda dd, ln=ln: dd.text((60, 50), ln, font=f, fill=CREAM, anchor="lm"), (W, 100), (0, PANEL_H - 110 - (len(lines) - n) * 76), ease((u - 0.5 - n * 0.15) / 0.4))
DRAW = {"photo": draw_photo, "quote": draw_quote, "stat": draw_stat, "bars": draw_bars, "badge": draw_badge, "checklist": draw_checklist, "pin": draw_pin}

def bottom(t):
    p = textured(FOREST, W, PANEL_H, t)
    beats = cfg["beats"]
    cur_i = max([k for k, b in enumerate(beats) if b["t"] <= t] + [-1])
    if cur_i < 0: return p
    b = beats[cur_i]; u = t - b["t"]
    def base(bb, uu):
        if bb["type"] == "photo": return photo_layer(bb["img"], uu, 0.0, *bb.get("zoom", (1.10, 1.0)), tuple(bb.get("pan", (0.5, 0.5))))
        if bb.get("bg"): return photo_layer(bb["bg"], uu, bb.get("dim", 0.72))
        return textured(FOREST, W, PANEL_H, t)
    layer = base(b, u); DRAW[b["type"]](layer, b, u); draw_credit(layer, b)
    wipe = ease(u / 0.4) if cur_i > 0 else 1.0
    if cur_i > 0 and wipe < 1:  # previous beat still visible under the wipe
        prev = beats[cur_i - 1]; p = base(prev, t - prev["t"]); DRAW[prev["type"]](p, prev, t - prev["t"]); draw_credit(p, prev)
    x = int(W * (1 - wipe)); p.paste(layer.crop((0, 0, W - x, PANEL_H)), (x, 0))
    return p

# ---- template mode: GPT designs the frame, we key video/visuals into its #00FF00 windows ----
def _components(mask, min_cells=80):
    small = mask[::8, ::8]; lab = np.zeros(small.shape, int); n = 0; boxes = []
    for (y, x) in zip(*np.nonzero(small)):
        if lab[y, x]: continue
        n += 1; st = [(y, x)]; lab[y, x] = n; ys, xs = [], []
        while st:
            cy, cx = st.pop(); ys.append(cy); xs.append(cx)
            for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                ny, nx = cy + dy, cx + dx
                if 0 <= ny < small.shape[0] and 0 <= nx < small.shape[1] and small[ny, nx] and not lab[ny, nx]:
                    lab[ny, nx] = n; st.append((ny, nx))
        if len(ys) > min_cells:
            ox, oy = max(0, min(xs) * 8 - 8), max(0, min(ys) * 8 - 8); sub = mask[oy:(max(ys) + 1) * 8 + 8, ox:(max(xs) + 1) * 8 + 8]; ys_, xs_ = np.nonzero(sub)
            boxes.append((ox + xs_.min(), oy + ys_.min(), ox + xs_.max() + 1, oy + ys_.max() + 1))
    return sorted(boxes, key=lambda w: (w[1], w[0]))

def load_plate(path, crop=None):
    """GPT plate -> (RGBA plate with key areas cut out, {key: [bbox]}, {key: L mask}, content_bottom).
    Keys: #00FF00 video (or face circles on end cards), #FF00FF visual (photo/stat/checklist), #00FFFF caption zone."""
    im = Image.open(path).convert("RGB")
    if crop is not None:
        if (len(crop) != 4 or not 0 <= crop[0] < crop[2] <= im.width
                or not 0 <= crop[1] < crop[3] <= im.height):
            print(f"LAYOUT: invalid plate crop for {path}: {crop}")
            raise SystemExit(2)
        im = im.crop(tuple(crop))
    if abs((im.width / im.height) / (W / H) - 1) > 0.005:
        print(f"LAYOUT: plate aspect {im.width}x{im.height} is not 9:16: {path}. "
              "Supply an inspected template_crop/end_template_crop or regenerate at 9:16.")
        raise SystemExit(2)
    im = im.resize((W, H), Image.LANCZOS)
    a = np.array(im).astype(int); r, g, b = a[..., 0], a[..., 1], a[..., 2]
    keys = {"video": (g > 150) & (r < 150) & (b < 150) & (g - np.maximum(r, b) > 60),
            "visual": (r > 150) & (b > 150) & (g < 120) & (np.minimum(r, b) - g > 60),
            "caption": (g > 150) & (b > 150) & (r < 120) & (np.minimum(g, b) - r > 60)}
    wins, masks, hole = {}, {}, np.zeros(g.shape, bool)
    for k, m in keys.items():
        wins[k] = _components(m); hole |= m
        masks[k] = Image.fromarray((m * 255).astype(np.uint8)).filter(ImageFilter.MaxFilter(7))
    # legacy plates: two green windows = video (upper) + visual (lower); caption strip between them
    if not wins["visual"] and len(wins["video"]) >= 2:
        v, vis = wins["video"][0], wins["video"][1]; wins["video"], wins["visual"] = [v], [vis]
        mv = np.zeros(g.shape, bool); mv[v[1]:v[3], v[0]:v[2]] = keys["video"][v[1]:v[3], v[0]:v[2]]
        ms = keys["video"] & ~mv; masks["video"] = Image.fromarray((mv * 255).astype(np.uint8)).filter(ImageFilter.MaxFilter(7))
        masks["visual"] = Image.fromarray((ms * 255).astype(np.uint8)).filter(ImageFilter.MaxFilter(7))
        if not wins["caption"]: wins["caption"] = [(v[0], v[3], v[2], vis[1])]
    hm = Image.fromarray((hole * 255).astype(np.uint8)).filter(ImageFilter.MaxFilter(7))
    plate = im.convert("RGBA"); plate.putalpha(Image.fromarray(255 - np.array(hm)))
    rows = a; ref = rows[-4:].reshape(-1, 3).mean(0); diff = np.abs(rows - ref).sum(2).max(1)
    busy = np.nonzero(diff > 60)[0]; content_bottom = int(busy.max()) + 1 if len(busy) else H
    return plate, wins, masks, content_bottom

TPL = END_PLATE = None
if cfg.get("template"):
    TPL, TW_, TM_, TPL_BOTTOM = load_plate(cfg["template"], cfg.get("template_crop"))
    if not TW_["video"]: raise SystemExit("template has no green video window")
if cfg.get("end_template"):
    END_PLATE, EW_, EM_, END_BOTTOM = load_plate(cfg["end_template"], cfg.get("end_template_crop")); EWINS = sorted(EW_["video"], key=lambda w: w[0])

def _keyed(c, content, box, mask):
    """put content (cover-fit to box) into c, visible only where the plate's key mask is"""
    ww_, wh_ = box[2] - box[0], box[3] - box[1]
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); lay.alpha_composite(content.convert("RGBA").resize((ww_, wh_)) if content.size == (ww_, wh_) else fit(content.convert("RGBA"), ww_, wh_), (box[0], box[1]))
    c.paste(lay, (0, 0), Image.fromarray(np.minimum(np.array(lay.getchannel("A")), np.array(mask))))

def template_footer(c, beat, y, t, index):
    """Fill the spare lower field; introduce the speaker in a temporary bubble."""
    if not cfg.get("template_footer", True) or y >= H - 130: return
    x0, x1, y1 = 40, W - 40, H - 30
    photo = beat.get("footer_image") or beat.get("img") or beat.get("bg")
    if photo:
        panel = fit(img(photo), x1 - x0, y1 - y).convert("RGBA")
        panel.alpha_composite(Image.new("RGBA", panel.size, NEAR + (145,)))
    else:
        panel = textured(FOREST, x1 - x0, y1 - y, t).convert("RGBA")
    c.alpha_composite(panel, (x0, y))
    d = ImageDraw.Draw(c)
    bubble_cfg = cfg.get("name_bubble", {})
    start = float(bubble_cfg.get("start", 0.3))
    hold = float(bubble_cfg.get("hold", 3.2))
    exit_s = float(bubble_cfg.get("exit", 0.45))
    if start <= t < start + hold + exit_s:
        intro = ease((t - start) / 0.4)
        outro = 1.0 - ease((t - start - hold) / max(0.1, exit_s))
        opacity = min(intro, outro)
        spk_key = cfg.get("main_speaker") or next(iter(brand["speakers"]))
        speaker = brand["speakers"][spk_key]
        tag = Image.new("RGBA", (625, 124), (0, 0, 0, 0))
        td = ImageDraw.Draw(tag)
        td.rounded_rectangle((2, 2, 622, 121), 60, fill=NEAR + (242,), outline=TANK + (255,), width=4)
        if spk_key in faces:
            tag.alpha_composite(bubble(faces[spk_key], 91, TANK), (13, 6))
        else:
            td.ellipse((16, 17, 105, 106), fill=TANK)
            td.text((60, 61), RB.get("monogram", speaker["name"][:1]), font=fnt(SERIF, 40), fill=NEAR, anchor="mm")
        td.text((135, 52), speaker["name"], font=fnt(XB, 42), fill=CREAM, anchor="lm")
        td.text((135, 91), speaker.get("sub", ""), font=fnt(XB, 27), fill=TANK, anchor="lm")
        if opacity < 1: tag.putalpha(tag.getchannel("A").point(lambda value: int(value * opacity)))
        bx, by = x0 + 22, y + 16 + int((1 - intro) * 32)
        c.alpha_composite(tag, (bx, by))
        reg("speaker bubble", (bx, by, bx + tag.width, by + tag.height))
    d.text((x1 - 24, y + 65), f"{index + 1:02d} / {len(cfg['beats']):02d}", font=fnt(XB, 29), fill=CREAM, anchor="rm")
    if beat.get("footer_title"):
        c.alpha_composite(Image.new("RGBA", (x1 - x0, 111), NEAR + (178,)), (x0, y + 129))
        title = beat["footer_title"]
        font = fnt(SERIF, 58)
        while d.textlength(title, font=font) > x1 - x0 - 88 and font.size > 38: font = fnt(SERIF, font.size - 2)
        d.text((x0 + 26, y + 172), title, font=font, fill=CREAM, anchor="lm")
    credit = beat.get("footer_credit")
    if credit: d.text((x0 + 26, y + 216), credit, font=fnt(XB, 21), fill=CREAM, anchor="lm")
    seg_w = (x1 - x0 - 46 - 18 * (len(cfg["beats"]) - 1)) / len(cfg["beats"])
    for n in range(len(cfg["beats"])):
        sx = x0 + 23 + n * (seg_w + 18)
        d.rounded_rectangle((sx, y1 - 32, sx + seg_w, y1 - 24), 4, fill=TANK if n <= index else MID)

def frame_tpl(i, top):
    t = i / FPS
    BOXES.clear()
    if cfg.get("template_face_box") and t < SPEECH - END_LEAD:
        reg("face", cfg["template_face_box"])  # final canvas coordinates
    c = Image.new("RGBA", (W, H), NEAR + (255,))
    vw = TW_["video"][0]; bw = TW_["visual"][0] if TW_["visual"] else None; cz = TW_["caption"][0] if TW_["caption"] else None
    if top is not None:  # live video, gentle breathing zoom
        z = 1.0 + 0.03 * math.sin(t * 0.25); ww_, wh_ = vw[2] - vw[0], vw[3] - vw[1]
        v = fit(top, int(ww_ * z), int(wh_ * z)).crop(((int(ww_ * z) - ww_) // 2, (int(wh_ * z) - wh_) // 2, (int(ww_ * z) - ww_) // 2 + ww_, (int(wh_ * z) - wh_) // 2 + wh_))
        _keyed(c, v, vw, TM_["video"])
    active = next((b for b in reversed(cfg["beats"]) if b["t"] <= t), cfg["beats"][0] if cfg["beats"] else None)
    if bw:  # inspect an explicit content crop; preserve graphic labels at other aspect ratios
        ww_, wh_ = bw[2] - bw[0], bw[3] - bw[1]
        if active and active["type"] == "photo":
            pi = fit(img(active["img"]), ww_, wh_).convert("RGBA")
            pd = ImageDraw.Draw(pi)
            if active.get("tag"):
                label = active["tag"].upper()
                font = fnt(XB, min(38, max(26, int(ww_ * 0.039))))
                while pd.textlength(label, font=font) > ww_ - 64 and font.size > 24:
                    font = fnt(XB, font.size - 2)
                lab_w = pd.textlength(label, font=font)
                pd.rounded_rectangle((18, 15, 48 + lab_w, 64), 10, fill=TANK)
                pd.text((33, 39), label, font=font, fill=NEAR, anchor="lm")
            if active.get("credit"):
                credit = active["credit"]
                cf = fnt(XB, max(15, min(22, int(ww_ * .02))))
                cw = pd.textlength(credit, font=cf)
                pd.rounded_rectangle((max(4, ww_ - cw - 28), wh_ - 35, ww_ - 6, wh_ - 4), 4, fill=NEAR)
                pd.text((ww_ - 16, wh_ - 18), credit, font=cf, fill=CREAM, anchor="rm")
        else:
            pnl = bottom(t)
            if active and active.get("panel_crop"):
                pc = active["panel_crop"]
                if (len(pc) != 4 or not 0 <= pc[0] < pc[2] <= pnl.width
                        or not 0 <= pc[1] < pc[3] <= pnl.height):
                    raise SystemExit("Invalid panel_crop in beat")
                pnl = pnl.crop(tuple(pc))
            content = ImageOps.contain(pnl, (ww_, wh_), Image.LANCZOS)
            pi = textured(FOREST, ww_, wh_, t)
            pi.alpha_composite(content.convert("RGBA"), ((ww_ - content.width) // 2, (wh_ - content.height) // 2))
        _keyed(c, pi, bw, TM_["visual"])
    # the plate builds in: hook area wipes in from the left, everything below the video's top rises in
    split_y = vw[1]
    tp = ease((t - 0.05) / 0.55)
    if tp > 0: c.alpha_composite(TPL.crop((0, 0, max(1, int(W * tp)), split_y)), (0, 0))
    bp = ease((t - 0.15) / 0.45)
    if bp > 0:
        lay = TPL.crop((0, split_y, W, H))
        if bp < 1: lay.putalpha(lay.getchannel("A").point(lambda v_: int(v_ * bp)))
        c.alpha_composite(lay, (0, split_y + int((1 - bp) * 30)))
    if TPL_BOTTOM < H - 40:  # fill GPT's empty bottom zone: moving brand pattern + progress line
        zb = TPL_BOTTOM + 14; c.alpha_composite(textured(FOREST, W, H - zb, t, speed=10), (0, zb))
        pg = min(1.0, t / max(0.1, SPEECH)); ImageDraw.Draw(c).rounded_rectangle((60, zb + 26, 60 + max(8, int((W - 120) * pg)), zb + 34), 4, fill=LIME)
    if active and bw and cfg.get("template_footer", True):
        bi = next((n for n in range(len(cfg["beats"]) - 1, -1, -1) if cfg["beats"][n]["t"] <= t), 0)
        template_footer(c, active, bw[3] + 18, t, bi)
    # captions in the cyan zone (or the strip GPT left between windows)
    ch = None
    for n_, k in enumerate(chunks):
        end_ = k[-1]["e"] + 0.25
        if n_ + 1 < len(chunks): end_ = min(end_, chunks[n_ + 1][0]["s"] - 0.05)
        if k[0]["s"] - 0.05 <= t < end_: ch = k; break
    if ch and t < SPEECH + 0.2:
        zx0, zy0, zx1, zy1 = cz if cz else (60, vw[3], W - 60, vw[3] + 130)
        sh = max(60, zy1 - zy0); fs = int(min(84, sh * 0.62)); maxw = (zx1 - zx0) - 60
        d = ImageDraw.Draw(c); f = fnt(XB, fs); toks = [(w["w"].strip(",").upper() if UP_CAP else w["w"].strip(",")) for w in ch]
        ws_ = [d.textlength(x, font=f) for x in toks]; sp_ = int(fs * 0.3); tot = sum(ws_) + sp_ * (len(toks) - 1)
        if tot > maxw: f = fnt(XB, int(fs * maxw / tot)); ws_ = [d.textlength(x, font=f) for x in toks]; tot = sum(ws_) + sp_ * (len(toks) - 1)
        pp = back((t - ch[0]["s"]) / 0.18); y = (zy0 + zy1) / 2 + (1 - pp) * 12; x = (zx0 + zx1) / 2 - tot / 2
        if cz: d.rounded_rectangle((x - 28, y - fs * 0.72, x + tot + 28, y + fs * 0.72), RB.get("radius", 18), fill=BAR + (235,))
        reg("captions", (x - 10, zy0, x + tot + 10, zy1))
        for w, tok, tw_ in zip(ch, toks, ws_):
            act = w["s"] - 0.03 <= t < w["e"] + 0.08
            d.text((x, y), tok, font=f, fill=SPK_COL.get(w["spk"], LIME) if act else CREAM, anchor="lm"); x += tw_ + sp_
    # end card: GPT's card, faces keyed into its green shapes, slides up before the last word
    te = t - (SPEECH - END_LEAD); ep = ease(te / 0.45)
    if ep > 0 and END_PLATE is not None:
        card = Image.new("RGBA", (W, H), FOREST + (255,))
        if EW_["visual"] and BG_IMG is not None: _keyed(card, BG_IMG, EW_["visual"][0], EM_["visual"])
        spk_order = sorted([k for k in brand["speakers"] if k in faces], key=lambda k: {"left": 0, "center": 1, "right": 2}.get(brand["speakers"][k].get("side"), 1))
        for n, (k, win) in enumerate(zip(spk_order, EWINS)):
            pr = back((te - 0.35 - 0.15 * n) / 0.45)
            if pr > 0.02: _keyed(card, faces[k], win, EM_["video"])
        card.alpha_composite(END_PLATE)
        if END_BOTTOM < H - 40: card.alpha_composite(textured(FOREST, W, H - END_BOTTOM - 14, t, speed=8), (0, END_BOTTOM + 14))
        if cfg.get("end_bg_credit"): ImageDraw.Draw(card).text((W - 24, H - 24), cfg["end_bg_credit"], font=fnt(XB, 20), fill=CREAM + (190,), anchor="rs")
        yy = int(H * (1 - ep)); c.alpha_composite(card.crop((0, 0, W, H - yy)), (0, yy))
    check_clashes(t)
    return c.convert("RGB")


# ---- full-bleed mode: the speaker IS the frame; brand lives in GPT overlays + captions + punch-ins ----
OV = {k: Image.open(v).convert("RGBA").resize((int(Image.open(v).width * H / Image.open(v).height), H), Image.LANCZOS) for k, v in cfg.get("overlays", {}).items()} if FB else {}
OVBOX = {}
for k in list(OV):
    o = OV[k]; x0 = (o.width - W) // 2; o = o.crop((x0, 0, x0 + W, H))
    # optional placement: {"top": y} or {"bottom": y}, {"scale": s} -> move the element's own box, keep it centered
    pl = cfg.get("overlay_place", {}).get(k, {}); bb_ = o.getchannel("A").point(lambda v: 255 if v > 24 else 0).getbbox()
    if bb_ and (pl or k in ("hook", "lowerthird", "tag")):
        el = o.crop(bb_); sc_ = pl.get("scale", 1.0)
        if sc_ != 1.0: el = el.resize((int(el.width * sc_), int(el.height * sc_)), Image.LANCZOS)
        nx = pl.get("left", bb_[0] if sc_ == 1.0 else (W - el.width) // 2)
        ny = pl["top"] if "top" in pl else (pl["bottom"] - el.height if "bottom" in pl else bb_[1])
        o = Image.new("RGBA", (W, H), (0, 0, 0, 0)); o.alpha_composite(el, (int(nx), int(ny))); bb_ = (int(nx), int(ny), int(nx) + el.width, int(ny) + el.height)
    OV[k] = o; OVBOX[k] = bb_
CUT_T = list(np.cumsum([0] + [c["b"] - c["a"] for c in cuts]))
PUNCH = []  # (t0, t1, beat) full-screen moments: photos and stats only
if FB:
    bb = [b for b in cfg["beats"] if b["type"] in ("photo", "stat")]
    for n, b in enumerate(bb):
        t0 = max(0.4, b["t"]); t1 = min(t0 + b.get("dur", 2.6), bb[n + 1]["t"] - 0.1 if n + 1 < len(bb) else SPEECH - END_LEAD - 0.2)
        if t1 - t0 > 0.8: PUNCH.append((t0, t1, b))

def ov(c, key, t, t_in, t_out, slide=(0, 40)):
    if key not in OV: return
    a = ease((t - t_in) / 0.35) * (1 - ease((t - (t_out - 0.3)) / 0.3))
    if a <= 0: return
    o = OV[key]
    if OVBOX.get(key) and a > 0.5 and key != "stat": reg(key, OVBOX[key])
    if a < 1: o = o.copy(); o.putalpha(o.getchannel("A").point(lambda v: int(v * a)))
    c.alpha_composite(o, (int(slide[0] * (1 - a)), int(-slide[1] * (1 - a))))

def frame_fb(i, top):
    t = i / FPS
    BOXES.clear()
    if cfg.get("face_box") and t < SPEECH - END_LEAD:
        reg("face", cfg["face_box"])  # full-bleed plans already use canvas coordinates
    c = Image.new("RGBA", (W, H), NEAR + (255,))
    if top is not None:
        k = max(0, int(np.searchsorted(CUT_T, t, side="right")) - 1)
        z = (1.0 if k % 2 == 0 else 1.13) * (1.0 + 0.015 * math.sin(t * 0.4))   # jump-cut zoom per piece + breathing
        fw, fh = int(W * z), int(H * z); f_ = top.resize((fw, fh), Image.BILINEAR)
        oy = int((fh - H) * 0.35)  # zoom toward the face (upper part), not the chest
        c.paste(f_.crop(((fw - W) // 2, oy, (fw - W) // 2 + W, oy + H)), (0, 0))
        # soft top/bottom gradients so overlays and captions read
        g = Image.linear_gradient("L").resize((W, 520)); c.alpha_composite(Image.merge("RGBA", (*Image.new("RGB", (W, 520), NEAR).split(), g.point(lambda v: int(v * 0.55)))), (0, H - 520))
        gt = g.transpose(Image.FLIP_TOP_BOTTOM).resize((W, 420)); c.alpha_composite(Image.merge("RGBA", (*Image.new("RGB", (W, 420), NEAR).split(), gt.point(lambda v: int(v * 0.45)))), (0, 0))
    # full-screen punch-ins
    for t0, t1, b in PUNCH:
        if t0 <= t < t1:
            u = t - t0; a = ease(u / 0.25) * (1 - ease((t - (t1 - 0.25)) / 0.25))
            if b["type"] == "photo":
                ph = fit(img(b["img"]), int(W * 1.12), int(H * 1.12)); z2 = 1.12 - 0.1 * ease(u / (t1 - t0))
                pw, pH = int(W * z2), int(H * z2); ph = ph.resize((pw, pH), Image.BILINEAR).crop(((pw - W) // 2, (pH - H) // 2, (pw - W) // 2 + W, (pH - H) // 2 + H)).convert("RGBA")
                if a < 1: ph.putalpha(int(255 * a))
                c.alpha_composite(ph)
                ov(c, "tag", t, t0 + 0.2, t1)
                if b.get("credit"): ImageDraw.Draw(c).text((W - 30, H - 330), b["credit"], font=fnt(XB, 22), fill=CREAM + (200,), anchor="rs")
            elif b["type"] == "stat" and "stat" in OV:
                ov(c, "stat", t, t0, t1, slide=(0, 0))
    # hook card, then lower third
    ov(c, "hook", t, 0.15, cfg.get("hook_out", 3.8))
    ov(c, "lowerthird", t, cfg.get("hook_out", 3.8) + 0.2, cfg.get("hook_out", 3.8) + 4.2, slide=(-60, 0))
    # captions: big, low-center
    ch = None
    for n_, k2 in enumerate(chunks):
        end_ = k2[-1]["e"] + 0.25
        if n_ + 1 < len(chunks): end_ = min(end_, chunks[n_ + 1][0]["s"] - 0.05)
        if k2[0]["s"] - 0.05 <= t < end_: ch = k2; break
    if ch and t < SPEECH + 0.2:
        d = ImageDraw.Draw(c); fs = RB.get("fb_caption_size", 92); f = fnt(XB, fs)
        toks = [(w["w"].strip(",").upper() if UP_CAP else w["w"].strip(",")) for w in ch]
        ws_ = [d.textlength(x, font=f) for x in toks]; sp_ = int(fs * 0.28); tot = sum(ws_) + sp_ * (len(toks) - 1)
        if tot > 920: f = fnt(XB, int(fs * 920 / tot)); ws_ = [d.textlength(x, font=f) for x in toks]; tot = sum(ws_) + sp_ * (len(toks) - 1)
        pp = back((t - ch[0]["s"]) / 0.16); y = RB.get("fb_caption_y", 1330) + (1 - pp) * 16; x = (W - tot) / 2
        d.rounded_rectangle((x - 30, y - fs * 0.74, x + tot + 30, y + fs * 0.74), RB.get("radius", 18), fill=BAR + (235,))
        reg("captions", (x - 30, y - fs * 0.74, x + tot + 30, y + fs * 0.74))
        for w, tok, tw_ in zip(ch, toks, ws_):
            act = w["s"] - 0.03 <= t < w["e"] + 0.08
            d.text((x, y), tok, font=f, fill=SPK_COL.get(w["spk"], LIME) if act else CREAM, anchor="lm"); x += tw_ + sp_
    # end card (GPT plate, faces keyed), slides up before the last word
    te = t - (SPEECH - END_LEAD); ep = ease(te / 0.45)
    if ep > 0 and END_PLATE is not None:
        card = Image.new("RGBA", (W, H), FOREST + (255,))
        if EW_["visual"] and BG_IMG is not None: _keyed(card, BG_IMG, EW_["visual"][0], EM_["visual"])
        spk_order = sorted([k for k in brand["speakers"] if k in faces], key=lambda k: {"left": 0, "center": 1, "right": 2}.get(brand["speakers"][k].get("side"), 1))
        for n, (k, win) in enumerate(zip(spk_order, EWINS)):
            if back((te - 0.35 - 0.15 * n) / 0.45) > 0.02: _keyed(card, faces[k], win, EM_["video"])
        card.alpha_composite(END_PLATE)
        if END_BOTTOM < H - 40: card.alpha_composite(textured(FOREST, W, H - END_BOTTOM - 14, t, speed=8), (0, END_BOTTOM + 14))
        yy = int(H * (1 - ep)); c.alpha_composite(card.crop((0, 0, W, H - yy)), (0, yy))
    check_clashes(t)
    return c.convert("RGB")

def frame(i, top):
    if FB: return frame_fb(i, top)
    if TPL is not None: return frame_tpl(i, top)
    t = i / FPS
    BOXES.clear()
    c = Image.new("RGBA", (W, H), NEAR + (255,))
    if top is not None:
        z = 1.0 + 0.04 * math.sin(t * 0.25)  # gentle breathing zoom
        tw, th = int(W * z), int(PANEL_H * z); ti = top.resize((tw, th), Image.BILINEAR)
        c.paste(ti.crop(((tw - W) // 2, (th - PANEL_H) // 2, (tw - W) // 2 + W, (th - PANEL_H) // 2 + PANEL_H)), (0, PANEL_TOP))
    c.alpha_composite(bottom(t), (0, BOT_Y))
    c.alpha_composite(textured(FOREST, W, PANEL_TOP, t, speed=10), (0, 0))
    for n, (line, y) in enumerate(zip(cfg["hook"], (88, 170))):
        pr = ease((t - 0.08 - n * 0.22) / 0.35)
        ln_ = line.upper() if UP_HEAD else line; hf = fnt(SERIF, RB.get("hook_size", 70))
        base_col = C.get((RB.get("hook_colors") or ["cream", "cream"])[min(n, 1)], CREAM)
        def draw_hook(dd, ln_=ln_, base_col=base_col, hf=hf):
            # *word* = accent word (brand "hook_accent" color); hook_colors = per-line base color
            toks = ln_.split(" "); wsp = dd.textlength(" ", font=hf)
            parts = [(t.strip("*"), t.startswith("*") and t.rstrip(".,?!\"").endswith("*")) for t in toks]
            tot = sum(dd.textlength(p, font=hf) for p, _ in parts) + wsp * (len(parts) - 1); x = (W - tot) / 2
            for p, acc in parts:
                dd.text((x, 50), p, font=hf, fill=C.get(RB.get("hook_accent", "tan"), TANK) if acc else base_col, anchor="lm"); x += dd.textlength(p, font=hf) + wsp
        if RB.get("hook_glow") and pr > 0:
            gl = Image.new("RGBA", (W, 100), (0, 0, 0, 0)); draw_hook(ImageDraw.Draw(gl)); gl = gl.filter(ImageFilter.GaussianBlur(10))
            gl.putalpha(gl.getchannel("A").point(lambda v: int(min(255, v * 1.6) * pr * 0.7))); c.alpha_composite(gl, (0, int(y - 50 + (1 - pr) * 26)))
        rise(c, draw_hook, (W, 100), (0, y - 50), pr, 26)
    rp = ease((t - 0.5) / 0.5)
    if rp > 0: ImageDraw.Draw(c).line((W / 2 - 170 * rp, 226, W / 2 + 170 * rp, 226), fill=TANK, width=4)
    # Brief speaker ID: Oak Street stacks it below the spoken captions.
    sp = brand["speakers"]; main = cfg.get("main_speaker", "tim")
    if cfg.get("face_box"):  # protect the speaker's head: nothing may be drawn on it
        fx0, fy0, fx1, fy1 = cfg["face_box"]; reg("face", (fx0, PANEL_TOP + fy0, fx1, PANEL_TOP + fy1))
    lp = ease((t - 1.0) / 0.4) * (1 - ease((t - 6.0) / 0.4))
    if lp > 0:
        nf, sf = fnt(XB, 34), fnt(XB, 24)
        dd0 = ImageDraw.Draw(Image.new("RGB", (1, 1))); tw = max(dd0.textlength(sp[main]["name"], font=nf), dd0.textlength(sp[main]["sub"], font=sf))
        bw, bh = int(122 + tw + 28), 92
        lt = Image.new("RGBA", (bw, bh), (0, 0, 0, 0)); ld = ImageDraw.Draw(lt)
        ld.rounded_rectangle((0, 0, bw - 1, bh - 1), 12, fill=NEAR + (230,))
        if ICON is not None:
            icon = ICON.resize((62, int(62 * ICON.height / ICON.width)), Image.LANCZOS)
            if icon.height > 70: icon = ICON.resize((int(70 * ICON.width / ICON.height), 70), Image.LANCZOS)
            lt.alpha_composite(icon, (20 + (62 - icon.width) // 2, (bh - icon.height) // 2))
        else:  # monogram disc
            ld.ellipse((20, 15, 82, 77), fill=LIME); ld.text((51, 47), RB.get("monogram", sp[main]["name"][:1]), font=fnt(SERIF, 30), fill=NEAR, anchor="mm")
        ld.line((98, 20, 98, 72), fill=TANK, width=3)
        ld.text((116, 34), sp[main]["name"], font=nf, fill=CREAM, anchor="lm"); ld.text((116, 68), sp[main]["sub"], font=sf, fill=SAGE, anchor="lm")
        lt.putalpha(lt.getchannel("A").point(lambda v: int(v * lp)))
        if RB.get("name_below_captions"):
            # Caption box ends at BOT_Y + 52; this leaves a clear gap and
            # keeps the ID above the first supporting-graphic text line.
            lx, ly = int(W - bw - 30 + (1 - lp) * 60), BOT_Y + 80
        else:
            lx, ly = int(30 - (1 - lp) * 60), BOT_Y - 10 - 62 - 16 - bh
        c.alpha_composite(lt, (lx, ly)); reg("name bar", (lx, ly, lx + bw, ly + bh))
    # captions on the seam
    ch = None
    for n_, k in enumerate(chunks):
        end_ = k[-1]["e"] + 0.25
        if n_ + 1 < len(chunks): end_ = min(end_, chunks[n_ + 1][0]["s"] - 0.05)
        if k[0]["s"] - 0.05 <= t < end_: ch = k; break
    if ch and t < SPEECH + 0.2:
        d = ImageDraw.Draw(c); f = fnt(XB, 80); toks = [(w["w"].strip(",").upper() if UP_CAP else w["w"].strip(",")) for w in ch]
        ws_ = [d.textlength(x, font=f) for x in toks]; sp_ = 24; tot = sum(ws_) + sp_ * (len(toks) - 1)
        if tot > 920: f = fnt(XB, int(80 * 920 / tot)); ws_ = [d.textlength(x, font=f) for x in toks]; tot = sum(ws_) + sp_ * (len(toks) - 1)
        pp = back((t - ch[0]["s"]) / 0.18); y = BOT_Y - 10 + (1 - pp) * 18; bw = tot + 80
        d.rounded_rectangle(((W - bw) / 2, y - 62, (W + bw) / 2, y + 62), RB.get("radius", 20), fill=BAR); x = (W - tot) / 2
        reg("captions", ((W - bw) / 2, y - 62, (W + bw) / 2, y + 62))
        for w, tok, tw_ in zip(ch, toks, ws_):
            act = w["s"] - 0.03 <= t < w["e"] + 0.08
            d.text((x, y), tok, font=f, fill=SPK_COL.get(w["spk"], LIME) if act else CREAM, anchor="lm"); x += tw_ + sp_
    # end card
    te = t - (SPEECH - END_LEAD); ep = ease(te / 0.45)
    if ep > 0:
        if BG_IMG:
            zc = 1.08 - 0.06 * ease(te / 3.0); pb = fit(BG_IMG, int(W * zc), int(H * zc)).filter(ImageFilter.GaussianBlur(3)).convert("RGBA")
            card = pb.crop(((pb.width - W) // 2, (pb.height - H) // 2, (pb.width - W) // 2 + W, (pb.height - H) // 2 + H))
            ov = textured(FOREST, W, H, t, speed=8); ov.putalpha(212); card.alpha_composite(ov)
        else: card = textured(FOREST, W, H, t, speed=8)
        cd = ImageDraw.Draw(card)
        order = [k for k in sp if k in faces]
        for n, k in enumerate(order):
            side = {"left": -1, "right": 1}.get(sp[k].get("side"), 0); delay = 0.15 + 0.15 * n; pr = back((te - delay) / 0.5)
            if pr <= 0.02: continue
            cx = W / 2 + side * 250 + (side or 1) * (1 - min(pr, 1)) * (420 if side else 0); cy = 330
            bb = bubble(faces[k], 230, C[sp[k]["ring"]]); card.alpha_composite(bb, (int(cx - bb.width / 2), int(cy - bb.height / 2)))
            na = ease((te - delay - 0.3) / 0.35)
            rise(card, lambda dd, s=sp[k]["name"]: dd.text((250, 30), s, font=fnt(XB, 40), fill=CREAM, anchor="mm"), (500, 60), (cx - 250, cy + 140), na)
            rise(card, lambda dd, s=sp[k]["sub"]: dd.text((250, 25), s, font=fnt(XB, 28), fill=SAGE, anchor="mm"), (500, 50), (cx - 250, cy + 190), na)
        if LOGO is not None:
            lw_ = RB.get("logo_width", 620); lg = LOGO.resize((lw_, int(lw_ * LOGO.height / LOGO.width)), Image.LANCZOS)
            if lg.height > 340: lg = LOGO.resize((int(340 * LOGO.width / LOGO.height), 340), Image.LANCZOS)
            pop(card, lg, (W / 2, 700 + lg.height / 2), back((te - 0.6) / 0.5)); y0 = 700 + lg.height + 110
        else: y0 = 800
        ll = 60 * ease((te - 0.7) / 0.35)
        if ll > 1: cd.line((W / 2 - ll, y0 - 50, W / 2 + ll, y0 - 50), fill=TANK, width=4)
        rise(card, lambda dd: dd.text((W / 2, 40), brand["end_card"]["follow_line"], font=fnt(XB, 42), fill=TANK, anchor="mm"), (W, 80), (0, y0 - 30), ease((te - 0.8) / 0.35))
        _w = brand["show"].split(); _k = min(range(1, len(_w)), key=lambda k: abs(len(" ".join(_w[:k])) - len(" ".join(_w[k:])))) if len(_w) > 1 else 1
        show = [" ".join(_w[:_k]), " ".join(_w[_k:])]
        if UP_HEAD: show = [x.upper() for x in show]
        rise(card, lambda dd: dd.text((W / 2, 50), show[0], font=fnt(SERIF, 64), fill=CREAM, anchor="mm"), (W, 100), (0, y0 + 45), ease((te - 0.95) / 0.4))
        rise(card, lambda dd: dd.text((W / 2, 50), show[1], font=fnt(SERIF, 64), fill=CREAM, anchor="mm"), (W, 100), (0, y0 + 120), ease((te - 1.1) / 0.4))
        pl = Image.new("RGBA", (560, 90), (0, 0, 0, 0)); pd = ImageDraw.Draw(pl); pd.rounded_rectangle((0, 0, 559, 89), 45, fill=LIME)
        pd.text((280, 46), brand["end_card"]["link_line"], font=fnt(XB, 38), fill=NEAR, anchor="mm"); pop(card, pl, (W / 2, y0 + 335), back((te - 1.35) / 0.4))
        s_ = ease((te - 0.5) / 0.5)
        if s_ > 0:
            strip = Image.new("RGBA", (W, 100), TANK + (255,)); _tg = brand["tagline"].upper(); _fs = 32
            while _fs > 18 and sum(ImageDraw.Draw(strip).textlength(ch, font=fnt(XB, _fs)) for ch in _tg) + 10 * len(_tg) > W - 80: _fs -= 1
            spaced(ImageDraw.Draw(strip), (W / 2, 50), _tg, fnt(XB, _fs), NEAR, 10)
            card.alpha_composite(strip.crop((0, 0, int(W * s_), 100)), (0, H - 190))
        yy = int(H * (1 - ep)); c.alpha_composite(card.crop((0, 0, W, H - yy)), (0, yy))
    check_clashes(t)
    return c.convert("RGB")

if "--stills" in sys.argv:  # style frames for approval: render single moments to PNG, no video/audio
    ts = [float(x) for x in sys.argv[sys.argv.index("--stills") + 1].split(",")]
    pngs = []
    for t in ts:
        acc, top = 0.0, None
        for c_ in cuts:
            if t < acc + (c_["b"] - c_["a"]) or c_ is cuts[-1]:
                st = c_["a"] + min(t - acc, c_["b"] - c_["a"] - 0.05)
                raw = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{max(0, st):.3f}", "-i", VSRC, "-frames:v", "1", "-vf",
                                      f"crop={TW}:{TH}:{TX}:{TY},scale={OUT_W}:{OUT_H}:flags=lanczos,eq=contrast=1.05:saturation=1.06", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                                     capture_output=True).stdout
                if len(raw) == OUT_W * OUT_H * 3: top = Image.frombytes("RGB", (OUT_W, OUT_H), raw)
                break
            acc += c_["b"] - c_["a"]
        fn = f"{cfg['out']}.still_{t:.1f}.png"; frame(int(t * FPS), top).save(fn); pngs.append(fn)
    sheet = Image.new("RGB", (W // 2 * len(pngs) + 20 * (len(pngs) - 1), H // 2), "white")
    for k, fn in enumerate(pngs): sheet.paste(Image.open(fn).resize((W // 2, H // 2)), (k * (W // 2 + 20), 0))
    sheet.save(cfg["out"] + ".stills.jpg", quality=90)
    print("stills", cfg["out"] + ".stills.jpg")
    report_layout()
    sys.exit(0)

out = cfg["out"]; tmpv = out + ".v.mp4"
enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                        "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", tmpv], stdin=subprocess.PIPE)
for i in range(N):
    enc.stdin.write(frame(i, next(frames)).tobytes())  # live video keeps running under the incoming end card
enc.stdin.close(); enc.wait()
if enc.returncode:
    raise SystemExit(f"Video encoder failed with exit {enc.returncode}")
report_layout()  # preserve the draft picture for diagnosis; do not publish a failed render

# ---- audio --------------------------------------------------------------------
parts = []
for k, c in enumerate(cuts):
    a, b = c["a"], c["b"]; af = f"atrim={a:.3f}:{b:.3f},asetpts=PTS-STARTPTS"
    if not (k > 0 and abs(cuts[k - 1]["b"] - a) < 0.03): af += ",afade=t=in:d=0.02"
    if not (k + 1 < len(cuts) and abs(cuts[k + 1]["a"] - b) < 0.03): af += f",afade=t=out:st={b - a - 0.02:.3f}:d=0.02"
    fn = f"{out}.p{k}.wav"; subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", cfg["source"], "-vn", "-af", af, "-ar", "48000", "-ac", "2", fn], check=True); parts.append(fn)
open(out + ".list", "w").write("".join(f"file '{os.path.abspath(p)}'\n" for p in parts))
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", out + ".list", "-af", f"apad=pad_dur={TAIL + 1}", out + ".speech.wav"], check=True)
sr = 48000; tt = np.arange(int((DUR + 0.5) * sr)) / sr; mus = np.zeros_like(tt)
chords = [[220.0, 261.63, 329.63], [174.61, 220.0, 261.63], [261.63, 329.63, 392.0], [196.0, 246.94, 293.66]]
for n, chd in enumerate(chords * 8):
    s0 = n * 2.4; m = (tt >= s0) & (tt < s0 + 3.0)
    if not m.any(): continue
    env = np.clip((tt[m] - s0) / 0.4, 0, 1) * np.clip((s0 + 3.0 - tt[m]) / 0.6, 0, 1)
    for f0 in chd:
        for det in (-0.6, 0.6): mus[m] += env * (np.sin(2 * np.pi * (f0 + det) * tt[m]) + 0.3 * np.sin(4 * np.pi * (f0 + det) * tt[m]))
    mus[m] += 0.8 * env * np.sin(np.pi * chd[0] * tt[m])
lift = np.clip((tt - 2.0) / 2.0, 0, 1); pulse = (0.5 + 0.5 * np.cos(2 * np.pi * tt * 100 / 60 * 2)) ** 6
mus = mus * (0.55 + 0.45 * lift) * (0.75 + 0.25 * pulse * lift)
for bt_ in np.arange(2.0, DUR, 0.6):
    k0 = int(bt_ * sr); kl = int(0.25 * sr)
    if k0 + kl < len(mus): kt = np.arange(kl) / sr; mus[k0:k0 + kl] += 2.2 * np.sin(2 * np.pi * (50 + 60 * np.exp(-kt * 30)) * kt) * np.exp(-kt * 14)
mus /= np.abs(mus).max(); mus *= np.clip((DUR + 0.5 - tt) / 1.2, 0, 1) * np.clip(tt / 0.3, 0, 1)
with wave.open(out + ".music.wav", "wb") as wf:
    wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(sr); wf.writeframes((mus * 0.9 * 32767).astype(np.int16).tobytes())
pool = sorted(glob.glob(SFX + "swooshes/*.wav")); random.seed(len(cfg["beats"]) * 7)
hits = [(0.05, SFX + "hook-air-swoosh.wav", 0.35)] + [(b["t"], random.choice(pool), 0.15) for b in cfg["beats"]] + [(SPEECH - END_LEAD, SFX + "hook-air-swoosh.wav", 0.3)]
ins = ["-i", out + ".speech.wav", "-i", out + ".music.wav"]; fl = ["[1:a]lowpass=f=2400,volume=0.11,aformat=channel_layouts=stereo[m]"]
for n, (at, f, v) in enumerate(hits):
    ins += ["-i", f]; fl.append(f"[{n + 2}:a]adelay={int(max(0, at) * 1000)}|{int(max(0, at) * 1000)},volume={v},aformat=channel_layouts=stereo[s{n}]")
fl.append("[0:a][m]" + "".join(f"[s{n}]" for n in range(len(hits))) + f"amix=inputs={len(hits) + 2}:normalize=0:duration=first,atrim=0:{DUR:.3f},loudnorm=I=-14:TP=-1.5[a]")
subprocess.run(["ffmpeg", "-v", "error", "-y", *ins, "-filter_complex", ";".join(fl), "-map", "[a]", "-ar", "48000", out + ".mix.wav"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", tmpv, "-i", out + ".mix.wav", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", out], check=True)
for f in parts + [out + ".list", out + ".speech.wav", out + ".music.wav", out + ".mix.wav", tmpv]: os.remove(f)
print("done", out, f"{DUR:.2f}s", "beats at", [round(b["t"], 2) for b in cfg["beats"]])
