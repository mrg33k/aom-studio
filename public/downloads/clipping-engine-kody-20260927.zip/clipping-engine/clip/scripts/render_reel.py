#!/usr/bin/env python3
"""Short text-only Reel from raw shots (POV / listicle / before-after), in the client's GPT series look.

  /usr/bin/python3 scripts/render_reel.py reel.json OUT.mp4

reel.json:
{
  "brand": "brand-kits/ambition-mechanical/brand.json",
  "src_root": "/Volumes/.../20260901 Elephante",
  "size": [1080, 1920], "fps": 24,
  "shots": [{"src": "Ronin4D/B007C0271_...MOV", "in": 13.0, "dur": 2.8, "cx": 0.45, "zoom": 0.05, "lift": 1.2}],
  "beats": [{"t0": 0.0, "t1": 5.4, "headline": [{"text": "THE BOLT", "slab": true}, {"text": "WON'T TURN."}],
             "sentence": "optional"}],
  "end_card": {"dur": 2.2, "lines": [{"text": "FOLLOW FOR MORE", "slab": true}], "sub": "Commercial HVAC in the Valley"},
  "music": {"file": "~/Downloads/MUSIC/mixkit_628_driving_corporate_full.mp3", "start": 40, "gain_db": -6},
  "swoosh": "corner/users/aom/agents/content-agent/audio/sfx/swooshes/01-air-swoosh-1.wav"
}

- Picture only from the shots (crew audio is often unusable); music bed + a soft swoosh on each headline.
- Reels zones are enforced: text stays in the top 75%, clear of the bottom 18% and the right 10%.
- Hard cuts on shot boundaries; each shot pushes in slowly. Headlines animate with `typestyle`.
- Overlay boxes are registered per frame; any clash or zone breach fails the render (exit 2).
"""
import json, os, subprocess, sys
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
REPO = os.path.abspath(os.path.join(SKILL, "../../.."))
sys.path.insert(0, HERE)
from clipkit.core import font, rgb, place, prog, ease_out  # noqa: E402
from clipkit.typestyle import Headline, sentence_block  # noqa: E402
from render_post import Registry, decode_bg, zoom_frame, shade, load_plate  # noqa: E402


def main():
    spec_path, out = sys.argv[1], sys.argv[2]
    spec = json.load(open(spec_path))
    bpath = os.path.join(SKILL, spec["brand"]); brand = json.load(open(bpath))
    slug = os.path.basename(os.path.dirname(bpath))
    W, H = spec["size"]; fps = spec.get("fps", 24)
    reg = Registry(W, H, True)
    base = os.path.dirname(os.path.abspath(spec_path))
    rp = lambda q: q if os.path.isabs(q) else os.path.join(base, q)
    plate, wins = load_plate(rp(spec["plate"]), W, H) if spec.get("plate") else (None, [])
    wx, wy, wx1, wy1 = wins[0] if wins else (0, 0, W, H)
    ww, wh = (wx1 - wx) // 2 * 2, (wy1 - wy) // 2 * 2
    endp = load_plate(rp(spec["end_plate"]), W, H)[0] if spec.get("end_plate") else None
    shots = []
    t = 0.0
    for s in spec["shots"]:
        n = int(round(s["dur"] * fps))
        frames, s2o, (OW, OH) = decode_bg(s, spec["src_root"], ww, wh, n)
        shots.append((t, n, frames, OW, OH, s)); t += n / fps
    body = t
    ec = spec.get("end_card")
    total = body + (ec["dur"] if ec else 0)
    N = int(round(total * fps))
    sh = shade(W, H, brand["roles"]["bg"])
    heads = [(b, Headline(brand, b["headline"], measure=b.get("measure", 860), max_size=b.get("max_size", 210))) for b in spec["beats"]]
    badge = Image.open(os.path.join(SKILL, "brand-kits", slug, brand["assets"]["logo"])).convert("RGBA")
    ecl = Headline(brand, ec["lines"], measure=760) if ec else None
    tmp = out + ".video.mp4"
    enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(fps),
                            "-i", "-", "-c:v", "libx264", "-crf", "17", "-preset", "medium", "-pix_fmt", "yuv420p",
                            "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709", tmp], stdin=subprocess.PIPE)
    for k in range(N):
        tt = k / fps
        reg.reset()
        if tt < body:
            st, n, frames, OW, OH, s = [x for x in shots if x[0] <= tt + 1e-6][-1]
            kk = min(int(round((tt - st) * fps)), n - 1)
            img, o2c, _ = zoom_frame(frames[kk], kk, n, s.get("zoom", 0.05), ww, wh, OW, OH)
            if plate is not None:  # template mode: shot keyed into the GPT plate's window
                c = Image.new("RGBA", (W, H), rgb(brand["roles"]["bg"]) + (255,))
                fi = img.convert("RGBA")
                g = (np.clip(1 - np.arange(wh)[:, None] / 260.0, 0, 1) ** 1.6 * 180).repeat(ww, 1).astype(np.uint8)
                Ls = Image.new("RGBA", (ww, wh), rgb(brand["roles"]["bg"]) + (0,)); Ls.putalpha(Image.fromarray(g)); fi.alpha_composite(Ls)
                c.alpha_composite(fi, (wx, wy)); c.alpha_composite(plate)
                for fb in s.get("faces", []):
                    reg.add("face", (fb[0] * W, fb[1] * H, fb[2] * W, fb[3] * H), text=False)
                for b, hl in heads:
                    if b["t0"] <= tt < b["t1"]:
                        x, y = 62, int(spec.get("headline_y", 0.045) * H)
                        hl.draw(c, x, y, tt - b["t0"], start=0.0)
                        reg.add("headline", (x, y, x + hl.width, y + hl.height))
                enc.stdin.write(c.convert("RGB").tobytes())
                continue
            drop = int(H * s.get("drop", spec.get("drop", 0.0)))  # push footage down: headline band on brand bg
            c = Image.new("RGBA", (W, H), rgb(brand["roles"]["bg"]) + (255,))
            ph = img.convert("RGBA").crop((0, 0, W, H - drop))
            fe = min(220, H - drop)  # feather the top edge into the band: no hard line behind the headline
            ph.putalpha(Image.fromarray((np.clip(np.arange(H - drop)[:, None] / fe, 0, 1) ** 1.5 * 255).repeat(W, 1).astype(np.uint8)))
            c.alpha_composite(ph, (0, drop))
            c.alpha_composite(sh)
            for fb in s.get("faces", []):  # output-fraction boxes of faces in this shot (after drop)
                reg.add("face", (fb[0] * W, fb[1] * H, fb[2] * W, fb[3] * H), text=False)
            for b, hl in heads:
                if b["t0"] <= tt < b["t1"]:
                    x, y = 62, int(H * 0.09)
                    hl.draw(c, x, y, tt - b["t0"], start=0.0)
                    reg.add("headline", (x, y, x + hl.width, y + hl.height))
                    if b.get("sentence"):
                        yy = y + hl.height + 30
                        bh = sentence_block(c, brand, b["sentence"], x + 6, yy, 820, tt - b["t0"], 0.4)
                        reg.add("sentence", (x, yy, x + 820, yy + bh))
        elif endp is not None:  # end card on the GPT end plate: badge in the red ring, follow line on the slab
            te = tt - body
            c = Image.new("RGBA", (W, H), rgb(brand["roles"]["bg"]) + (255,)); c.alpha_composite(endp)
            if "ring" not in spec:
                a_ = np.asarray(endp.convert("RGB")).astype(int)
                red = (a_[..., 0] > 170) & (a_[..., 1] < 90) & (a_[..., 2] < 90)
                # density, not any-red: GPT scatters red halftone dots in the corners
                rr = np.where(red.mean(1) > 0.3)[0]; rr = rr[rr > H * 0.5]
                sy0_, sy1_ = int(rr.min()), int(rr.max())
                cc = np.where(red[sy0_:sy1_ + 1].mean(0) > 0.5)[0]
                spec["slab"] = (int(cc.min()), sy0_, int(cc.max()), sy1_)
                band = red[int(H * 0.08): sy0_ - 20, int(W * 0.1): int(W * 0.9)]
                ry = np.where(band.mean(1) > 0.015)[0]; rx = np.where(band.mean(0) > 0.015)[0]
                spec["ring"] = (int(rx.min() + W * 0.1), int(ry.min() + H * 0.08), int(rx.max() + W * 0.1), int(ry.max() + H * 0.08))
            rx0, ry0, rx1, ry1 = spec["ring"]; sx0, sy0, sx1, sy1 = spec["slab"]
            q = ease_out(prog(te, 0.0, 0.35))
            bs = int((rx1 - rx0) * 0.78)
            b2 = badge.resize((bs, int(bs * badge.height / badge.width)), Image.LANCZOS)
            place(c, b2, (rx0 + rx1) / 2, (ry0 + ry1) / 2, "mm", 0.7 + 0.3 * q, q)
            reg.add("badge", (rx0, ry0, rx1, ry1), text=False)
            from clipkit.typestyle import text_ink, style_of
            ink = text_ink(ec["lines"][0]["text"].upper(), style_of(brand), None, min((sx1 - sx0) * 0.84, W * 0.62))
            if ink.height > (sy1 - sy0) * 0.7:
                ink = text_ink(ec["lines"][0]["text"].upper(), style_of(brand), int((sy1 - sy0) * 0.62))
            qa = prog(te, 0.25, 0.25)
            if qa > 0:
                place(c, ink, (sx0 + sx1) / 2, (sy0 + sy1) / 2, "mm", 1.12 - 0.12 * ease_out(qa), min(1, qa * 2))
            reg.add("endline", ((sx0 + sx1) / 2 - ink.width / 2, (sy0 + sy1) / 2 - ink.height / 2, (sx0 + sx1) / 2 + ink.width / 2, (sy0 + sy1) / 2 + ink.height / 2))
            from PIL import ImageDraw
            a2 = prog(te, 0.6, 0.3)
            L = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(L)
            sub_y = min(sy1 + 56, H * 0.82 - 40)   # stay above the platform caption zone
            fs = font("BarlowCondensed-SemiBold", 46)
            d.text((W / 2, sub_y), ec.get("sub", ""), font=fs, fill=(255, 255, 255, 255), anchor="mm")
            L.putalpha(L.getchannel("A").point(lambda v: int(v * a2))); c.alpha_composite(L)
            tw_ = fs.getlength(ec.get("sub", "")); reg.add("sub", (W / 2 - tw_ / 2, sub_y - 24, W / 2 + tw_ / 2, sub_y + 24))
        else:
            te = tt - body
            c = Image.new("RGBA", (W, H), rgb(brand["roles"]["bg"]) + (255,))
            last = shots[-1]
            bg, _, _ = zoom_frame(last[2][-1], last[1] - 1, last[1], last[5].get("zoom", 0.05), W, H, last[3], last[4])
            bg = bg.convert("RGBA"); bg.putalpha(int(255 * 0.28)); c.alpha_composite(bg)
            q = ease_out(prog(te, 0.0, 0.35))
            bs = 300
            b2 = badge.resize((bs, int(bs * badge.height / badge.width)), Image.LANCZOS)
            place(c, b2, W / 2, H * 0.36, "mm", 0.7 + 0.3 * q, q)
            reg.add("badge", (W / 2 - bs / 2, H * 0.36 - bs / 2, W / 2 + bs / 2, H * 0.36 + bs / 2))
            ex = (W - ecl.width) / 2; ey = H * 0.36 + bs / 2 + 60
            ecl.draw(c, ex, ey, te, start=0.25)
            reg.add("endline", (ex, ey, ex + ecl.width, ey + ecl.height))
            if ec.get("sub"):
                f = font("BarlowCondensed-SemiBold", 46); sub = ec["sub"]
                a = prog(te, 0.6, 0.3)
                L = Image.new("RGBA", (W, 60), (0, 0, 0, 0))
                from PIL import ImageDraw
                ImageDraw.Draw(L).text((W / 2, 30), sub, font=f, fill=(255, 255, 255, 255), anchor="mm")
                L.putalpha(L.getchannel("A").point(lambda v: int(v * a)))
                sy = int(ey + ecl.height + 40); c.alpha_composite(L, (0, sy))
                tw = f.getlength(sub); reg.add("sub", ((W - tw) / 2, sy, (W + tw) / 2, sy + 60))
                u = brand.get("url", "")
                if u:
                    L2 = Image.new("RGBA", (W, 60), (0, 0, 0, 0))
                    ImageDraw.Draw(L2).text((W / 2, 30), u, font=font("BarlowCondensed-SemiBold", 38), fill=rgb(brand["roles"]["muted"]) + (255,), anchor="mm")
                    L2.putalpha(L2.getchannel("A").point(lambda v: int(v * a)))
                    c.alpha_composite(L2, (0, sy + 64))
        enc.stdin.write(c.convert("RGB").tobytes())
    enc.stdin.close(); enc.wait()

    # audio: music bed + swooshes on each headline entry, fade out at the end
    mu = spec["music"]; mfile = os.path.expanduser(mu["file"])
    inputs = ["-i", tmp, "-ss", str(mu.get("start", 0)), "-t", f"{total:.3f}", "-i", mfile]
    filt = [f"[1:a]volume={mu.get('gain_db', -6)}dB,afade=t=in:d=0.25,afade=t=out:st={total - 1.4:.2f}:d=1.4[m]"]
    mix = ["[m]"]
    sw = spec.get("swoosh")
    if sw:
        swp = sw if os.path.isabs(sw) else os.path.join(REPO, sw)
        hits = [b["t0"] for b in spec["beats"]] + ([body] if ec else [])
        for i, h in enumerate(hits):
            inputs += ["-i", swp]
            filt.append(f"[{2 + i}:a]volume=0.16,adelay={int(h * 1000)}|{int(h * 1000)}[s{i}]"); mix.append(f"[s{i}]")
    filt.append(f"{''.join(mix)}amix=inputs={len(mix)}:normalize=0,alimiter=limit=0.9,loudnorm=I=-14:TP=-1.5:LRA=11[a]")
    subprocess.run(["ffmpeg", "-v", "error", "-y", *inputs, "-filter_complex", ";".join(filt), "-map", "0:v", "-map", "[a]",
                    "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", out], check=True)
    os.remove(tmp)
    print("OK" if not reg.fail else "FAIL", *sorted(reg.fail), f"{total:.2f}s -> {out}", sep="\n  ")
    sys.exit(2 if reg.fail else 0)


if __name__ == "__main__":
    main()
