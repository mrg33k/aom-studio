#!/usr/bin/env python3
"""Enumerate draft clipping compositions from compatible role treatments."""
import argparse
import itertools
import json
from pathlib import Path

DEFAULT_CATALOG = Path(__file__).resolve().parents[1] / "reference" / "option-recipes.json"


def build(catalog):
    axes = {
        "caption": "caption_treatments",
        "support": "support_treatments",
        "identity": "identity_treatments",
        "brand_finish": "brand_finishes",
    }
    family_ids = [item["id"] for item in catalog["main_families"]]
    ending_ids = [item["id"] for item in catalog["ending_families"]]
    if len(family_ids) != len(set(family_ids)) or len(ending_ids) != len(set(ending_ids)):
        raise ValueError("Family IDs must be unique")
    if not catalog["main_families"] or not catalog["ending_families"]:
        raise ValueError("Catalog needs main and ending families")

    options = []
    photo_support = set(catalog["compatibility"]["photo_bridge_requires"])
    for family in catalog["main_families"]:
        for axis, definition in axes.items():
            if not family.get(axis):
                raise ValueError(f"{family['id']} has no {axis} choices")
            unknown = set(family[axis]) - set(catalog[definition])
            if unknown:
                raise ValueError(f"{family['id']} has unknown {axis}: {sorted(unknown)}")
        if set(family["endings"]) - set(ending_ids):
            raise ValueError(f"{family['id']} names an unknown ending")
        for caption, support, identity, finish in itertools.product(
            family["caption"], family["support"], family["identity"], family["brand_finish"]
        ):
            if caption == "photo_bridge" and support not in photo_support:
                continue
            option_id = "--".join((family["id"], caption, support, identity, finish))
            options.append({
                "id": option_id,
                "family": family["id"],
                "status": "draft",
                "geometry_status": family["geometry_status"],
                "origin": family["origin"],
                "best_for": family["best_for"],
                "caption": caption,
                "support": support,
                "identity": identity,
                "brand_finish": finish,
                "compatible_endings": family["endings"],
            })
    ids = [item["id"] for item in options]
    if len(ids) != len(set(ids)):
        raise ValueError("Generated option IDs are not unique")
    return {
        "schema_version": 1,
        "source": "option-recipes.json",
        "status": "Draft metadata; not measured Figma frames or approved designs",
        "main_option_count": len(options),
        "ending_count": len(ending_ids),
        "compatible_main_end_pair_count": sum(len(x["compatible_endings"]) for x in options),
        "endings": catalog["ending_families"],
        "options": options,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--catalog", type=Path, default=DEFAULT_CATALOG)
    parser.add_argument("--output", type=Path, help="Write JSON here; otherwise print to stdout")
    args = parser.parse_args()
    result = build(json.loads(args.catalog.read_text()))
    content = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(content)
    else:
        print(content, end="")


if __name__ == "__main__":
    main()
