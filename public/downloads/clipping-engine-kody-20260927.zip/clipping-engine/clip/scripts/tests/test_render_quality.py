"""CLI regressions: a rendered artifact must not hide a failed layout check."""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from PIL import Image, ImageDraw

SKILL = Path(__file__).resolve().parents[2]


class RenderQualityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temp.name)
        cls.source = cls.root / "source.mp4"
        subprocess.run(["ffmpeg", "-v", "error", "-f", "lavfi", "-i",
                        "color=c=gray:s=160x160:r=30:d=4", "-c:v", "libx264",
                        "-pix_fmt", "yuv420p", str(cls.source)], check=True)
        cls.cuts = cls.root / "cuts.json"
        cls.cuts.write_text(json.dumps([{"a": 0, "b": 4, "spk": "main",
                                       "words": [{"w": "hello", "s": .1, "e": 3}]}]))

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def render(self, stills="1", **extra):
        cfg = {"source": str(self.source), "cuts": str(self.cuts),
               "brand": str(SKILL / "brand-kits/kody-romero/brand.json"),
               "out": str(self.root / "test.mp4"), "hook": ["Test", "frame"],
               "top_crop": [0, 0, 160, 160], "faces": {}, "main_speaker": "main",
               "beats": [{"type": "quote", "at": "hello", "text": "A complete thought"}]}
        cfg.update(extra)
        plan = self.root / "plan.json"
        plan.write_text(json.dumps(cfg))
        return subprocess.run([sys.executable, str(SKILL / "scripts/render_clip.py"),
                               str(plan), "--stills", stills], capture_output=True, text=True)

    def test_clear_layout_succeeds(self):
        result = self.render()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_standard_face_collision_fails(self):
        result = self.render(face_box=[0, 0, 1080, 1670])
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("CLASH", result.stdout + result.stderr)

    def test_fullbleed_face_collision_fails(self):
        result = self.render(layout="fullbleed", fb_crop=[0, 0, 160, 160],
                             face_box=[0, 0, 1080, 1920])
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("face", result.stdout + result.stderr)

    def test_wrong_aspect_plate_requires_explicit_crop(self):
        plate = self.root / "wrong-aspect.png"
        Image.new("RGB", (1024, 1536), "lime").save(plate)
        result = self.render(template=str(plate))
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("aspect", (result.stdout + result.stderr).lower())

    def test_template_name_bubble_appears_then_disappears(self):
        plate = self.root / "keyed.png"
        im = Image.new("RGB", (108, 192), "#082038")
        d = ImageDraw.Draw(im)
        d.rectangle((4, 20, 104, 90), fill="#00FF00")
        d.rectangle((4, 93, 104, 105), fill="#00FFFF")
        d.rectangle((4, 108, 104, 145), fill="#FF00FF")
        im.save(plate)
        result = self.render(template=str(plate), stills="1,5")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        early = Image.open(self.root / "test.mp4.still_1.0.png")
        late = Image.open(self.root / "test.mp4.still_5.0.png")
        # The name bubble's gold portrait ring appears, then leaves the photo clear.
        self.assertEqual(early.getpixel((150, 1535)), (188, 160, 98))
        self.assertNotEqual(late.getpixel((150, 1535)), (188, 160, 98))

    def test_oak_street_name_sits_below_spoken_captions(self):
        oak = SKILL / "brand-kits/oak-street/brand.json"
        result = self.render(brand=str(oak), main_speaker="tim", stills="2")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        frame = Image.open(self.root / "test.mp4.still_2.0.png")
        # The name surface is in the green field beneath the caption seam.
        self.assertTrue(all(abs(actual - expected) <= 5 for actual, expected
                            in zip(frame.getpixel((1025, 1115)), (27, 41, 31))))
        # It no longer covers the live picture above the caption.
        self.assertNotEqual(frame.getpixel((35, 875)), (27, 41, 31))


if __name__ == "__main__":
    unittest.main()
