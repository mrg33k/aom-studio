#!/usr/bin/env python3
"""Static social assets from the same brand + footage: carousels (saves), quote cards, stat cards,
checklists (saves), covers/thumbnails (CTR), story sets (replies). One pack file -> many PNGs.

  python3 stills.py PACK.json --brand BRAND.json --out DIR

PACK.json:
{
  "sources": {"a": {"path": "episode.mp4", "offset": 0}},       # optional, for frame grabs
  "assets": [
    {"type": "quote", "id": "q1", "quote": "...", "name": "Tim Fergestad", "title": "Oak Street Assets", "photo": {"src": "a", "t": 812.4, "focus": [0.5, 0.4]}},
    {"type": "stat", "id": "s1", "value": "$1,000,000", "label": "insurance payout after the fire", "source": "Phoenix Prosperity Podcast ep. 41"},
    {"type": "carousel", "id": "c1", "title": "3 things that saved a burned building", "photo": {...},
     "slides": [{"head": "...", "body": "..."}], "cta": "Save this for your next deal"},
    {"type": "checklist", "id": "k1", "title": "...", "items": ["...", "..."]},
    {"type": "cover", "id": "cv1", "title": "They made $1M from a fire", "highlight": ["$1M"], "photo": {...}},
    {"type": "story", "id": "st1", "hook": "...", "photo": {...}, "question": "Would you have rebuilt?", "options": ["Rebuild", "Sell"], "cta": "Full story on our page"}
  ]
}
Photos: {"src": id, "t": transcript-time, "focus": [x, y]} grabs a frame; or {"path": "image.jpg"}.
"""
import argparse, json, os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from PIL import Image, ImageDraw
from clipkit.core import (load_brand, C, rgb, mix, font, fit_font, text_layer, rounded, circle_crop, mask_round,
                          place, shadow_of, cover, Source, brand_asset, readable_on)
from clipkit.components import Texture, scrim, chip, gradient_v
from clipkit.styles import make_texture

class SC:  # minimal ctx so components work on stills
    def __init__(self, brand, W, H):
        self.brand, self.W, self.H, self.plan = brand, W, H, {}
        self.texture = make_texture(brand, W, H)

    def bg(self, t=7.0):
        return self.texture.frame(t) if self.texture else Image.new("RGBA", (self.W, self.H), C(self.brand, "bg") + (255,))

def grab(pack, ph, base):
    if not ph:
        return None
    if ph.get("path"):
        p = ph["path"] if os.path.isabs(ph["path"]) else str(base / ph["path"])
        return Image.open(p).convert("RGB")
    s = pack["sources"][ph["src"]]
    p = s["path"] if os.path.isabs(s["path"]) else str(base / s["path"])
    r = Source(p, 30)
    img = r.frame(ph["t"] - s.get("offset", 0)).copy(); r.close()
    return img

def hl_map(b, words):
    return {w.lower(): C(b, "accent") for w in (words or [])}

def logo_small(cv, b, x, y, h=70, anchor="rb"):
    lg = brand_asset(b, "logo")
    if lg is not None:
        L = lg.resize((max(1, int(lg.width * h / lg.height)), h), Image.LANCZOS)
        place(cv, L, x, y, anchor)
    else:
        place(cv, text_layer([b.get("short_name", b.get("client", ""))], font(b["type"]["headline"], 34), C(b, "text")), x, y, anchor)

def quote(b, a, photo):
    W, H = 1080, 1350
    s = SC(b, W, H); cv = s.bg()
    qf = font(b["type"]["display"], 300)
    place(cv, text_layer(["“"], qf, C(b, "accent")), 70, 40, "lt")
    f, ls = fit_font(a["quote"], b["type"]["headline"], 92, W - 160, 7, 40)
    L = text_layer(ls, f, C(b, "text"), align="left", spacing=1.12, highlights=hl_map(b, a.get("highlight")))
    place(cv, L, 80, 330, "lt")
    y = 330 + L.height + 60
    ImageDraw.Draw(cv).rectangle((80, y, 200, y + 8), fill=C(b, "accent"))
    fx = 80
    if photo is not None:
        cv.alpha_composite(circle_crop(cover(photo, 400, 400, a["photo"].get("focus", (0.5, 0.4)), 2.2), 130), (80, H - 230))
        fx = 240
    place(cv, text_layer([a.get("name", "")], font(b["type"]["headline"], 46), C(b, "text"), align="left"), fx, H - 205, "lt")
    place(cv, text_layer([a.get("title", "")], font(b["type"]["body"], 32), C(b, "muted"), align="left"), fx, H - 140, "lt")
    logo_small(cv, b, W - 70, H - 80, 80)
    return {"": cv}

def stat(b, a, photo):
    W, H = 1080, 1350
    s = SC(b, W, H); cv = s.bg(3)
    if photo is not None:
        ph = cover(photo, W, H).convert("RGBA")
        ph.alpha_composite(Image.new("RGBA", (W, H), C(b, "bg") + (215,)))
        cv = ph
    f, _ = fit_font(a["value"], b["type"]["number"], 300, W - 140, 1)
    L = text_layer([a["value"]], f, C(b, "accent"))
    place(cv, L, W / 2, H * 0.40, "mm")
    lf, ll = fit_font(a.get("label", "").upper(), b["type"]["headline"], 64, W - 180, 3)
    place(cv, text_layer(ll, lf, C(b, "text")), W / 2, H * 0.40 + L.height / 2 + 30, "mt")
    if a.get("source"):
        place(cv, text_layer([a["source"]], font(b["type"]["body"], 28), C(b, "muted")), W / 2, H - 150, "mb")
    logo_small(cv, b, W / 2, H - 50, 70, "mb")
    return {"": cv}

def carousel(b, a, photo):
    W, H = 1080, 1350
    out = {}
    n = len(a["slides"]) + 2
    def dots(cv, i):
        d = ImageDraw.Draw(cv)
        x0 = W / 2 - (n - 1) * 14
        for k in range(n):
            d.ellipse((x0 + k * 28 - 6, H - 60, x0 + k * 28 + 6, H - 48), fill=C(b, "accent") if k == i else mix(C(b, "text"), C(b, "bg"), 0.6))
    # cover
    s = SC(b, W, H)
    cv = cover(photo, W, H, a.get("photo", {}).get("focus", (0.5, 0.45))).convert("RGBA") if photo is not None else s.bg()
    cv.alpha_composite(scrim(W, H, int(H * 0.25), H, 235, C(b, "bg")))
    f, ls = fit_font(a["title"].upper(), b["type"]["headline"], 110, W - 140, 4)
    L = text_layer(ls, f, C(b, "text"), align="left", spacing=1.0, highlights=hl_map(b, a.get("highlight")))
    place(cv, L, 70, H - 190, "lb")
    place(cv, chip("Swipe →", b, "accent", 30), W - 70, H - 110, "rb")
    logo_small(cv, b, 70, 60, 70, "lt")
    dots(cv, 0); out["01-cover"] = cv
    for i, sl in enumerate(a["slides"], 1):
        s = SC(b, W, H); cv = s.bg(2 + i * 3)
        num = text_layer([f"{i:02d}"], font(b["type"]["display"], 170), C(b, "accent"))
        f, ls = fit_font(sl["head"], b["type"]["headline"], 104, W - 160, 3)
        L = text_layer(ls, f, C(b, "text"), align="left", spacing=1.02, highlights=hl_map(b, sl.get("highlight")))
        B = None
        if sl.get("body"):
            bf, bl = fit_font(sl["body"], b["type"]["body"], 52, W - 160, 7, 32)
            B = text_layer(bl, bf, mix(C(b, "text"), C(b, "bg"), 0.1), align="left", spacing=1.3)
        sp = grab(PACK[0], sl.get("photo"), PACK[1]) if sl.get("photo") else None
        ph_h = 430 if sp is not None else 0
        total = num.height + L.height + 30 + (B.height + 20 if B else 0) + (ph_h + 50 if ph_h else 0)
        y = max(70, (H - 90 - total) / 2)
        place(cv, num, 70, y, "lt"); y += num.height - 10
        place(cv, L, 76, y, "lt"); y += L.height + 30
        if B:
            place(cv, B, 80, y, "lt"); y += B.height + 20
        if sp is not None:
            y += 30
            card = mask_round(cover(sp, W - 160, ph_h, sl["photo"].get("focus", (0.5, 0.5))).convert("RGBA"), b["style"]["radius"])
            cv.alpha_composite(card, (80, int(y)))
        dots(cv, i); out[f"{i + 1:02d}"] = cv
    s = SC(b, W, H); cv = s.bg(40)
    f, ls = fit_font(a.get("cta", "Save this for later"), b["type"]["headline"], 96, W - 160, 3)
    place(cv, text_layer(ls, f, C(b, "text"), spacing=1.05), W / 2, H * 0.40, "mm")
    place(cv, chip(b.get("handle") or "Follow for more", b, "accent", 40), W / 2, H * 0.40 + 190, "mm")
    logo_small(cv, b, W / 2, H - 120, 110, "mb")
    dots(cv, n - 1); out[f"{n:02d}-cta"] = cv
    return out

def checklist(b, a, photo):
    W, H = 1080, 1350
    s = SC(b, W, H); cv = s.bg(11)
    f, ls = fit_font(a["title"].upper(), b["type"]["headline"], 92, W - 160, 3)
    L = text_layer(ls, f, C(b, "text"), align="left", highlights=hl_map(b, a.get("highlight")))
    place(cv, L, 80, 90, "lt")
    y = 90 + L.height + 50
    rowh = min(130, (H - y - 160) // max(1, len(a["items"])))
    for it in a["items"]:
        d = ImageDraw.Draw(cv)
        d.rounded_rectangle((80, y + 6, 140, y + 66), radius=12, outline=C(b, "accent"), width=6)
        d.line((92, y + 36, 106, y + 52, 130, y + 20), fill=C(b, "accent"), width=8)
        tf, tl = fit_font(it, b["type"]["body"], 46, W - 260, 2, 30)
        place(cv, text_layer(tl, tf, C(b, "text"), align="left", spacing=1.1), 170, y + 36, "lm")
        y += rowh
    place(cv, text_layer([a.get("footer", "Save this. Share it with someone who needs it.")], font(b["type"]["body"], 30), C(b, "muted")), 80, H - 70, "lb")
    logo_small(cv, b, W - 70, H - 50, 70)
    return {"": cv}

def cover_asset(b, a, photo):
    out = {}
    for (W, H, tag) in ((1080, 1920, "9x16"), (1280, 720, "16x9")):
        s = SC(b, W, H)
        cv = cover(photo, W, H, a.get("photo", {}).get("focus", (0.5, 0.45))).convert("RGBA") if photo is not None else s.bg()
        if tag == "9x16":
            cv.alpha_composite(scrim(W, H, 0, 900, 200, C(b, "bg"), up=True))
            f, ls = fit_font(a["title"].upper(), b["type"]["headline"], 150, 900, 4)
            L = text_layer(ls, f, C(b, "text"), spacing=0.98, highlights=hl_map(b, a.get("highlight")), shadow=(0, 0, 0, 140))
            place(cv, L, W / 2, 300, "mt")  # inside the 3:4 grid-safe band (y 240-1680)
        else:
            cv.alpha_composite(Image.new("RGBA", (W, H), (0, 0, 0, 0)))
            g = scrim(W, H, 0, H, 0)
            grad = Image.new("RGBA", (W, H), C(b, "bg") + (0,))
            import numpy as np
            al = np.tile(np.clip((np.linspace(1.2, -0.2, W)) * 255, 0, 235).astype("uint8"), (H, 1))
            grad.putalpha(Image.fromarray(al)); cv.alpha_composite(grad)
            f, ls = fit_font(a["title"].upper(), b["type"]["headline"], 120, 640, 4)
            L = text_layer(ls, f, C(b, "text"), align="left", spacing=0.98, highlights=hl_map(b, a.get("highlight")), shadow=(0, 0, 0, 140))
            place(cv, L, 60, H / 2, "lm")
        logo_small(cv, b, W - 40, H - 40 if tag == "16x9" else H - 540, 70 if tag == "16x9" else 90)
        out[tag] = cv
    return out

def story(b, a, photo):
    W, H = 1080, 1920
    out = {}
    s = SC(b, W, H)
    cv = cover(photo, W, H, a.get("photo", {}).get("focus", (0.5, 0.45))).convert("RGBA") if photo is not None else s.bg()
    cv.alpha_composite(scrim(W, H, 900, H, 220, C(b, "bg")))
    f, ls = fit_font(a["hook"].upper(), b["type"]["headline"], 110, W - 160, 4)
    place(cv, text_layer(ls, f, C(b, "text"), spacing=1.0, highlights=hl_map(b, a.get("highlight"))), W / 2, 1150, "mt")
    out["1-hook"] = cv
    s = SC(b, W, H); cv = s.bg(5)
    f, ls = fit_font(a.get("question", "What would you do?"), b["type"]["headline"], 96, W - 180, 3)
    place(cv, text_layer(ls, f, C(b, "text")), W / 2, 520, "mm")
    box = rounded((760, 150 * len(a.get("options", ["Yes", "No"])) + 40), 36, (255, 255, 255, 235))
    d = ImageDraw.Draw(box)
    for i, o in enumerate(a.get("options", ["Yes", "No"])):
        d.rounded_rectangle((30, 30 + i * 150, 730, 150 + i * 150), radius=24, fill=(238, 238, 240))
        d.text((380, 90 + i * 150), o, font=font(b["type"]["headline"], 56), fill=C(b, "ink"), anchor="mm")
    place(cv, box, W / 2, 1000, "mm")
    place(cv, text_layer(["Placeholder: add the real poll sticker in-app"], font(b["type"]["body"], 26), C(b, "muted")), W / 2, 1400, "mm")
    out["2-poll"] = cv
    s = SC(b, W, H); cv = s.bg(9)
    f, ls = fit_font(a.get("cta", "Watch the full clip on our page"), b["type"]["headline"], 100, W - 180, 3)
    place(cv, text_layer(ls, f, C(b, "text")), W / 2, 760, "mm")
    place(cv, chip(b.get("handle") or "Follow", b, "accent", 44), W / 2, 980, "mm")
    logo_small(cv, b, W / 2, 1300, 150, "mb")
    out["3-cta"] = cv
    return out

PACK = [None, None]
MAKERS = {"quote": quote, "stat": stat, "carousel": carousel, "checklist": checklist, "cover": cover_asset, "story": story}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pack"); ap.add_argument("--brand", required=True); ap.add_argument("--out", required=True)
    a = ap.parse_args()
    pp = Path(a.pack).resolve(); pack = json.loads(pp.read_text()); b = load_brand(a.brand)
    os.makedirs(a.out, exist_ok=True)
    PACK[0], PACK[1] = pack, pp.parent
    for i, asset in enumerate(pack["assets"]):
        photo = grab(pack, asset.get("photo"), pp.parent)
        res = MAKERS[asset["type"]](b, asset, photo)
        for k, img in res.items():
            name = f"{asset.get('id', asset['type'] + str(i))}{('-' + k) if k else ''}.png"
            img.convert("RGB").save(os.path.join(a.out, name)); print("wrote", name)

if __name__ == "__main__":
    main()
