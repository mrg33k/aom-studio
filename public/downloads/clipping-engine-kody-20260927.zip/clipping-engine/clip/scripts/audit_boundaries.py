import json, numpy as np
exec(open("audit.py").read().split("res=[]")[0])
AL={int(k):v for k,v in json.load(open("aligned.json")).items()}
sm=np.convolve(db,np.ones(3)/3,mode="same")
def floor2(t):
    a,b=max(0,fr(t-10)),min(n,fr(t+10)); return float(np.percentile(db[a:b],5))
QUIET=15  # dB above floor counts as pause
rows=[]
for k,(a,b) in enumerate(SEGS):
    aw=AL[k]
    for kind,t in (("IN",a),("OUT",b)):
        fl=floor2(t); c=fr(t)
        rel=sm-fl
        if kind=="IN":
            keep=[w for w in aw if (w['s']+w['e'])/2>=t][0]; nb=[w for w in aw if (w['s']+w['e'])/2<t]; nb=nb[-1] if nb else None
            win150=rel[c:c+15]
        else:
            keep=[w for w in aw if (w['s']+w['e'])/2<t][-1]; nb=[w for w in aw if (w['s']+w['e'])/2>=t]; nb=nb[0] if nb else None
            win150=rel[c-15:c]
        at=float(rel[c-1:c+2].max())
        # search window bounded by neighbour word (aligned) and +-300ms
        if kind=="IN":
            lo=max(t-0.3, nb['e']+0.02 if nb else t-0.3); hi=min(t+0.3, keep['s']-0.02)
        else:
            lo=max(t-0.3, keep['e']+0.02); hi=min(t+0.3, nb['s']-0.02 if nb else t+0.3)
        if hi<lo: lo,hi=min(lo,hi),max(lo,hi)
        idx=np.arange(fr(lo),fr(hi)+1)
        quiet=idx[rel[idx]<QUIET]
        if len(quiet):
            # contiguous quiet run nearest cut
            runs=np.split(quiet,np.where(np.diff(quiet)>1)[0]+1)
            run=max(runs,key=len)
            if kind=="OUT": sug=min(run[0]+8, (run[0]+run[-1])//2)   # 80ms into the pause (tail room) or pause middle
            else: sug=max(run[-1]-5, (run[0]+run[-1])//2)           # 50ms before onset or pause middle
            how=f"pause {run[0]/100:.2f}-{run[-1]/100:.2f}"
        else:
            sug=idx[np.argmin(rel[idx])]; how=f"no pause; deepest dip {rel[sug]:+.0f}dB"
        rows.append(dict(seg=k,kind=kind,t=t,floor=round(fl,1),at=round(at,1),mx150=round(float(win150.max()),1),mean150=round(float(win150.mean()),1),
            keep=f"{keep['w']}[{keep['s']:.2f}-{keep['e']:.2f}]",nb=(f"{nb['w']}[{nb['s']:.2f}-{nb['e']:.2f}]" if nb else "-"),
            sug=sug/100,sug_rel=round(float(rel[sug]),1),how=how,
            strip=" ".join(f"{rel[i]:.0f}" for i in range(c-30,c+31))))
json.dump(rows,open("audit_rows.json","w"),indent=1)
for r in rows:
    print(f"seg{r['seg']:2d} {r['kind']:3} {r['t']:7.2f} at{r['at']:+5.0f} max150{r['mx150']:+5.0f} mean150{r['mean150']:+5.0f} keep {r['keep']:24} nb {r['nb']:24} -> {r['sug']:.2f} ({r['sug_rel']:+.0f}) {r['how']}")
