#!/usr/bin/env python3
"""Index a raw shoot: send each small proxy (whole clip, inline) to Gemini and
get back action, people, place, parts, story role and the best Moment in/out.

Sends the full proxy video, not sampled frames, so Gemini sees motion and can
place in/out times on real action. Resumable: skips clips already in the index.

  /usr/bin/python3 scripts/index_shoot.py <proxy_dir> <out.json> [--context "one line about the job"]

Proxies: 480p, 12 fps, h264 (see SKILL.md pipeline step 5). Log footage is
flat; the prompt tells Gemini so it doesn't mark grade as a quality problem.
"""
from __future__ import annotations
import base64, json, sys, time, subprocess, urllib.request, urllib.error, argparse, threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

# Free-tier keys get ~20 requests/day PER MODEL. On a quota 429 we move to the next model instead of
# sleeping; a model that runs dry is dropped for the rest of the run.
MODELS = ["gemini-3.8-flash", "gemini-3.7-flash", "gemini-3.6-flash", "gemini-3.5-flash", "gemini-flash-latest",
          "gemini-3-flash-preview", "gemini-2.5-flash", "gemini-3.1-flash-lite", "gemini-2.5-flash-lite"]
DRY = set()

PROMPT = """You are indexing raw footage from one job shoot for a commercial HVAC company's social media.
Job context: {context}
This clip is {dur:.1f} s long. It is a low-res proxy of flat LOG footage (washed-out color is normal, not a flaw; judge focus, framing, light and content).

Watch the whole clip, listen to the audio, and return STRICT JSON only:
{{
  "action": "what physically happens, under 20 words",
  "people": "who is visible and what they do (e.g. 'tech in gray shirt, hands only'), or 'none'",
  "place": "where (rooftop, unit interior, kitchen, dining room, street, parking deck...)",
  "parts": ["specific equipment or parts visible: rooftop unit, condenser fan, control board, compressor, contactor, capacitor, wiring, gauges, meter, ladder, crane..."],
  "story_role": "one of: establish, problem, diagnose, fix, test, result, people, b-roll",
  "speech": "none | ambient | talking (someone speaks words you can understand)",
  "said": "short paraphrase of anything said that matters, else ''",
  "moment": {{"in": <sec>, "out": <sec>, "why": "under 12 words"}},
  "loopable": true|false,
  "text_on_screen": true|false,
  "q": 1-10,
  "a": 1-10,
  "peak": "the single most striking thing in this clip, under 12 words"
}}
moment = the best continuous 4-8 s (3-5 s if the clip is short) with one clear visual idea and steady or smoothly moving camera, on this clip's 0..{dur:.1f} timeline.
loopable = that moment would loop cleanly (continuous motion like a fan spinning, or a static scene with subtle movement).
q = composition + focus + light + content. 5 = average, 8+ = portfolio, under 4 = unusable (out of focus, lens cap, floor, whip pan).
a = how much real work or motion happens. 9-10 nonstop hands-on work, 5 one beat, 1 nothing."""


def key() -> str:
    for line in (Path.home() / ".config/gemini-api-key.env").read_text().splitlines():
        if "GEMINI_API_KEY" in line and "=" in line:
            return line.split("=", 1)[1].strip().strip('"').strip("'")
    sys.exit("no GEMINI_API_KEY")


def duration(p: Path) -> float:
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(p)],
                         capture_output=True, text=True).stdout.strip()
    return float(out or 0)


def ask(model: str, k: str, video: Path, text: str):
    body = {"contents": [{"parts": [
        {"inline_data": {"mime_type": "video/mp4", "data": base64.b64encode(video.read_bytes()).decode()}},
        {"text": text}]}],
        "generationConfig": {"temperature": 0.2, "responseMimeType": "application/json"}}
    req = urllib.request.Request(
        f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={k}",
        data=json.dumps(body).encode(), headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=180) as r:
        d = json.loads(r.read())
    parts = d["candidates"][0]["content"]["parts"]
    txt = "".join(p.get("text", "") for p in parts if not p.get("thought")).strip()
    if txt.startswith("```"):
        txt = txt.split("\n", 1)[1].rsplit("```", 1)[0]
    g = json.loads(txt)
    return g[0] if isinstance(g, list) else g


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("proxy_dir"); ap.add_argument("out")
    ap.add_argument("--context", default="commercial HVAC service job")
    ap.add_argument("--workers", type=int, default=6)
    a = ap.parse_args()
    k = key(); out = Path(a.out)
    idx = json.loads(out.read_text()) if out.exists() else {}
    clips = sorted(Path(a.proxy_dir).glob("*.mp4"))
    todo = [v for v in clips if not (v.stem in idx and "error" not in idx[v.stem])]
    lock = threading.Lock()

    def one(v):
        dur = duration(v)
        if dur <= 0:
            print(f"skip {v.stem}: no duration (broken proxy?)", flush=True); return
        res, err = None, ""
        for model in MODELS:
            if model in DRY:
                continue
            for attempt in range(3):
                try:
                    res = ask(model, k, v, PROMPT.format(context=a.context, dur=dur)); res["_model"] = model; break
                except urllib.error.HTTPError as e:
                    body = e.read().decode(errors="ignore"); err = f"HTTP {e.code} {body[:200]!r}"
                    if e.code == 429 and "free_tier_requests" in body and "PerDay" in body:
                        DRY.add(model); break
                    if e.code in (400, 404):
                        DRY.add(model); break
                    time.sleep(20 if e.code == 429 else 4)
                except Exception as e:  # parse errors, timeouts
                    err = repr(e)[:200]; time.sleep(3)
            if res:
                break
        res = res or {"error": err}
        res["dur"] = round(dur, 2)
        with lock:
            idx[v.stem] = res
            out.write_text(json.dumps(idx, indent=1))
            print(f"[{len(idx)}/{len(clips)}] {v.stem} q={res.get('q')} a={res.get('a')} {res.get('story_role','')} | {res.get('action', res.get('error'))}", flush=True)

    with ThreadPoolExecutor(a.workers) as ex:
        list(ex.map(one, todo))

if __name__ == "__main__":
    main()
