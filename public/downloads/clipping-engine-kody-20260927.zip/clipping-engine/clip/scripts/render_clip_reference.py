#!/usr/bin/env python3
"""Fire clip, look C (before/after). Frame-by-frame render with PIL -> ffmpeg."""
import json, math, subprocess, random
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageOps

FPS, W, H = 30, 1080, 1920
SRC = "hq2.mp4"
F = "/Users/aom-inhouse/Library/Fonts/"
BLACK, XB = F + "Inter_28pt-BlackItalic.ttf", F + "Poppins-ExtraBold.ttf"
TREE = Image.open("tree.png").convert("RGBA")
LIME, FOREST = (121, 178, 40), (33, 63, 37)
GREEN, TAN, YEL, RED, BG = (34, 92, 52), (196, 160, 110), (255, 214, 64), (200, 50, 40), (14, 18, 15)
SFX = "/Users/aom-inhouse/aom-studio-transfer/AOM-EA/corner/users/aom/agents/content-agent/audio/sfx/"

# radio edit: (src_in, src_out) in hq.mp4 seconds, word-accurate
SEGS = [(139.48, 142.83),                    # hook: investors made ~$1M from the fire
        (9.18, 12.30),                       # this building caught fire in 2023
        (47.07, 48.02), (48.06, 48.86),      # nobody got hurt. thankfully
        (158.22, 159.60),                    # host: so explain why?
        (160.15, 163.90),                    # well, good insurance adjuster and settlement
        (165.14, 168.25),                    # lost revenue covered
        (175.56, 179.79),                    # and then we had a good team, good rebuild rate
        (132.52, 133.62), (134.30, 137.08),  # so ultimately, brand new building
        (144.39, 146.28),                    # big pain in the butt for the team
        (155.25, 157.62),                    # wouldn't recommend it, came out better
        (197.83, 200.66)]                    # host: you don't often hear happy insurance stories
# cut points snapped to real pauses via forced alignment + energy audit (boundary-audit.md)
TAIL = 2.4  # end card hold after last word (card starts 1.2s before it)
words_all = [w for s in json.load(open("hq2.json"))["segments"] for w in s.get("words", [])]

# map words into output time
HOST_SEGS = {4, 12}  # "so explain why?" and the closing line are the host (Dave)
words, t0, HOST_WIN = [], 0.0, []
for k, (a, b) in enumerate(SEGS):
    spk = "host" if k in HOST_SEGS else "tim"
    if spk == "host": HOST_WIN.append((t0, t0 + b - a))
    for w in words_all:
        if a <= w["start"] and w["end"] <= b + 0.05:
            words.append({"w": w["word"].strip(), "s": w["start"] - a + t0, "e": w["end"] - a + t0, "spk": spk})
    t0 += b - a
SPEECH = t0
DUR = SPEECH + TAIL
N = int(DUR * FPS)
seg_starts = np.cumsum([0] + [b - a for a, b in SEGS])[:-1]
def wt(txt, after=0.0):  # output time of first word matching txt after a time
    return next(w["s"] for w in words if w["s"] >= after and w["w"].lower().strip(".,?").startswith(txt))
T_MILLION = wt("million")
T_WHY = wt("explain")
T_C1, T_C2, T_C3 = wt("insurance", T_WHY), wt("lost", T_WHY), wt("negotiated", T_WHY)
T_BRAND = wt("brand", T_C3)
CHECKS = [(T_C1, "Great insurance settlement"), (T_C2, "Lost rent covered"), (T_C3, "Good price on the rebuild")]

# caption chunks (max 3 words, break on punctuation)
chunks, cur = [], []
for i, w in enumerate(words):
    cur.append(w)
    nxt_spk = words[i + 1]["spk"] if i + 1 < len(words) else None
    if len(cur) == 4 or sum(len(x["w"]) + 1 for x in cur) > 18 or w["w"][-1] in ".,!?" or i == len(words) - 1 or nxt_spk != w["spk"]:
        chunks.append(cur); cur = []
KEY = {"million", "dollars", "fire", "2023", "hurt", "why", "insurance", "settlement", "revenue", "rent", "negotiated", "brand", "new", "building", "pain", "better", "happy"}

# --- source stills and live face frames ---------------------------------
still = Image.open("h72.png").convert("RGB")
still.paste(still.crop((335, 339, 351, 359)), (355, 339))  # paint out the screen-share cursor
fire = still.crop((575, 165, 1085, 545))
after = still.crop((140, 165, 570, 500))

def grab_face():
    frames = []
    for a, b in SEGS:
        raw = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{a - 3:.3f}", "-i", SRC, "-ss", "3", "-t", f"{b - a:.3f}",
                              "-vf", f"fps={FPS},crop=104:104:1176:8", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                             capture_output=True).stdout
        n = len(raw) // (104 * 104 * 3)
        frames += [Image.frombytes("RGB", (104, 104), raw[i * 104 * 104 * 3:(i + 1) * 104 * 104 * 3]) for i in range(n)]
    return frames
faces = grab_face()
face_still = faces[len(faces) // 3]

def fit(img, w, h): return ImageOps.fit(img, (w, h), Image.LANCZOS)
def ease(x): x = max(0, min(1, x)); return 1 - (1 - x) ** 3
def back(x):  # overshoot ease for pops
    x = max(0, min(1, x)); c = 1.9; return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2
font_cache = {}
def fnt(p, s):
    k = (p, s)
    if k not in font_cache: font_cache[k] = ImageFont.truetype(p.split("#")[0], s, index=int(p.split("#")[1]) if "#" in p else 0)
    return font_cache[k]

PANEL_TOP, PANEL_H, GAP = 250, 760, 20
BOT_Y = PANEL_TOP + PANEL_H + GAP
fire_big = fit(fire, int(W * 1.12), int(PANEL_H * 1.12))
after_big = fit(after, int(W * 1.1), int(PANEL_H * 1.1))
mask_d = 210
bubble_mask = Image.new("L", (mask_d, mask_d), 0); ImageDraw.Draw(bubble_mask).ellipse((0, 0, mask_d, mask_d), fill=255)


SERIF = "/System/Library/Fonts/Supplemental/Rockwell.ttc#2"
CREAM, TANK, MID, SAGE, NEAR = (251, 245, 230), (217, 190, 143), (48, 109, 65), (153, 174, 160), (27, 41, 31)
BG = NEAR
LOGO = Image.open("logo_dark.png").convert("RGBA")
HOST_IMG = Image.open("host_full.png").convert("RGB").crop((180, 190, 500, 510))

# slow-drifting contour-line texture (land-map feel) for the green areas
_yy, _xx = np.mgrid[0:1400, 0:1400].astype(np.float32) / 1400.0
_field = (np.sin(_xx * 7.1 + 1.3) + np.sin(_yy * 5.3 + 0.4) + 0.7 * np.sin((_xx + _yy) * 9.7) + 0.5 * np.sin((_xx - _yy) * 12.9 + 2.0))
_lines = np.abs(((_field * 3.2) % 1.0) - 0.5) < 0.035
TEX = Image.fromarray(np.where(_lines, 26, 0).astype(np.uint8), "L")
TEX = TEX.filter(ImageFilter.GaussianBlur(0.8))

def textured(base_rgb, w, h, t, speed=14, tint=(121, 178, 40)):
    """flat brand color + drifting faint contour lines + a slow soft light"""
    img = Image.new("RGBA", (w, h), base_rgb + (255,))
    ox = int((t * speed) % (1400 - w)) if w < 1400 else 0
    oy = int((t * speed * 0.6) % (1400 - h)) if h < 1400 else 0
    m = TEX.crop((ox, oy, ox + w, oy + h)) if (w < 1400 and h < 1400) else TEX.resize((w, h))
    img.alpha_composite(Image.merge("RGBA", (*Image.new("RGB", (w, h), tint).split(), m)))
    # soft light blob drifting across
    cx = w * (0.3 + 0.4 * math.sin(t * 0.35)); cy = h * (0.4 + 0.2 * math.cos(t * 0.27))
    glow = Image.new("L", (w, h), 0); ImageDraw.Draw(glow).ellipse((cx - w * 0.5, cy - w * 0.5, cx + w * 0.5, cy + w * 0.5), fill=22)
    glow = glow.resize((max(1, w // 8), max(1, h // 8))).filter(ImageFilter.GaussianBlur(12)).resize((w, h), Image.BILINEAR)
    img.alpha_composite(Image.merge("RGBA", (*Image.new("RGB", (w, h), (255, 255, 240)).split(), glow)))
    return img

def host_level(t):
    """0..1: how 'on' the host bubble is (pops in just before his line, out just after)"""
    v = 0.0
    for a_, b_ in HOST_WIN:
        v = max(v, min(ease((t - (a_ - 0.18)) / 0.18), 1 - ease((t - (b_ + 0.02)) / 0.16)))
    return v

def host_talking(t):
    return any(a_ <= t <= b_ for a_, b_ in HOST_WIN)

def tag(c, x, y, label, bg, fg, p):
    if p <= 0: return
    f = fnt(XB, 44); d = ImageDraw.Draw(c); tw = d.textlength(label, font=f)
    s_ = back(p); w, h = int((tw + 48) * s_), int(74 * s_)
    if w < 4 or h < 4: return
    t_ = Image.new("RGBA", (int(tw + 48), 74), (0, 0, 0, 0)); td = ImageDraw.Draw(t_)
    td.rounded_rectangle((0, 0, tw + 48, 74), 12, fill=bg); td.text((24, 38), label, font=f, fill=fg, anchor="lm")
    t_ = t_.resize((w, h), Image.LANCZOS); c.alpha_composite(t_, (x, y + (74 - h) // 2))

def spaced(d, xy, s_, font, fill, track, anchor="mm"):
    widths = [d.textlength(ch, font=font) for ch in s_]; total = sum(widths) + track * (len(s_) - 1)
    x = xy[0] - total / 2 if anchor == "mm" else xy[0]
    for ch, w in zip(s_, widths):
        d.text((x, xy[1]), ch, font=font, fill=fill, anchor="lm"); x += w + track

def centered(c, y, s_, font, size, color, stroke=0, alpha=1.0, dy=0):
    if alpha <= 0: return
    layer = Image.new("RGBA", (W, size * 2), (0, 0, 0, 0))
    ImageDraw.Draw(layer).text((W / 2, size), s_, font=fnt(font, size), fill=color, anchor="mm", stroke_width=stroke, stroke_fill="black")
    if alpha < 1: layer.putalpha(layer.getchannel("A").point(lambda v: int(v * alpha)))
    c.alpha_composite(layer, (0, int(y - size + dy)))

def rise(c, draw_fn, size, pos, p, dist=30):
    """draw_fn(ImageDraw) onto a transparent layer of `size`, composite at pos with fade + rise by progress p"""
    if p <= 0: return
    lay = Image.new("RGBA", size, (0, 0, 0, 0)); draw_fn(ImageDraw.Draw(lay))
    if p < 1: lay.putalpha(lay.getchannel("A").point(lambda v: int(v * p)))
    c.alpha_composite(lay, (int(pos[0]), int(pos[1] + (1 - p) * dist)))

def check_path(d, x0, y0, p, color, width):
    """checkmark that draws itself: short stroke then long stroke"""
    pts = [(x0 + 17, y0 + 38), (x0 + 31, y0 + 53), (x0 + 57, y0 + 21)]
    l1 = math.dist(pts[0], pts[1]); l2 = math.dist(pts[1], pts[2]); L = (l1 + l2) * max(0, min(1, p))
    if L <= 0: return
    if L <= l1:
        e = (pts[0][0] + (pts[1][0] - pts[0][0]) * L / l1, pts[0][1] + (pts[1][1] - pts[0][1]) * L / l1); d.line((pts[0], e), fill=color, width=width)
    else:
        k = (L - l1) / l2; e = (pts[1][0] + (pts[2][0] - pts[1][0]) * k, pts[1][1] + (pts[2][1] - pts[1][1]) * k)
        d.line((pts[0], pts[1], e), fill=color, width=width, joint="curve")

def money(v): return "$" + f"{int(v):,}"

def frame(i):
    t = i / FPS
    c = Image.new("RGBA", (W, H), BG + (255,))
    # top photo: fire, slow push-in
    z = 1.0 + 0.10 * (t / DUR)
    fw, fh = int(W * z), int(PANEL_H * z)
    fimg = fire_big.resize((fw, fh), Image.BILINEAR)
    c.paste(fimg.crop(((fw - W) // 2, (fh - PANEL_H) // 2, (fw - W) // 2 + W, (fh - PANEL_H) // 2 + PANEL_H)), (0, PANEL_TOP))
    # bottom panel: stat card -> checklist -> after photo
    bot = textured(FOREST, W, PANEL_H, t); bd = ImageDraw.Draw(bot)
    cp = ease((t - (T_MILLION - 0.5)) / 1.2)
    rise(bot, lambda d_: spaced(d_, (W / 2, 40), "MADE FOR INVESTORS", fnt(XB, 34), CREAM, 9), (W, 80), (0, 175), ease((t - 0.6) / 0.4))
    lw = 150 * ease((t - 0.85) / 0.45)
    if lw > 1: bd.line((W / 2 - lw, 255, W / 2 + lw, 255), fill=LIME, width=5)
    np_ = back((t - 0.9) / 0.45)
    if np_ > 0.02:
        nl = Image.new("RGBA", (W, 220), (0, 0, 0, 0))
        ImageDraw.Draw(nl).text((W / 2, 110), money(1_000_000 * cp), font=fnt(SERIF, 150), fill=CREAM, anchor="mm")
        sw, sh = int(W * np_), int(220 * np_)
        if sw > 4 and sh > 4:
            nl = nl.resize((sw, sh), Image.LANCZOS); bot.alpha_composite(nl, ((W - sw) // 2, 375 - sh // 2))
    cw = ease((t - (T_WHY - 0.1)) / 0.4)
    if cw > 0:
        cl = textured(FOREST, W, PANEL_H, t); cd = ImageDraw.Draw(cl)
        rise(cl, lambda d_: spaced(d_, (80, 40), "WHY IT PAID OFF", fnt(XB, 36), TANK, 8, anchor="lm"), (W, 80), (0, 145), ease((t - (T_WHY + 0.25)) / 0.4))
        hl = 180 * ease((t - (T_WHY + 0.45)) / 0.4)
        if hl > 1: cd.line((80, 222, 80 + hl, 222), fill=LIME, width=4)
        for n, (ts, label) in enumerate(CHECKS):
            p = back((t - ts) / 0.35)
            if p <= 0: continue
            y = 310 + n * 115; sz = int(74 * p)
            if sz > 4:
                box = Image.new("RGBA", (74, 74), (0, 0, 0, 0)); bdd = ImageDraw.Draw(box)
                bdd.rounded_rectangle((0, 0, 73, 73), 14, fill=LIME)
                check_path(bdd, 0, 0, (t - ts - 0.15) / 0.3, FOREST, 9)
                box = box.resize((sz, sz), Image.LANCZOS); cl.alpha_composite(box, (80 + (74 - sz) // 2, y - sz // 2))
            a_ = ease((t - ts) / 0.3)
            lay = Image.new("RGBA", (W, 100), (0, 0, 0, 0))
            ImageDraw.Draw(lay).text((185, 50), label, font=fnt(XB, 52), fill=CREAM, anchor="lm")
            lay.putalpha(lay.getchannel("A").point(lambda v: int(v * a_)))
            cl.alpha_composite(lay, (int((1 - a_) * 40), y - 50))
        x = int(W * (1 - cw)); bot.paste(cl.crop((0, 0, W - x, PANEL_H)), (x, 0))
    wipe = ease((t - (T_BRAND - 0.15)) / 0.45)
    if wipe > 0:
        z2 = 1.06 - 0.06 * ease((t - T_BRAND) / 4)
        aw, ah = int(W * z2), int(PANEL_H * z2)
        aimg = after_big.resize((aw, ah), Image.BILINEAR).crop(((aw - W) // 2, (ah - PANEL_H) // 2, (aw - W) // 2 + W, (ah - PANEL_H) // 2 + PANEL_H))
        x = int(W * (1 - wipe)); bot.paste(aimg.crop((0, 0, W - x, PANEL_H)), (x, 0))
        if wipe >= 1:
            bp_ = back((t - (T_BRAND + 0.6)) / 0.4)
            if bp_ > 0:
                card = Image.new("RGBA", (470, 150), (0, 0, 0, 0)); kd = ImageDraw.Draw(card)
                kd.rounded_rectangle((0, 0, 469, 149), 18, fill=NEAR + (240,))
                spaced(kd, (235, 36), "MADE FOR INVESTORS", fnt(XB, 20), CREAM, 5)
                kd.line((235 - 70, 56, 235 + 70, 56), fill=LIME, width=3)
                kd.text((235, 100), "+$1,000,000", font=fnt(SERIF, 64), fill=CREAM, anchor="mm")
                cw_, ch_ = int(470 * bp_), int(150 * bp_)
                if cw_ > 4 and ch_ > 4:
                    card = card.resize((cw_, ch_), Image.LANCZOS)
                    bot.alpha_composite(card, (W - 40 - cw_ // 2 - 235, PANEL_H - 70 - ch_ // 2 - 75 + 75 - ch_ // 2 + ch_ // 2))
    c.alpha_composite(bot, (0, BOT_Y))
    tag(c, 40, PANEL_TOP + 40, "2023: THE FIRE", TANK, NEAR, (t - 0.25) / 0.35)
    tag(c, 40, BOT_Y + 140, "NOW: BRAND NEW", MID, "white", (t - (T_BRAND + 0.35)) / 0.35)
    # hook title bar: forest, serif, tan rule
    c.alpha_composite(textured(FOREST, W, PANEL_TOP, t, speed=10), (0, 0))
    for n, (line, y) in enumerate([("How a fire made", 88), ("investors $1 million", 170)]):
        p = ease((t - 0.08 - n * 0.22) / 0.35)
        centered(c, y, line, SERIF, 74, CREAM, alpha=p, dy=(1 - p) * 26)
    rp = ease((t - 0.5) / 0.5)
    if rp > 0:
        ImageDraw.Draw(c).line((W / 2 - 170 * rp, 226, W / 2 + 170 * rp, 226), fill=TANK, width=4)
    # captions: dark bar, active word lime
    ch = None
    for n_, k in enumerate(chunks):
        end_ = k[-1]["e"] + 0.25
        if n_ + 1 < len(chunks): end_ = min(end_, chunks[n_ + 1][0]["s"] - 0.05)
        if chunks[n_ + 1][0]["spk"] != k[0]["spk"] if n_ + 1 < len(chunks) else False: end_ = min(end_, k[-1]["e"] + 0.02)
        start_ = k[0]["s"] - 0.05
        if n_ > 0 and chunks[n_ - 1][0]["spk"] != k[0]["spk"]: start_ = max(start_, max([b_ for a_, b_ in HOST_WIN if b_ <= k[0]["s"] + 0.3] + [0]) + 0.2)
        if start_ <= t < end_: ch = k; break
    if ch and t < SPEECH + 0.2:
        d = ImageDraw.Draw(c); f = fnt(XB, 80)
        toks = [w["w"].strip(",") for w in ch]
        widths = [d.textlength(x, font=f) for x in toks]; space = 24
        total = sum(widths) + space * (len(toks) - 1)
        hl_c = host_level(t)
        cap = 640 - 200 * hl_c
        if total > cap:
            f = fnt(XB, int(80 * cap / total)); widths = [d.textlength(x, font=f) for x in toks]; total = sum(widths) + space * (len(toks) - 1)
        pop = back((t - ch[0]["s"]) / 0.18)
        y = BOT_Y - 10 + (1 - pop) * 18
        barw = total + 80
        bx = 40 + 250 * hl_c
        d.rounded_rectangle((bx, y - 62, bx + barw, y + 62), 20, fill=NEAR)
        x = bx + 40
        for w, tok, tw in zip(ch, toks, widths):
            active = w["s"] - 0.03 <= t < w["e"] + 0.08
            d.text((x, y), tok, font=f, fill=(TANK if w["spk"] == "host" else LIME) if active else CREAM, anchor="lm")
            x += tw + space
    # face bubble: green ring + thin cream
    fi = min(len(faces) - 1, int(t * FPS)); face = faces[fi] if faces else None
    hl_ = host_level(t)
    bp = back((t - 0.4) / 0.4) * (1 - 0.18 * hl_)
    if face is not None and bp > 0:
        d0 = int(mask_d * bp)
        if d0 > 8:
            ring = Image.new("RGBA", (d0 + 20, d0 + 20), (0, 0, 0, 0)); rd = ImageDraw.Draw(ring)
            rd.ellipse((0, 0, d0 + 19, d0 + 19), fill=MID); rd.ellipse((6, 6, d0 + 13, d0 + 13), fill=CREAM)
            ring.paste(fit(face, d0, d0), (10, 10), bubble_mask.resize((d0, d0)))
            if hl_ > 0: ring.putalpha(ring.getchannel("A").point(lambda v: int(v * (1 - 0.45 * hl_))))
            cx, cy = W - 150, BOT_Y - 10
            c.alpha_composite(ring, (cx - (d0 + 20) // 2, cy - (d0 + 20) // 2))
    # host bubble (still frame; ring pulses while he talks)
    if hl_ > 0:
        hb = back(hl_) if hl_ < 1 else 1.0
        d1 = int(mask_d * hb)
        if d1 > 8:
            pulse = 0.5 + 0.5 * math.sin(t * 2 * math.pi * 2.2) if host_talking(t) else 0
            g = int(10 + 10 * pulse)
            hr = Image.new("RGBA", (d1 + 20 + 2 * g, d1 + 20 + 2 * g), (0, 0, 0, 0)); hd = ImageDraw.Draw(hr)
            hd.ellipse((0, 0, d1 + 19 + 2 * g, d1 + 19 + 2 * g), fill=TANK + (int(90 * pulse),))
            hd.ellipse((g, g, g + d1 + 19, g + d1 + 19), fill=TANK); hd.ellipse((g + 6, g + 6, g + d1 + 13, g + d1 + 13), fill=CREAM)
            hr.paste(fit(HOST_IMG, d1, d1), (g + 10, g + 10), bubble_mask.resize((d1, d1)))
            cx, cy = 150, BOT_Y - 10
            c.alpha_composite(hr, (cx - hr.width // 2, cy - hr.height // 2))
    # name lower third, early
    lp = ease((t - 1.0) / 0.4) * (1 - ease((t - 6.6) / 0.4))
    if lp > 0:
        lt = Image.new("RGBA", (720, 130), (0, 0, 0, 0)); ld = ImageDraw.Draw(lt)
        ld.rounded_rectangle((0, 0, 719, 129), 14, fill=NEAR + (235,))
        tr = TREE.resize((86, int(86 * TREE.height / TREE.width)), Image.LANCZOS); lt.alpha_composite(tr, (28, (130 - tr.height) // 2))
        ld.line((138, 28, 138, 102), fill=TANK, width=3)
        ld.text((162, 48), "Tim Fergestad", font=fnt(XB, 44), fill=CREAM, anchor="lm")
        ld.text((162, 95), "Oak Street Assets", font=fnt(XB, 32), fill=SAGE, anchor="lm")
        lt.putalpha(lt.getchannel("A").point(lambda v: int(v * lp)))
        c.alpha_composite(lt, (int(40 - (1 - lp) * 60), BOT_Y + PANEL_H - 170))
    # end card
    ep = ease((t - (SPEECH - 1.2)) / 0.45)
    if ep > 0:
        te = t - (SPEECH - 1.2)
        zc = 1.08 - 0.06 * ease(te / 3.0)
        pbg = fit(after, int(W * zc), int(H * zc)).filter(ImageFilter.GaussianBlur(3)).convert("RGBA")
        card = pbg.crop(((pbg.width - W) // 2, (pbg.height - H) // 2, (pbg.width - W) // 2 + W, (pbg.height - H) // 2 + H))
        ov = textured(FOREST, W, H, t, speed=8); ov.putalpha(212)
        card.alpha_composite(ov); cdr = ImageDraw.Draw(card)
        for side, img_, name, sub, ringc, delay in [(-1, HOST_IMG, "Dave Dubeau", "Property Profits Podcast", TANK, 0.15),
                                                    (1, face_still, "Tim Fergestad", "Oak Street Assets", MID, 0.3)]:
            p = back((te - delay) / 0.5)
            if p <= 0.02: continue
            d2 = 230; cx = W / 2 + side * 250 + side * (1 - min(p, 1)) * 420; cy = 330
            rr = Image.new("RGBA", (d2 + 20, d2 + 20), (0, 0, 0, 0)); rrd = ImageDraw.Draw(rr)
            rrd.ellipse((0, 0, d2 + 19, d2 + 19), fill=ringc); rrd.ellipse((6, 6, d2 + 13, d2 + 13), fill=CREAM)
            rr.paste(fit(img_, d2, d2), (10, 10), bubble_mask.resize((d2, d2)))
            card.alpha_composite(rr, (int(cx - rr.width / 2), int(cy - rr.height / 2)))
            na = ease((te - delay - 0.3) / 0.35)
            rise(card, lambda d_, n=name: d_.text((250, 30), n, font=fnt(XB, 40), fill=CREAM, anchor="mm"), (500, 60), (cx - 250, cy + 140), na)
            rise(card, lambda d_, s_=sub: d_.text((250, 25), s_, font=fnt(XB, 28), fill=SAGE, anchor="mm"), (500, 50), (cx - 250, cy + 190), na)
        lg = LOGO.resize((620, int(620 * LOGO.height / LOGO.width)), Image.LANCZOS)
        lgp = back((te - 0.6) / 0.5)
        if lgp > 0.02:
            lw_, lh_ = int(lg.width * lgp), int(lg.height * lgp)
            if lw_ > 4 and lh_ > 4:
                lgs = lg.resize((lw_, lh_), Image.LANCZOS)
                card.alpha_composite(lgs, ((W - lw_) // 2, 700 + (lg.height - lh_) // 2))
        y0 = 700 + lg.height + 110
        ll = 60 * ease((te - 0.7) / 0.35)
        if ll > 1: cdr.line((W / 2 - ll, y0 - 50, W / 2 + ll, y0 - 50), fill=TANK, width=4)
        rise(card, lambda d_: d_.text((W / 2, 40), "Follow for more", font=fnt(XB, 42), fill=TANK, anchor="mm"), (W, 80), (0, y0 - 30), ease((te - 0.8) / 0.35))
        rise(card, lambda d_: d_.text((W / 2, 50), "Phoenix Prosperity", font=fnt(SERIF, 64), fill=CREAM, anchor="mm"), (W, 100), (0, y0 + 45), ease((te - 0.95) / 0.4))
        rise(card, lambda d_: d_.text((W / 2, 50), "Podcast", font=fnt(SERIF, 64), fill=CREAM, anchor="mm"), (W, 100), (0, y0 + 120), ease((te - 1.1) / 0.4))
        pill_p = back((te - 1.35) / 0.4)
        if pill_p > 0.02:
            pl = Image.new("RGBA", (560, 90), (0, 0, 0, 0)); pd = ImageDraw.Draw(pl)
            pd.rounded_rectangle((0, 0, 559, 89), 45, fill=LIME)
            pd.text((280, 46), "Full episode: link in bio", font=fnt(XB, 38), fill=NEAR, anchor="mm")
            pw, ph = int(560 * pill_p), int(90 * pill_p)
            if pw > 4 and ph > 4:
                pl = pl.resize((pw, ph), Image.LANCZOS); card.alpha_composite(pl, ((W - pw) // 2, y0 + 290 + (90 - ph) // 2))
        sp = ease((te - 0.5) / 0.5)
        if sp > 0:
            strip = Image.new("RGBA", (W, 100), TANK + (255,))
            spaced(ImageDraw.Draw(strip), (W / 2, 50), "STEADY GROWTH. STRONG RETURNS.", fnt(XB, 32), NEAR, 10)
            card.alpha_composite(strip.crop((0, 0, int(W * sp), 100)), (0, H - 190))
        y = int(H * (1 - ep)); c.alpha_composite(card.crop((0, 0, W, H - y)), (0, y))
    return c.convert("RGB")

# --- video ---------------------------------------------------------------
enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS),
                        "-i", "-", "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", "wow_v.mp4"],
                       stdin=subprocess.PIPE)
for i in range(N):
    enc.stdin.write(frame(i).tobytes())
enc.stdin.close(); enc.wait()

# --- audio: speech radio edit + music bed + swooshes ----------------------
speech = []
for k, (a, b) in enumerate(SEGS):
    fn = f"seg{k}.wav"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", SRC, "-vn",
                    "-af", f"atrim={a:.3f}:{b:.3f},asetpts=PTS-STARTPTS,afade=t=in:d=0.02,afade=t=out:st={b - a - 0.03:.3f}:d=0.03", "-ar", "48000", "-ac", "2", fn], check=True)
    speech.append(fn)
open("segs.txt", "w").write("".join(f"file '{s}'\n" for s in speech))
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "segs.txt", "-af", f"apad=pad_dur={TAIL + 1}", "speech.wav"], check=True)

# music bed: Am - F - C - G pad with soft pulse, lifts at "brand new"
sr = 48000; tt = np.arange(int((DUR + 0.5) * sr)) / sr
chords = [[220.0, 261.63, 329.63], [174.61, 220.0, 261.63], [261.63, 329.63, 392.0], [196.0, 246.94, 293.66]]
bar = 2.4
mus = np.zeros_like(tt)
for n, ch in enumerate(chords * 5):
    s0 = n * bar
    m = (tt >= s0) & (tt < s0 + bar + 0.6)
    env = np.clip((tt[m] - s0) / 0.4, 0, 1) * np.clip((s0 + bar + 0.6 - tt[m]) / 0.6, 0, 1)
    for f0 in ch:
        for det in (-0.6, 0.6):
            mus[m] += env * (np.sin(2 * np.pi * (f0 + det) * tt[m]) + 0.3 * np.sin(2 * np.pi * 2 * (f0 + det) * tt[m]))
    # low root
    mus[m] += 0.8 * env * np.sin(2 * np.pi * ch[0] / 2 * tt[m])
pulse = (0.5 + 0.5 * np.cos(2 * np.pi * (tt * 100 / 60 * 2))) ** 6  # eighth-note pulse at 100bpm
lift = np.clip((tt - T_BRAND) / 1.0, 0, 1)
mus = mus * (0.55 + 0.45 * lift) * (0.75 + 0.25 * pulse * lift)
# soft kick on beats after the lift
for bt in np.arange(T_BRAND, DUR, 60 / 100):
    k0 = int(bt * sr); kl = int(0.25 * sr)
    if k0 + kl < len(mus):
        kt = np.arange(kl) / sr
        mus[k0:k0 + kl] += 2.2 * np.sin(2 * np.pi * (50 + 60 * np.exp(-kt * 30)) * kt) * np.exp(-kt * 14)
mus /= np.abs(mus).max()
fade = np.clip((DUR + 0.5 - tt) / 1.2, 0, 1) * np.clip(tt / 0.3, 0, 1)
mus *= fade
import wave
with wave.open("music.wav", "wb") as wf:
    wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(sr)
    wf.writeframes((mus * 0.9 * 32767).astype(np.int16).tobytes())

# swooshes: hook, fire tag, counter, wipe, face bubble
pool = sorted(__import__("glob").glob(SFX + "swooshes/*.wav"))
random.seed(7)
hits = [(0.05, SFX + "hook-air-swoosh.wav", 0.35), (T_MILLION - 0.5, random.choice(pool), 0.14),
        (T_WHY - 0.1, random.choice(pool), 0.16), (T_C1, random.choice(pool), 0.10), (T_C2, random.choice(pool), 0.10),
        (T_C3, random.choice(pool), 0.10), (T_BRAND - 0.15, random.choice(pool), 0.18), (T_BRAND + 0.35, random.choice(pool), 0.12),
        (SPEECH - 1.2, SFX + "hook-air-swoosh.wav", 0.3)]
ins = ["-i", "speech.wav", "-i", "music.wav"]; fl = ["[1:a]lowpass=f=2400,volume=0.11,aformat=channel_layouts=stereo[m]"]
for n, (at, f, v) in enumerate(hits):
    ins += ["-i", f]
    fl.append(f"[{n + 2}:a]adelay={int(at * 1000)}|{int(at * 1000)},volume={v},aformat=channel_layouts=stereo[s{n}]")
fl.append("[0:a][m]" + "".join(f"[s{n}]" for n in range(len(hits))) + f"amix=inputs={len(hits) + 2}:normalize=0:duration=first,atrim=0:{DUR:.3f},loudnorm=I=-14:TP=-1.5[a]")
subprocess.run(["ffmpeg", "-v", "error", "-y", *ins, "-filter_complex", ";".join(fl), "-map", "[a]", "-ar", "48000", "mix.wav"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "wow_v.mp4", "-i", "mix.wav", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest",
                "out/fire-sample-branded.mp4"], check=True)
print("done", f"{DUR:.2f}s", N, "frames", "million", T_MILLION, "why", T_WHY, "brand", T_BRAND, "speech", SPEECH)
