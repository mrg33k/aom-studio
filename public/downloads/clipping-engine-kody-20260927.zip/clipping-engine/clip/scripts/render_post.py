#!/usr/bin/env python3
"""Render carousel slides / short posts in a client's GPT series look, with real footage behind.

  /usr/bin/python3 scripts/render_post.py post.json OUT_DIR [--still-only] [--only s1,s2]

post.json:
{
  "brand": "brand-kits/ambition-mechanical/brand.json",   (relative to the skill folder)
  "src_root": "/Volumes/.../20260901 Elephante",
  "size": [1080, 1350], "fps": 24, "dur": 5.0,
  "zones": false,            (true for 9:16 Reels: fail if text enters the bottom 18% / right 10%)
  "slides": [{
     "id": "s1",
     "bg": {"src": "Ronin4D/B007C0270_...MOV", "in": 2.0, "cx": 0.36, "cy": 0.5, "zoom": 0.03, "log": true}
           or {"still": "/abs/path.jpg", "cx": 0.5, "zoom": 0.03},
     "plate": "templates/learning_plate.png",   (optional GPT plate from gpt_sheet.py: its window is keyed)
     "headline": [{"text": "WHAT BURNED OUT", "slab": true}, {"text": "UP HERE?"}],
     "sentence": "One rooftop unit down at a fine-dining restaurant.",
     "callouts": [{"at": [1000, 1520], "r": 150, "label": "FAN MOTOR BOARD", "label_at": [560, 980]}],
                  (at = source-pixel point, follows the push-in; label_at = output px, top-left of label)
     "inset": {"at": [1000, 1520], "src_r": 260, "box": [640, 600, 380]},   (magnify: source point, source
                  radius, output x, y, size)
     "progress": "2/6",
     "faces": [[x0, y0, x1, y1]]   (source px, protected: no overlay may cover)
  }]
}

Look rules (matched from the client's approved GPT posts, never invented here):
- Headline + sentence from `clipkit.typestyle` (the brand's matched `type_style`).
- Callout = hand-drawn red ring (GPT "LICENSED. BONDED." post) + red label box (GPT CTA box).
- Footer = round badge + client name + URL + short red rule (GPT "Improve HVAC Branding" series).
- Top of frame darkens to the brand bg so type reads, same as the GPT posts.
Every overlay registers its box each frame; overlaps print CLASH and fail the render (exit 2).
"""
import argparse, json, math, os, subprocess, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from clipkit.core import font, rgb, place, prog, ease_out, ease_back, lerp  # noqa: E402
from clipkit.typestyle import Headline, sentence_block  # noqa: E402
from make_moments import LOG_LUT, LOOK, probe  # noqa: E402

OVERSAMPLE = 1.25
STILL_BASE = ['.']  # relative stills resolve against the post.json folder


class Registry:
    def __init__(self, W, H, zones):
        self.W, self.H, self.zones, self.boxes, self.fail = W, H, zones, [], set()

    def reset(self):
        self.boxes = []

    def add(self, name, box, text=True):
        x0, y0, x1, y1 = box
        for n, b in self.boxes:
            if x0 < b[2] and x1 > b[0] and y0 < b[3] and y1 > b[1]:
                # a ring may cross its own label or another ring; never text, the footer, an inset or a face
                soft = {name.split("#")[0], n.split("#")[0]}
                ok = (soft <= {"ring", "label"} and "ring" in soft) or soft == {"ringin", "inset"} or soft <= {"ringin", "label"}
                if not ok:
                    self.fail.add(f"CLASH: {name} overlaps {n}")
        if self.zones and text:
            if y1 > self.H * 0.82 and not name.startswith("footer"):
                self.fail.add(f"ZONE: {name} enters the bottom 18% (platform captions)")
            if x1 > self.W * 0.90:
                self.fail.add(f"ZONE: {name} enters the right 10% (platform buttons)")
        self.boxes.append((name, box))


def decode_bg(bg, root, W, H, n):
    """Returns list of oversampled RGB frames + a mapper from source px to oversampled px."""
    OW, OH = int(W * OVERSAMPLE) // 2 * 2, int(H * OVERSAMPLE) // 2 * 2
    if "still" in bg:
        im = Image.open(bg["still"] if os.path.isabs(bg["still"]) else os.path.join(STILL_BASE[0], bg["still"])).convert("RGB")
        sw, sh = im.size
    else:
        src = os.path.join(root, bg["src"])
        sw, sh, _ = probe(src)
    aspect = W / H
    ch = sh if sw / sh >= aspect else int(sw / aspect)
    cw = int(ch * aspect) // 2 * 2; ch = ch // 2 * 2
    x = int(min(max(bg.get("cx", 0.5) * sw - cw / 2, 0), sw - cw)) // 2 * 2
    y = int(min(max(bg.get("cy", 0.5) * sh - ch / 2, 0), sh - ch)) // 2 * 2
    s = OW / cw
    mapper = lambda px, py: ((px - x) * s, (py - y) * s)
    if "still" in bg:
        fr = np.asarray(im.crop((x, y, x + cw, y + ch)).resize((OW, OH), Image.LANCZOS))
        return [fr] * n, mapper, (OW, OH)
    log = bg.get("log", "ronin" in bg["src"].lower())
    grade = (f"lut3d='{LOG_LUT}'," if log else "") + LOOK + (",eq=contrast=1.08:saturation=1.06" if log else ",eq=contrast=1.03:saturation=0.9")
    if bg.get("lift"):
        grade += f",eq=gamma={bg['lift']}"
    vf = f"{grade},crop={cw}:{ch}:{x}:{y},scale={OW}:{OH}:flags=lanczos,fps=24"
    raw = subprocess.run(["ffmpeg", "-v", "error", "-ss", str(bg["in"]), "-i", src, "-frames:v", str(n), "-map", "0:v:0",
                          "-vf", vf, "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True, check=True).stdout
    fsz = OW * OH * 3
    frames = [np.frombuffer(raw[i:i + fsz], np.uint8).reshape(OH, OW, 3) for i in range(0, len(raw) - fsz + 1, fsz)]
    while len(frames) < n:
        frames.append(frames[-1])
    return frames, mapper, (OW, OH)


def zoom_frame(fr, k, n, zoom, W, H, OW, OH):
    z = 1 + zoom * k / max(1, n - 1)
    w, h = OW / z, OH / z
    l, t = (OW - w) / 2, (OH - h) / 2
    img = Image.fromarray(fr).resize((W, H), Image.LANCZOS, box=(l, t, l + w, t + h))
    to_out = lambda ox, oy: ((ox - l) * W / w, (oy - t) * H / h)
    return img, to_out, W / w


def shade(W, H, bgc):
    """Top darkening (type area) + soft bottom darkening (footer), like the GPT posts."""
    a = np.zeros((H, 1), np.float32)
    ys = np.arange(H)[:, None]
    a = np.maximum(a, np.clip(1 - ys / (H * 0.46), 0, 1) ** 1.3 * 0.92)
    a = np.maximum(a, np.clip((ys - H * 0.72) / (H * 0.2), 0, 1) ** 1.1 * 0.93)
    col = np.array(rgb(bgc), np.float32)
    L = np.dstack([np.broadcast_to(col, (H, W, 3)), np.broadcast_to(a * 255, (H, W))[..., None]])
    return Image.fromarray(L.astype(np.uint8), "RGBA")


def ring(canvas, cx, cy, r, color, p, width=9, seed=3):
    """Hand-drawn marker ring: slightly uneven radius, overshoots its start; draws on with p in 0..1."""
    if p <= 0:
        return
    rs = np.random.RandomState(seed)
    wob = rs.uniform(-0.06, 0.06, 5)
    pts = []
    total = 2 * math.pi * 1.12
    steps = 90
    for i in range(int(steps * p) + 1):
        a = -1.9 + total * i / steps
        rr = r * (1 + wob[0] * math.sin(a * 2 + wob[1] * 20) + wob[2] * math.cos(a * 3))
        pts.append((cx + rr * 1.08 * math.cos(a), cy + rr * 0.92 * math.sin(a)))
    if len(pts) > 1:
        ImageDraw.Draw(canvas).line(pts, fill=rgb(color), width=width, joint="curve")


def label_box(text, brand, size=44):
    f = font(brand["type"].get("cta", "BarlowCondensed-ExtraBold"), size)
    tw = int(f.getlength(text)); pad = (22, 10)
    L = Image.new("RGBA", (tw + pad[0] * 2, size + pad[1] * 2), rgb(brand["roles"]["accent"]) + (255,))
    ImageDraw.Draw(L).text((pad[0], pad[1] + size * 0.5), text, font=f, fill=(255, 255, 255), anchor="lm")
    return L


def footer(canvas, brand, W, H, progress, reg, t=None):
    badge = Image.open(os.path.join(SKILL, "brand-kits", brand["_slug"], brand["assets"]["logo"])).convert("RGBA")
    bs = 104
    badge = badge.resize((bs, int(bs * badge.height / badge.width)), Image.LANCZOS)
    y = H - 60 - badge.height
    a = 1.0 if t is None else min(1, max(0, (t - 0.9) / 0.4))
    if a <= 0:
        return
    F = Image.new("RGBA", canvas.size, (0, 0, 0, 0))  # draw on its own layer, then fade: ImageDraw on RGBA
    F.alpha_composite(badge, (62, y))                   # overwrites alpha instead of blending
    d = ImageDraw.Draw(F)
    nf, uf = font("BarlowCondensed-SemiBold", 34), font("BarlowCondensed-SemiBold", 28)
    name = brand.get("footer_name", "AMBITION MECHANICAL SERVICES")
    x = 62 + bs + 26
    tx = x
    for ch in name:  # tracked caps like the GPT footer
        d.text((tx, y + 30), ch, font=nf, fill=(255, 255, 255, 255), anchor="lm"); tx += nf.getlength(ch) + 3
    d.text((x, y + 70), brand.get("url", ""), font=uf, fill=rgb(brand["roles"]["muted"]) + (255,), anchor="lm")
    rx1 = W - 62
    d.rectangle((rx1 - 110, y + 50, rx1, y + 56), fill=rgb(brand["roles"]["accent"]) + (255,))
    if progress:
        pf = font("BarlowCondensed-ExtraBold", 34)
        d.text((rx1, y + 22), progress, font=pf, fill=(255, 255, 255, 255), anchor="rm")
    if a < 1:
        F.putalpha(F.getchannel("A").point(lambda v: int(v * a)))
    canvas.alpha_composite(F)
    reg.add("footer", (62, y, rx1, y + badge.height), text=False)


def load_plate(path, W, H):
    """GPT plate (gpt_sheet.py `<name>_plate.png`, green window already transparent) scaled to the canvas.
    Returns (plate RGBA, [window boxes in canvas px, largest first]). The transparency is grown 3 px so no
    green fringe survives the key."""
    from gpt_sheet import windows as find_windows
    pl = Image.open(path).convert("RGBA")
    src_panel = path.replace("_plate.png", ".png")
    sx, sy = W / pl.width, H / pl.height
    ws = find_windows(Image.open(src_panel)) if os.path.exists(src_panel) else []
    boxes = sorted([(int(w["bbox"][0] * sx), int(w["bbox"][1] * sy), int(w["bbox"][2] * sx), int(w["bbox"][3] * sy)) for w in ws],
                   key=lambda b: -(b[2] - b[0]) * (b[3] - b[1]))
    pl = pl.resize((W, H), Image.LANCZOS)
    a = pl.getchannel("A").filter(ImageFilter.MinFilter(7))
    pl.putalpha(a)
    return pl, boxes


def render_postcard(sl, spec, brand, out_dir, still_only):
    """Postcard slide: brand halftone field, the photo as a bordered card (native 3:2), red location stamp,
    capture time as the slab headline, one short note under the card. Card drops in; stamp thumps on."""
    from clipkit.components import Texture
    W, H = spec["size"]; fps = spec.get("fps", 24)
    n = 1 if still_only else int(spec.get("dur", 4.0) * fps)
    reg = Registry(W, H, spec.get("zones", False))
    tex = Texture(W, H, brand["roles"]["bg"], brand["colors"].get("halftone_dot", "#23345A"), kind="halftone", seed=len(sl["id"]))
    im = Image.open(sl["photo"] if os.path.isabs(sl["photo"]) else os.path.join(STILL_BASE[0], sl["photo"])).convert("RGB")
    if sl.get("crop"):
        fx0, fy0, fx1, fy1 = sl["crop"]; im = im.crop((int(fx0 * im.width), int(fy0 * im.height), int(fx1 * im.width), int(fy1 * im.height)))
    pw = W - 2 * 62 - 2 * 20; ph = int(pw * 2 / 3)
    im = im.resize((pw, int(pw * im.height / im.width)), Image.LANCZOS).crop((0, 0, pw, ph))
    card = Image.new("RGBA", (pw + 40, ph + 40), (244, 241, 234, 255))
    card.paste(im, (20, 20))
    hl = Headline(brand, sl["headline"], measure=sl.get("measure", 900), max_size=sl.get("max_size", 150))
    lx, ly = 62, 70
    if sl.get("plate"):
        return _postcard_on_plate(sl, spec, brand, out_dir, still_only, im, hl, reg, W, H, fps, n)
    top = ly + hl.height + 40
    foot_top = H - 60 - 104 - 36
    block = card.height + 34 + 100          # card + gap + ~2 sentence lines
    cy = int(top + max(0, (foot_top - top - block) / 2))
    stamp_lines = sl.get("stamp", ["FASHION SQUARE", "SCOTTSDALE, AZ"])
    sf = font("BarlowCondensed-ExtraBold", 30); sf2 = font("BarlowCondensed-SemiBold", 24)
    sw_ = int(max(sf.getlength(stamp_lines[0]), sf2.getlength(stamp_lines[1]))) + 36
    stamp = Image.new("RGBA", (sw_, 86), rgb(brand["roles"]["accent"]) + (255,))
    sd = ImageDraw.Draw(stamp)
    sd.rectangle((5, 5, sw_ - 6, 80), outline=(255, 255, 255, 220), width=2)
    sd.text((sw_ / 2, 30), stamp_lines[0], font=sf, fill=(255, 255, 255), anchor="mm")
    sd.text((sw_ / 2, 60), stamp_lines[1], font=sf2, fill=(255, 255, 255), anchor="mm")
    stamp = stamp.rotate(-4, expand=True, resample=Image.BICUBIC)

    def draw(k, t):
        reg.reset()
        c = tex.frame(0 if t is None else t)
        hl.draw(c, lx, ly, t, start=0.1)
        reg.add("headline", (lx, ly, lx + hl.width, ly + hl.height))
        q = 1.0 if t is None else ease_out(prog(t, 0.35, 0.5))
        cx0 = 62
        if q > 0:
            rot = (1 - q) * -3 + sl.get("tilt", -1.2)
            C = card.rotate(rot, expand=True, resample=Image.BICUBIC)
            # soft shadow
            shw = Image.new("RGBA", C.size, (0, 0, 0, 0)); shw.putalpha(C.getchannel("A").point(lambda v: int(v * 0.55)))
            shw = shw.filter(ImageFilter.GaussianBlur(14))
            ox = cx0 + (card.width - C.width) / 2; oy = cy + (1 - q) * 60 + (card.height - C.height) / 2
            place(c, shw, ox + 10, oy + 16, "lt", 1, q)
            place(c, C, ox, oy, "lt", 1, min(1, q * 1.5))
        reg.add("card", (cx0, cy, cx0 + card.width, cy + card.height), text=False)
        sq = 1.0 if t is None else prog(t, 1.0, 0.18)
        if sq > 0:
            sx, sy = cx0 + card.width - stamp.width + 14, cy - 34
            place(c, stamp, sx + stamp.width / 2, sy + stamp.height / 2, "mm", lerp(1.35, 1.0, ease_out(sq)), min(1, sq * 2))
        ny = cy + card.height + 34
        if sl.get("sentence"):
            bh = sentence_block(c, brand, sl["sentence"], lx + 6, ny, sl.get("sentence_w", 900), t, 1.25)
            reg.add("sentence", (lx, ny, lx + 900, ny + bh))
        footer(c, brand, W, H, sl.get("progress"), reg, t)
        return c.convert("RGB")

    return _write(sl, draw, n, W, H, fps, out_dir, still_only, reg)


def _postcard_on_plate(sl, spec, brand, out_dir, still_only, im, hl, reg, W, H, fps, n):
    """Postcard on a GPT plate: photo keyed into the card's green window, stamp text set inside the plate's
    red stamp, note under the card's bottom edge (both found in the plate by colour)."""
    pp = sl["plate"] if os.path.isabs(sl["plate"]) else os.path.join(STILL_BASE[0], sl["plate"])
    plate, wins = load_plate(pp, W, H)
    wx0, wy0, wx1, wy1 = wins[0]
    ww, wh = wx1 - wx0, wy1 - wy0
    ph = im.copy(); r = max(ww / ph.width, wh / ph.height)
    ph = ph.resize((int(ph.width * r) + 2, int(ph.height * r) + 2), Image.LANCZOS)
    ox, oy = (ph.width - ww) // 2, (ph.height - wh) // 2
    ph = ph.crop((ox, oy, ox + ww, oy + wh))
    a = np.asarray(plate.convert("RGB")).astype(int)
    red = (a[..., 0] > 170) & (a[..., 1] < 80) & (a[..., 2] < 80)
    ys, xs = np.where(red[: H // 2])
    stamp_box = (xs.min(), ys.min(), xs.max(), ys.max()) if len(xs) else None
    paper = (a[..., 0] > 215) & (a[..., 1] > 210) & (a[..., 2] > 195) & (np.abs(a[..., 0] - a[..., 2]) < 40)
    rows = np.where(paper.mean(1) > 0.05)[0]
    card_bottom = int(rows.max()) if len(rows) else wy1
    lines = sl.get("stamp", ["SCOTTSDALE", "AZ"])
    lx, ly = 62, 70

    def draw(k, t):
        reg.reset()
        c = Image.new("RGBA", (W, H), rgb(brand["roles"]["bg"]) + (255,))
        z = 1 + 0.03 * k / max(1, n - 1)
        pz = ph.resize((int(ww * z), int(wh * z)), Image.LANCZOS)
        pz = pz.crop(((pz.width - ww) // 2, (pz.height - wh) // 2, (pz.width - ww) // 2 + ww, (pz.height - wh) // 2 + wh)).convert("RGBA")
        q = 1.0 if t is None else ease_out(prog(t, 0.3, 0.5))
        if q < 1:
            pz.putalpha(int(255 * q))
        c.alpha_composite(pz, (wx0, wy0))
        c.alpha_composite(plate)
        hl.draw(c, lx, ly, t, start=0.1)
        reg.add("headline", (lx, ly, lx + hl.width, ly + hl.height))
        if stamp_box:
            sx0, sy0, sx1, sy1 = stamp_box
            sq = 1.0 if t is None else prog(t, 0.9, 0.2)
            if sq > 0:
                L = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(L)
                cxs, cys = (sx0 + sx1) / 2, (sy0 + sy1) / 2
                sw0 = (sx1 - sx0) * 0.72  # fit both lines inside the stamp's inner border
                s1 = int((sx1 - sx0) * 0.22)
                while s1 > 10 and font("BarlowCondensed-ExtraBold", s1).getlength(lines[0]) > sw0: s1 -= 1
                f1 = font("BarlowCondensed-ExtraBold", s1); f2 = font("BarlowCondensed-SemiBold", int(s1 * 0.8))
                d.text((cxs, cys - (sy1 - sy0) * 0.1), lines[0], font=f1, fill=(255, 255, 255, 255), anchor="mm")
                d.text((cxs, cys + (sy1 - sy0) * 0.17), lines[1], font=f2, fill=(255, 255, 255, 255), anchor="mm")
                L.putalpha(L.getchannel("A").point(lambda v: int(v * min(1, sq * 2))))
                c.alpha_composite(L)
            reg.add("stamp", stamp_box, text=False)
        ny = card_bottom + 36
        if sl.get("sentence"):
            bh = sentence_block(c, brand, sl["sentence"], lx + 6, ny, sl.get("sentence_w", 900), t, 1.0)
            reg.add("sentence", (lx, ny, lx + 900, ny + bh))
        footer(c, brand, W, H, sl.get("progress"), reg, t)
        return c.convert("RGB")

    return _write(sl, draw, n, W, H, fps, out_dir, still_only, reg)


def _write(sl, draw, n, W, H, fps, out_dir, still_only, reg):
    draw(n - 1, None).save(os.path.join(out_dir, f"{sl['id']}.png"))
    if not still_only:
        out = os.path.join(out_dir, f"{sl['id']}.mp4")
        enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(fps),
                                "-i", "-", "-c:v", "libx264", "-crf", "17", "-preset", "medium", "-pix_fmt", "yuv420p",
                                "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709", "-movflags", "+faststart", out],
                               stdin=subprocess.PIPE)
        for k in range(n):
            enc.stdin.write(draw(k, k / fps).tobytes())
        enc.stdin.close(); enc.wait()
    return reg.fail


def render_slide(sl, spec, brand, out_dir, still_only):
    W, H = spec["size"]; fps = spec.get("fps", 24)
    n = 1 if still_only else int(spec.get("dur", 5.0) * fps)
    bg = sl["bg"]
    plate, wins = (None, [])
    if sl.get("plate"):
        pp = sl["plate"] if os.path.isabs(sl["plate"]) else os.path.join(STILL_BASE[0], sl["plate"])
        plate, wins = load_plate(pp, W, H)
    wx, wy, wx1, wy1 = wins[0] if wins else (0, 0, W, H)
    ww, wh = (wx1 - wx) // 2 * 2, (wy1 - wy) // 2 * 2
    frames, s2o, (OW, OH) = decode_bg(bg, spec["src_root"], ww, wh, n if not still_only else 1)
    reg = Registry(W, H, spec.get("zones", False))
    sh = shade(W, H, brand["roles"]["bg"]) if plate is None else None
    hl = Headline(brand, sl["headline"], measure=sl.get("measure", 900), slab_scale=1.0, max_size=sl.get("max_size", 170))
    lx, ly = 62, 70

    def draw(k, t):
        reg.reset()
        img, o2c0, sc = zoom_frame(frames[min(k, len(frames) - 1)], k, n, bg.get("zoom", 0.03), ww, wh, OW, OH)
        drop = 0 if plate is not None else int(H * sl.get("drop", 0))   # photo below a headline band (no plate)
        o2c = lambda ox, oy: (o2c0(ox, oy)[0] + wx, o2c0(ox, oy)[1] + wy + drop)
        if plate is not None:   # template mode: footage keyed into the GPT plate's green window
            c = Image.new("RGBA", (W, H), rgb(brand["roles"]["bg"]) + (255,))
            fi = img.convert("RGBA")
            if sl.get("window_shade", 0.7):  # soft top shade inside the window so text that spills in stays readable
                g = (np.clip(1 - np.arange(wh)[:, None] / 240.0, 0, 1) ** 1.6 * 255 * sl.get("window_shade", 0.7)).repeat(ww, 1).astype(np.uint8)
                L = Image.new("RGBA", (ww, wh), rgb(brand["roles"]["bg"]) + (0,)); L.putalpha(Image.fromarray(g)); fi.alpha_composite(L)
            c.alpha_composite(fi, (wx, wy))
        elif drop:
            c = Image.new("RGBA", (W, H), rgb(brand["roles"]["bg"]) + (255,))
            ph = img.convert("RGBA").crop((0, 0, W, H - drop))
            fe = min(220, H - drop)  # feather the top edge into the band: no hard line behind the headline
            ph.putalpha(Image.fromarray((np.clip(np.arange(H - drop)[:, None] / fe, 0, 1) ** 1.5 * 255).repeat(W, 1).astype(np.uint8)))
            c.alpha_composite(ph, (0, drop))
        else:
            c = img.convert("RGBA")
        if sl.get("inset") and len(wins) > 1:   # magnified crop keyed into the plate's second window
            ins = sl["inset"]; sx_, sy_ = ins["at"]; rr = ins["src_r"]; ix0, iy0, ix1, iy1 = wins[1]
            q = 1.0 if t is None else ease_out(prog(t, 1.4, 0.4))
            if q > 0:
                ox0, oy0 = s2o(sx_ - rr, sy_ - rr); ox1, oy1 = s2o(sx_ + rr, sy_ + rr)
                cr = Image.fromarray(frames[min(k, len(frames) - 1)]).crop((int(ox0), int(oy0), int(ox1), int(oy1))).resize((ix1 - ix0, iy1 - iy0), Image.LANCZOS).convert("RGBA")
                if q < 1:
                    cr.putalpha(int(255 * q))
                c.alpha_composite(cr, (ix0, iy0))
            reg.add("inset", (ix0, iy0, ix1, iy1), text=False)
        if plate is not None:
            c.alpha_composite(plate)
        if sh is not None:
            c.alpha_composite(sh)
        for fb in sl.get("faces", []):
            p0 = o2c(*s2o(fb[0], fb[1])); p1 = o2c(*s2o(fb[2], fb[3]))
            reg.add("face", (p0[0], p0[1], p1[0], p1[1]), text=False)
        hy = ly
        if sl.get("kicker"):   # series kicker in the GPT CTA-box style, e.g. "AMBITION'S AT IT AGAIN"
            K = label_box(sl["kicker"], brand, sl.get("kicker_size", 40))
            kq = 1.0 if t is None else ease_out(prog(t, 0.0, 0.25))
            if kq > 0:
                place(c, K, lx + (1 - kq) * -30, ly, "lt", 1, kq)
            reg.add("kicker", (lx, ly, lx + K.width, ly + K.height))
            hy = ly + K.height + 22
        hl.draw(c, lx, hy, t, start=0.2 if sl.get("kicker") else 0.1)
        reg.add("headline", (lx, hy, lx + hl.width, hy + hl.height))
        y = hy + hl.height + 30
        if sl.get("sentence"):
            bh = sentence_block(c, brand, sl["sentence"], lx + 6, y, sl.get("sentence_w", 760), t, 0.55)
            reg.add("sentence", (lx, y, lx + sl.get("sentence_w", 760), y + bh))
        if sl.get("inset") and len(wins) < 2:
            ins = sl["inset"]; sx, sy = ins["at"]; rr = ins["src_r"]; bx, by, bs = ins["box"]
            q = 1.0 if t is None else ease_back(prog(t, 1.6, 0.45), 1.2)
            if q > 0:
                ox0, oy0 = s2o(sx - rr, sy - rr); ox1, oy1 = s2o(sx + rr, sy + rr)
                crop = Image.fromarray(frames[min(k, len(frames) - 1)]).crop((int(ox0), int(oy0), int(ox1), int(oy1))).resize((bs, bs), Image.LANCZOS)
                box = Image.new("RGBA", (bs + 16, bs + 16), (255, 255, 255, 255))
                box.paste(crop, (8, 8))
                ImageDraw.Draw(box).rectangle((0, 0, bs + 15, bs + 15), outline=rgb(brand["roles"]["accent"]), width=6)
                place(c, box, bx + (bs + 16) / 2, by + (bs + 16) / 2, "mm", lerp(0.6, 1, q), min(1, q * 2))
            reg.add("inset", (bx, by, bx + bs + 16, by + bs + 16))
        for i, co in enumerate(sl.get("callouts", [])):
            px, py = co["at_out"] if "at_out" in co else o2c(*s2o(*co["at"])); r = co.get("r", 140) * (W / 1080)
            t0 = 1.0 + i * 0.5
            p = 1.0 if t is None else ease_out(prog(t, t0, 0.55))
            ring(c, px, py, r, brand["roles"]["accent"], p, seed=3 + i)
            reg.add(f"{'ringin' if co.get('on_inset') else 'ring'}#{i}", (px - r, py - r, px + r, py + r), text=False)
            if co.get("label"):
                L = label_box(co["label"], brand, co.get("size", 44))
                bx, by = co.get("label_at", (px + r + 20, py - L.height / 2))
                q = 1.0 if t is None else prog(t, t0 + 0.35, 0.25)
                if q > 0:
                    place(c, L, bx + (1 - ease_out(q)) * -24, by, "lt", 1, min(1, q * 2))
                reg.add(f"label#{i}", (bx, by, bx + L.width, by + L.height))
        footer(c, brand, W, H, sl.get("progress"), reg, t)
        return c.convert("RGB")

    still = draw(n - 1, None)
    still.save(os.path.join(out_dir, f"{sl['id']}.png"))
    if not still_only:
        out = os.path.join(out_dir, f"{sl['id']}.mp4")
        enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(fps),
                                "-i", "-", "-c:v", "libx264", "-crf", "17", "-preset", "medium", "-pix_fmt", "yuv420p",
                                "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709", "-movflags", "+faststart", out],
                               stdin=subprocess.PIPE)
        for k in range(n):
            enc.stdin.write(draw(k, k / fps).tobytes())
        enc.stdin.close(); enc.wait()
    return reg.fail


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("post"); ap.add_argument("out")
    ap.add_argument("--still-only", action="store_true"); ap.add_argument("--only", default="")
    a = ap.parse_args()
    spec = json.load(open(a.post)); STILL_BASE[0] = os.path.dirname(os.path.abspath(a.post))
    bpath = os.path.join(SKILL, spec["brand"])
    brand = json.load(open(bpath)); brand["_slug"] = os.path.basename(os.path.dirname(bpath))
    if spec.get("sentence_style"):  # per-post override of type_style.sentence (for A/B tests)
        brand.setdefault("type_style", {}).setdefault("sentence", {}).update(spec["sentence_style"])
    os.makedirs(a.out, exist_ok=True)
    only = set(filter(None, a.only.split(",")))
    bad = False
    for sl in spec["slides"]:
        if only and sl["id"] not in only:
            continue
        fn = render_postcard if sl.get("layout") == "postcard" else render_slide
        fails = fn(sl, spec, brand, a.out, a.still_only)
        print(sl["id"], "OK" if not fails else "FAIL", *sorted(fails), sep="\n  " if fails else " ", flush=True)
        bad |= bool(fails)
    sys.exit(2 if bad else 0)


if __name__ == "__main__":
    main()
