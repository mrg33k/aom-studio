#!/usr/bin/env python3
"""Fill in `focus` (face center, normalized) for every segment of a clip plan so crops follow the face.

  python3 find_focus.py PLAN.json [--write]

Uses OpenCV's bundled Haar cascades (pip install opencv-python-headless). Samples 3 frames per segment,
takes the largest face, averages. Segments with no face keep the speaker default and are flagged so a
human can set them (wide shots, hands-on-equipment shots). Never trust this blindly on B-roll-heavy footage:
check the style-frame sheet.
"""
import json, sys, subprocess
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
from clipkit.core import Source

def main():
    import cv2
    plan_p = Path(sys.argv[1]).resolve()
    plan = json.loads(plan_p.read_text())
    base = plan_p.parent
    casc = [cv2.CascadeClassifier(cv2.data.haarcascades + n) for n in
            ("haarcascade_frontalface_default.xml", "haarcascade_profileface.xml")]
    readers = {}
    for k, sg in enumerate(plan["segments"]):
        src = plan["sources"][sg.get("src", "main")]
        p = src["path"] if Path(src["path"]).is_absolute() else str(base / src["path"])
        rd = readers.setdefault(p, Source(p, 10, max_w=960))
        hits = []
        a, b = sg["in"] - src.get("offset", 0), sg["out"] - src.get("offset", 0)
        for f in (0.2, 0.5, 0.8):
            img = np.array(rd.frame(a + (b - a) * f).convert("L"))
            best = None
            for c in casc:
                for (x, y, w, h) in c.detectMultiScale(img, 1.1, 6, minSize=(img.shape[0] // 12,) * 2):
                    if best is None or w * h > best[2] * best[3]:
                        best = (x, y, w, h)
            if best is not None:
                x, y, w, h = best
                hits.append(((x + w / 2) / img.shape[1], (y + h / 2) / img.shape[0], w / img.shape[1]))
        if hits:
            fx, fy, fw = np.median(np.array(hits), axis=0)
            sg["focus"] = [round(float(fx), 3), round(float(min(0.6, fy + 0.06)), 3)]
            print(f"seg {k}: focus {sg['focus']} (face width {fw:.2f}, {len(hits)}/3 frames)")
        else:
            print(f"seg {k}: NO FACE - set focus by hand (kept {sg.get('focus', 'speaker default')})")
    if "--write" in sys.argv:
        plan_p.write_text(json.dumps(plan, indent=2)); print("updated", plan_p)
    for r in readers.values():
        r.close()

if __name__ == "__main__":
    main()
