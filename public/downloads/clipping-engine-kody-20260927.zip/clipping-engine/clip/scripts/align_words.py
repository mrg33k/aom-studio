import json, re, numpy as np, torch, torchaudio
torch.set_num_threads(4)
SR=16000
x=np.fromfile("audit48.f32",dtype=np.float32)
wav=torchaudio.functional.resample(torch.from_numpy(x.copy()),48000,SR)
W=[w for s in json.load(open("hq2.json"))["segments"] for w in s.get("words",[]) if w["word"].strip() not in ("Tim","Cynova")]
SEGS = [(139.36, 142.84),(9.06, 12.24),(46.80, 47.98),(48.12, 48.80),(158.14, 159.60),(160.36, 163.84),(165.04, 168.29),(175.84, 179.79),(132.54, 133.36),(134.62, 137.00),(144.00, 146.28),(155.22, 157.62),(197.80, 200.66)]
b=torchaudio.pipelines.WAV2VEC2_ASR_BASE_960H
model=b.get_model().eval(); labels=b.get_labels(); d={c:i for i,c in enumerate(labels)}
NUM={"2023":"TWENTY TWENTY THREE"}
def norm(w):
    w=w.strip().strip(".,?!").upper()
    return NUM.get(w,w)
out={}
for k,(a,bb) in enumerate(SEGS):
    ws=[w for w in W if w["end"]>a-1.2 and w["start"]<bb+1.2]
    t0=max(0,ws[0]["start"]-0.4); t1=ws[-1]["end"]+0.4
    chunk=wav[int(t0*SR):int(t1*SR)].unsqueeze(0)
    with torch.inference_mode():
        em,_=model(chunk); em=torch.log_softmax(em,-1)
    toks=[norm(w["word"]) for w in ws]
    # expand multi-word number tokens
    words=[]; 
    for t in toks: words+= [re.sub(r"[^A-Z']","",p) for p in t.split()]
    words=[w for w in words if w]
    tgt=torch.tensor([[d[c] for c in "|".join(words)]],dtype=torch.int32)
    al,sc=torchaudio.functional.forced_align(em,tgt,blank=0)
    al=al[0].tolist(); sc=sc[0].exp().tolist()
    ratio=chunk.shape[1]/em.shape[1]/SR
    # token spans -> words
    spans=torchaudio.functional.merge_tokens(torch.tensor(al),torch.tensor(sc))
    res=[]; wi=0; cur=[]
    for s in spans:
        if labels[s.token]=="|":
            if cur: res.append(cur); cur=[]
        else: cur.append(s)
    if cur: res.append(cur)
    aw=[dict(w=words[i],s=round(t0+r[0].start*ratio,3),e=round(t0+r[-1].end*ratio,3),p=round(float(np.mean([z.score for z in r])),2)) for i,r in enumerate(res)]
    out[k]=aw
    print(k, " ".join(f"{z['w']}[{z['s']:.2f}-{z['e']:.2f}]" for z in aw))
json.dump(out,open("aligned.json","w"),indent=1)
