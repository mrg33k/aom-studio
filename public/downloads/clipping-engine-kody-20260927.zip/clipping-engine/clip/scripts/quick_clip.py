#!/usr/bin/env python3
"""Cut a 9:16 podcast clip with a hook title and word-timed captions.
usage: make_clip.py SRC TRANSCRIPT_JSON START END "HOOK TITLE" OUT.mp4
"""
import json, os, subprocess, sys
from PIL import Image, ImageDraw, ImageFont

src, tj, start, end, hook, out = sys.argv[1], sys.argv[2], float(sys.argv[3]), float(sys.argv[4]), sys.argv[5], sys.argv[6]
W, H = 1080, 1920
VID_Y = 620            # top of the 16:9 video band (1080x608)
CAP_Y = 1330           # caption center line
FONT = "/System/Library/Fonts/Supplemental/Arial Bold.ttf"
tmp = out + ".parts"; os.makedirs(tmp, exist_ok=True)

words = [w for s in json.load(open(tj))["segments"] for w in s.get("words", [])]
words = [w for w in words if start <= w["start"] < end]

# group words into short caption chunks: max 3 words, break on punctuation or pauses
chunks, cur = [], []
for i, w in enumerate(words):
    cur.append(w)
    t = w["word"].strip()
    nxt = words[i + 1]["start"] if i + 1 < len(words) else None
    if len(cur) >= 3 or t[-1:] in ".,?!" or (nxt and nxt - w["end"] > 0.35) or nxt is None:
        chunks.append(cur); cur = []

def text_img(txt, size, path, box_w=980, fill="white", stroke=8):
    f = ImageFont.truetype(FONT, size)
    img = Image.new("RGBA", (W, size * 3), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    # simple word wrap
    lines, line = [], ""
    for word in txt.split():
        test = (line + " " + word).strip()
        if d.textlength(test, font=f) > box_w and line:
            lines.append(line); line = word
        else:
            line = test
    lines.append(line)
    img = Image.new("RGBA", (W, int(size * 1.2 * len(lines)) + 30), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for n, ln in enumerate(lines):
        x = (W - d.textlength(ln, font=f)) / 2
        d.text((x, 10 + n * size * 1.2), ln, font=f, fill=fill, stroke_width=stroke, stroke_fill="black")
    img.save(path)
    return img.size[1]

# hook title
hook_h = text_img(hook.upper(), 78, f"{tmp}/hook.png", fill="#FFD84D")

pre = max(0.0, start - 5)
inputs, filters = ["-ss", f"{pre:.3f}", "-i", src, "-i", f"{tmp}/hook.png"], []
filters.append(f"[0:v]trim=start={start-pre:.3f}:duration={end-start:.3f},setpts=PTS-STARTPTS,scale={W}:-2,split[fg][bgsrc]")
filters.append(f"[0:a]atrim=start={start-pre:.3f}:duration={end-start:.3f},asetpts=PTS-STARTPTS[aout]")
filters.append(f"[bgsrc]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},boxblur=40:5,eq=brightness=-0.35[bg]")
filters.append(f"[bg][fg]overlay=0:{VID_Y}[v0]")
filters.append(f"[v0][1:v]overlay=0:{VID_Y - hook_h - 60}[v1]")
last = "v1"
for i, c in enumerate(chunks):
    txt = " ".join(w["word"].strip() for w in c).upper().replace(" %", "%").replace(" ,000", ",000").replace(" -", "-")
    p = f"{tmp}/c{i}.png"
    h = text_img(txt, 92, p)
    inputs += ["-i", p]
    a = c[0]["start"] - start
    b = (chunks[i + 1][0]["start"] if i + 1 < len(chunks) else end) - start
    filters.append(f"[{last}][{i + 2}:v]overlay=0:{CAP_Y - h // 2}:enable='gte(t,{a:.2f})*lt(t,{b:.2f})'[v{i + 2}]")
    last = f"v{i + 2}"

subprocess.run(["ffmpeg", "-v", "error", "-y", *inputs, "-filter_complex", ";".join(filters),
                "-map", f"[{last}]", "-map", "[aout]", "-c:v", "libx264", "-preset", "fast", "-crf", "20",
                "-c:a", "aac", "-b:a", "160k", "-r", "30", out], check=True)
print(out, len(chunks), "captions")
