# Raw shoots and existing production tools

Use this only for job-site, event, or B-roll-heavy shoots. Prospect podcast/interview clips follow `prospect-workflow.md`. The historical preference for Patrik to edit a main raw-shoot story reel does not assign prospect clipping back to him.

5. **Raw shoot → post menu** (full method: `reference/format-recipes.md`). For B-roll-heavy shoots (trades, events):
   - Make 480p proxies.
   - Index every clip (action, people, place, parts, best 4–8 s Moment).
   - Write a one-page story map (problem, fix, result, people, place, parts, numbers, quotes, peaks).
   - Match format recipes and draft a 10–14 post menu balanced across saves, shares, comments and trust. Patrik picks.
   - Then export only the picked Moments at full quality.
   - Formats that suit agents today: Moments (3–5 s graded, push-in, loop), moment montage, postcard carousel, learning carousel, zoom-in / panorama / spot-the-problem carousels.

## Production notes

## Gotchas learned the hard way

- Remote file staging from the Mac is flaky above ~10 MB and capped at 400 MB; the remote shell dies when its disk fills. Process big footage locally (proxies, Moment exports) and move small files.
- Ronin 4D .MOV may be ProRes RAW, which ffmpeg can't decode: make proxies in Resolve. (Élephante 2026-09-01 was ProRes 422 Proxy `apcs` 4K and decoded fine; check `ffprobe` codec_tag first.) Ronin files also carry an MJPEG preview stream; map `0:v:0` explicitly.
- Shoot index: `scripts/index_shoot.py <proxy_dir> <out.json>` sends each whole proxy (not sampled frames) to Gemini and returns action, people, place, parts, story role, speech, best Moment in/out, loopable, q/a. Tell it in `--context` who the client crew is and who is OUR shooter, or BTS clips get scored as job footage.
- Gemini free tier = ~20 requests/day PER MODEL. `index_shoot.py` rotates through flash models on a daily-quota 429; 70 clips used 7 models. Don't retry-sleep on a PerDay 429, it never clears.
- Whisper hallucinates on wind/ambient-only clips ("Thank you", "I'm going to go to the next video" looped). Keep only segments with `no_speech_prob < 0.5` and `avg_logprob > -0.8`, and trust a line only if Gemini also heard `speech: talking`.
- Raw crew audio has swearing and banter. Read every transcript before using a clip's audio; mark clips "picture only" in the story map.
- zsh: `for spec in "a 6"; do set -- $spec` doesn't word-split and ffmpeg gets `-ss -i`. Loop in Python. `xargs -I{}` with a long inline command fails with "command line cannot be assembled"; use a helper script + `xargs -0 -n 1`.
- PIL: `ImageDraw.text(fill=(r,g,b,a))` on an RGBA canvas OVERWRITES alpha, it doesn't blend, so faded text shows at full strength once flattened to RGB. Draw fading elements on their own layer, scale its alpha, `alpha_composite`.
- Callouts must sit where the tech points WHILE he names the part (transcript segment time -> that frame). Handheld cameras drift, so pin callouts on a still frame (slow push-in), not on moving video.
- A top headline lands on faces and ceiling details, because heads and ceilings sit at the top of the frame. Use `drop` (0.14-0.28): the footage sits under a brand-colour band with a feathered edge, like the GPT "Social Posts" series. Mark `faces` so the clash check can see them. Without face boxes it can't catch a covered face (Élephante POV v1 shipped a headline over two faces to the strip check).
- Ring callouts may only overlap their own label or another ring. Anything else (text, footer, inset, face) is a CLASH. A ring drawn inside a magnified inset needs `on_inset: true`.
- Postcard/photo-journal carousels: stamp the real EXIF capture time (`exiftool -DateTimeOriginal`). It's the most believable detail in the post and costs nothing.
- Don't fake a before/after. If the shoot has no "after" (clean part, unit running), switch format (tip carousel) and ask for the shot next time.
- Gemini review pass (flash-lite models still have quota after an index run): about 1 in 3 flags is wrong (it misread a URL and a zone). Verify each flag against the frame before changing anything.
- Template plates: ask GPT for NO TEXT/LOGO in the plate (the code sets all text crisp and animated). `gpt_sheet.py`'s gutter finder misreads a dark band next to green as a panel gap; slice by near-black full-height/width gutter lines instead. `render_post.load_plate` grows the key 3 px (no green fringe) and takes window boxes from the source panel.
- Plate mode keys: slide `"plate"` (+ inset keyed into the plate's 2nd window), `layout: postcard` + plate (photo into the card window, stamp text auto-fit into the plate's red stamp, note under the card's paper edge), reel `"plate"` + `"end_plate"` (badge centred in GPT's ring, follow line on GPT's slab; detect by red DENSITY, since GPT scatters red halftone in corners). Reels: `headline_y` >= 0.075 (the platform header covers the top ~5%).
- **Every carousel needs a cover** (Patrik 2026-09-25): hero photo + a series kicker (`"kicker"`, e.g. "AMBITION'S AT IT AGAIN") + one broad headline ("THIS TIME: FINE DINING."). Slide 1 as a detail shot never stops the scroll.
- **Broad strokes, not detail.** Tell the job as a story ("It started with the fan motor... it wouldn't come off... new board in"), not a parts list ("compressor control", "main PCB"). The owner is the audience, not the tech.
- **Secondary text = the headline's family, smaller** (`type_style.sentence.ink: true`, same italic + grit). Inter under a poster headline read as "Arial thrown in".
- Don't put the headline over the image's payoff (a sign, a face). Move the words to the plate's band instead.
- Waiting on a job with `until ! pgrep -f index_shoot.py` never ends: the waiter's own command line contains the name and matches itself. Wait on the job's background task instead, or `pgrep -f '[i]ndex_shoot.py'`.

- Renders need disk: check `df -h /System/Volumes/Data` first; the Mac hit 0 bytes free on 2026-09-25 mid-render.

- Crop sizes for rawvideo must be even (odd widths shear the image).
- Old Pillow: use `Image.frombytes`, not `frombuffer` (flips upside down).
- Georgia has old-style numbers ($1,000,000 looks uneven); use a lining-figure serif (Rockwell Bold).
- Screen-share cursor shows up in slide photos; patch it out of the still.
- Zoom face cams sit near the frame edge; center the crop on the face, tight enough to fill the bubble but not cut the head.
- Music: KIE (Suno) needs credits; fallback is a soft synthesized pad in the render script. Swap for a licensed track for paid work.
- SFX: soft swooshes only, from `corner/users/aom/agents/content-agent/audio/sfx/swooshes/`, volume ~0.10-0.18.
