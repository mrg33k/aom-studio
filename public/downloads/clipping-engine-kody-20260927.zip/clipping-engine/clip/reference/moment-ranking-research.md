# Moment ranking: how open-source clippers pick the best moments, and our recipe

Research date 2026-09-25. Read-only source review (no installs, no runs of third-party code). Tested on the Phoenix Prosperity Podcast episode (`/tmp/clip-test/a.json` + `a.wav`, ~32 min, host + Tim).

## TL;DR

- Every open-source tool that works well is **LLM-over-transcript first**. Audio features are either absent (SamurAIGPT) or a secondary booster (open-clip-studio). None use visual features to *pick* moments; vision is only for reframing/face tracking.
- The strongest structural idea is from OpenClipper: the picker returns **word indices, not timestamps**, and the app snaps cuts to real word edges plus silence. That kills hallucinated timestamps and mid-word cuts.
- Research (Rhapsody, 2025, 13k podcasts labeled by YouTube "most replayed") says zero-shot GPT-4o/Gemini are weak at highlight detection and text+audio beats text alone. So: LLM for meaning, audio for "did it land", and a human (Patrik) as the final gate.
- On our episode, audio alone found 2 of our 3 picks (water, fire story climax) in its top 8, but also flagged intro/outro "show voice" and a slide-share moment. The $1,000 build-to-rent line is audio-flat (43rd percentile): value moments come from words, not voice. Audio is a booster and a peak-locator, never the selector.

---

## 1. SamurAIGPT/AI-Youtube-Shorts-Generator

Source: `shorts_generator/highlights.py` (logic says it is ported from "ViralVadoo"), `pipeline.py`, `local/clipper.py`.

**How it finds moments: pure LLM over a segment-timestamped transcript.** No audio or visual scoring at all.

1. Transcript is flattened to lines `[{start:.1f}s] segment text` (Whisper segment level, not word level).
2. A cheap first call classifies content type and density from the first 25 segments (max 3000 chars):
   > "Analyze this video transcript sample and classify the content type. Choose one: podcast, interview, tutorial, lecture, commentary, debate, vlog, other. Also estimate content density: low (mostly filler/chit-chat), medium, or high (dense info/stories). Respond with JSON only"
3. Videos >= 1800 s are chunked into 1200 s windows with 60 s overlap; each chunk gets its own call; times are re-offset.
4. Highlight prompt (verbatim criteria, ranked by impact):
   ```
   1. HOOK MOMENTS: statements that create immediate curiosity ("The secret is...", "Nobody talks about...", "I was completely wrong about...")
   2. EMOTIONAL PEAKS: genuine surprise, laughter, anger, vulnerability, excitement; raw unscripted reactions
   3. OPINION BOMBS: strong, polarizing or counter-intuitive statements that trigger agree/disagree
   4. REVELATION MOMENTS: surprising facts, stats, or confessions that reframe how the viewer thinks
   5. CONFLICT/TENSION: disagreement, pushback, or a problem being confronted head-on
   6. QUOTABLE ONE-LINERS: a sentence that works as a standalone quote card
   7. STORY PEAKS: the climax or twist of an anecdote; the payoff moment
   8. PRACTICAL VALUE: a concrete tip, hack, or insight the viewer can immediately apply
   ```
   System framing: "You are an elite short-form video editor who has studied thousands of viral clips..." Rules: must open with a hook in the first 3 s; duration sweet spot 45-90 s, 20-44 s only for a perfect one-liner, 91-180 s only when a story arc needs it; never cut mid-sentence; score 0-100 "on viral potential (not general quality)"; return a `hook_sentence` and a one-sentence `virality_reason`. Output JSON: `title, start_time, end_time, score, hook_sentence, virality_reason`.
5. Asks for about 2x the wanted clip count (`target = max(n*2, 5)`, capped at 8 and at duration/90) so dedupe has headroom.
6. Dedupe: sort by score, drop any clip overlapping a kept one by more than 50% of its own length. Take top N by score.
7. Start/end: **whatever the LLM wrote**, clamped to video length. No snapping to words or silence.

**Clever:** the ranked criteria list is a good taxonomy; asking for a hook sentence + reason per clip makes output reviewable; over-generate then dedupe; content-type/density pre-pass.
**Weak:** LLM invents timestamps from segment starts (cuts land mid-word or mid-thought); a single 0-100 "viral" number hides why; no audio, so "emotional peak" is guessed from text only; no standalone-clarity check beyond one rule line; chunk boundaries can split a story (60 s overlap is thin for a 5 min anecdote).

## 2. paragbml/open-clip-studio

Source: `server/services/viralityService.js` (1,372 lines), `server/ml/acoustic_analyzer.py`, `semantic_scorer.py`, `virality_inference.py`, `config/hookPhrases.json`.

**How it finds moments: a hybrid.** Heuristic sliding-window scorer over word timestamps, an optional LLM pass, an ML regressor, then an LLM re-rank.

- **Sentence building:** words grouped into sentences by end punctuation, or a pause > 0.85 s when the last word is not a "dangling" word (and, the, but...). Candidates are sentence-aligned windows of 30-45 s, optionally expanded by one setup sentence before or one conclusion after.
- **Heuristic score per window** (point values from the code):
  - Hook regex on the first sentence, best match wins: "Shocking Confession" +48, "Actionable Advice" (the best way to, the secret to...) +35, "Curiosity Gap" (here's why, nobody talks about, the real reason) +32, "Pattern Interrupt" (stop doing, biggest mistake) +30, "Contrarian" (people don't realize, everyone thinks) +28, attention grabbers (wait, listen, here's the thing) +24, questions +15-22, "Hot Take" (honestly, the problem is) +20, "Storytelling" (years ago, I remember) +18, stats (million, percent) +16. Custom hook phrases +25. Intro/setup chatter -45.
  - Emotion word banks (high-stakes, surprise, humor, conflict, empathy, authority, curiosity, urgency, positive, negative) x1.4, +10 if total >= 10.
  - Speaker turns and Q-and-A inside the window (+12 if it has both a question and its answer).
  - Payoff regex at the end ("that's why", "bottom line", "the point is") +16; ending on a dangling word is penalized.
  - Pace: 140-175 wpm +12, 120-140 +6, under 120 **-20**, over 240 -10.
  - Duration pull toward 36 s: `+ (20 - |dur - 36| * 0.8)`.
- **Acoustic slice features** (numpy only, from the 16 kHz wav): mean RMS, crest factor (peak/RMS, "punch vs monotone"), **climax boost = RMS of last 25% / RMS of first 75%**, silence ratio, and zero-crossing-rate variance as a cheap pitch-animation proxy.
- **ML:** a 46-feature gradient-boosting regressor (hook, lexical emotion, acoustic, speaker-switch, MiniLM semantic similarity to "viral" vs "boring" exemplars). Its metrics file claims cross-val R^2 = 0.999 on 5,000 samples, which almost certainly means it was trained on labels derived from its own heuristics, not real view data. Treat it as a smoothed heuristic, not a learned virality model.
- **LLM prompt** (Groq Llama 3.3 70B): "find the top 5 most ENGAGING clips, each strictly between 30 and 45 seconds... IGNORE stream setup... Each clip MUST start with a strong hook... and end with a payoff... NEVER end mid-sentence... Prioritize: conflict/debate > humor/funny > emotional/story > educational > general conversation." It only sends `fullText.slice(0, 12000)`, so anything after roughly the first 12-15 minutes is invisible to the LLM.
- **Merge + re-rank:** LLM clips are primary; heuristic clips with score >= 70 that overlap LLM clips by < 30% are added. Final dedupe at 25% overlap. Then a "deep re-rank" LLM call sees the top 8 (first 320 chars each) and returns a boost, title, and one-line critique.
- **Teaser hook:** picks a 1.4-4.2 s sentence from 25-85% into the clip (question, shock word, emotion) to prepend as a cold open. Good idea for our reels.

**Clever:** climax-boost (energy rising toward the end = payoff landed); pace floor; sentence-aligned windows; Q-and-A completeness; teaser cold-open selector; hybrid LLM + heuristic merge.
**Weak:** regex/word-bank emotion is shallow and genre-specific (knife/police/cortisol); 12k-char truncation; fake-precision ML; fixed 30-45 s windows cannot hold a real story.

## 3. GrepCut/OpenClipper

Source: `src-tauri/src/mcp/ai_clips.rs`, `src/features/clipper/engine/transcript/ai-clip-builder.util.ts`, `word-boundaries.util.ts`.

**How it finds moments: it doesn't, by design.** There is no built-in scorer. It exposes an MCP server (`list_projects` -> `get_project_transcript` -> `patch_ai_clips`) and lets an outside agent (Claude, Cursor) read the transcript and write picks. Scoring via MCP is still on their roadmap. This is exactly our setup: Claude reads the transcript and picks.

What's worth stealing is the plumbing:
- Transcript is served with a **word index** per word. The agent returns `wordStartIdx / wordEndIdx`, never seconds. Times are looked up from the real words, so a pick cannot land mid-word or on a hallucinated time.
- A clip can be **multiple segments** (a supercut: hook line from minute 18 + setup from minute 16).
- Cut padding: 0.12 s pre-roll, 0.18 s post-roll, never more than the actual gap to the neighbor word, min 0.06 s gap between segments, then each edge is nudged to the nearest RMS silence within 0.15 s.
- Vision (face/pose/YOLO ONNX models) is only for reframing, not selection. It also vendors sherpa-onnx audio tagging (AudioSet classes, which include laughter) but not wired to picking.

## 4. Opus Clip (closed, published factors)

Opus publishes a 0-99 "Virality Score" built from four named factors: **Hook** (does the opening grab attention and relate to the topic), **Flow** (logical progression and a satisfying conclusion), **Value** (useful, emotional, personal connection), **Trend** (fits current topics). Reviewers describe it as hook strength + pacing + topic shifts. It's a sorting aid, not a promise; creators report it's loosely correlated with actual performance. Its "ClipAnything" mode adds visual scene understanding, but details aren't public.

## 5. Audio-side approaches worth knowing

- **Rhapsody (arXiv 2505.19429):** 13k podcast episodes, labels from YouTube "most replayed". Zero-shot GPT-4o/Gemini struggle; fine-tuned models win; speech features + transcript beat transcript alone. Implication: don't trust an LLM's number alone; combine with audio and with our own history of what actually performed.
- **Prosody features used in podcast research:** pitch standard deviation, speaking rate, intensity, voiced/unvoiced ratio. We compute all but voicing ratio below.
- **Laughter:** jrgillick/laughter-detection (PyTorch ResNet, trained on Switchboard, robust to noise) returns laugh (start, end) segments. Needs torch; not installed here, so it's a later add. Cheap proxy today: Whisper often drops laughs, but reaction words ("Wow.", "Oh whoa", "No way") from the *other* speaker are a good reaction marker. In our episode: "Wow." at 543, 1073, 1123, 1645 s, two of them inside the fire story.

---

## 6. Our episode test

Script: `/tmp/mr/audio_peaks.py` (copy below in the appendix). `/usr/bin/python3`, numpy + librosa 0.11 (already installed), 17 s runtime for 32 min.

Method: 0.1 s frames. Loudness = RMS dB on speech frames (above 30th percentile). Pitch = pYIN f0 (70-400 Hz) in semitones; median and 10-90% range per window. Pace = words per minute from Whisper word times. 10 s windows every 1 s. Each feature z-scored against its own +-90 s neighborhood (so a naturally loud or high-voiced speaker is judged against themselves), clipped to +-3. `arousal = 0.40 loud + 0.30 pitch + 0.15 pitch-range + 0.15 pace`, plus 0.25 x global loudness z. Top 8 with 30 s spacing.

| # | Time | Score | What's there | Verdict |
|---|---|---|---|---|
| 1 | 0:19 (19-29 s) | 2.87 | "Well, hey, everyone. Welcome back..." intro | False positive: show-open voice |
| 2 | 31:44 (1904 s) | 2.48 | "Fantastic. Fantastic. And if people want to reach out..." outro | False positive: outro |
| 3 | 6:46 (406 s) | 2.34 | "Getting rid of farms and putting up more housing is a fix to the water crisis. It is. It really is." | **HIT: our water clip**, pace 276 wpm, pitch +2.9 z |
| 4 | 5:01 (301 s) | 2.25 | "You just roll around a couple hundred billion, you'd think. Right. Right." | Maybe: banter/joke energy, worth a look |
| 5 | 27:45 (1665 s) | 1.98 | "Sweet dreams. And then he turns the light off and walks away. Oh, whoa." | Maybe: story beat + reaction (near "Wow." at 1645) |
| 6 | 8:30 (510 s) | 1.95 | "Well, wait, wait, wait... Can you see this screen? That's Lake Powell." | Energy is real but it's a screen-share, not standalone |
| 7 | 16:27 (987 s) | 1.94 | "When the firemen put everything out... a couple units... were saved. And a boy walked out..." | **HIT: climax of our fire story** |
| 8 | 10:18 (618 s) | 1.93 | "So remind us what it is... build-to-rent is when you build houses for" | Near-hit: setup to our build-to-rent clip (645 s) |

How our chosen moments score (percentile vs every 10 s window in the episode):

| Clip | Peak window | Peak pct | Mean pct |
|---|---|---|---|
| Fire / insurance story (935-1200 s) | 987 s | 99th | 48th |
| Houses save water (385-414 s) | 403 s | 99th | 67th |
| Build-to-rent $1,000 cheaper (645-672 s) | 654 s | 43rd | 26th |

Takeaways:
1. **Mask the first and last ~60-90 s** (and any "welcome/reach out/where can people find you" text). Two of eight slots were wasted on show-voice.
2. **Audio finds where a story peaks, not whether it's a good clip.** The fire story is 4+ minutes and averages 48th percentile, but its peak (the boy walking out, 987 s) is top 1%. That's the moment to open on or cold-open tease.
3. **Value/stat clips are audio-flat.** The $1,000 line is delivered calmly. Text scoring has to carry these. Never gate on audio.
4. **Speech rate spikes signal conviction.** The water line hit 276 wpm and +2.5 pace z; the fire climax 216 wpm. Pace was more telling here than loudness.
5. Screen-share moments (#6) need a visual/context flag: "can you see this", "here's a picture", "on the screen" lower standalone clarity.

---

## 7. Recommended recipe for us

1. **Transcribe once, word level** (mlx_whisper, already done). Build an indexed word list `[i] word (t)` and a sentence list (split on end punctuation, or pause > 0.7 s when the last word isn't a dangling word). Every candidate is a sentence range, so cuts are always clean.
2. **Compute the audio curve** (script below, ~20 s per 30 min): per-sentence loudness z, pitch z, pitch-range z, pace z, plus climax-boost (last 25% vs first 75% RMS of the candidate). Mask intro/outro. Also mark reaction words from the listener ("wow", "no way", "oh", laughs if Whisper kept them).
3. **Claude pass A, candidate finding (me, in chat, no API):** read the full sentence-indexed transcript in one go (32 min is about 6k words, it fits) with the audio-peak list printed in the margin as hints. Return 10-15 candidates as **sentence/word index ranges**, each with hook sentence, type, and reason. Allow a two-segment supercut (hook from later + setup from earlier).
4. **Score each candidate on four axes 1-5** (rubric below). Claude scores Hook, Standalone, and Words-Emotion; the script supplies Audio-Emotion. Combine: `total = 0.35 Hook + 0.25 Emotion + 0.25 Standalone + 0.15 Value`, where `Emotion = 0.6 words + 0.4 audio`. Hard gates: Standalone <= 2 is dropped regardless of total; a clip that starts on a dangling word or a pronoun with no referent fails.
5. **Snap boundaries** from indices: start 0.12 s before the first word, end 0.18-0.25 s after the last, never past half the gap to the neighbor word, nudged to the quietest 50 ms within 0.15 s. Length target 20-45 s for one-liners and value hits, 45-90 s for stories; if a story won't fit, supercut setup + climax rather than running long.
6. **Pick the cold-open line** (open-clip-studio idea): the highest-audio 1.5-4 s sentence from 25-85% into the clip, if the clip's first line is weak.
7. **Dedupe** by >40% overlap keeping the higher total, then give Patrik a plain ranked list (time, hook line, one-line reason, four scores). He calls it. Log which clips he picks and later which perform, so the weights can be tuned on our own data (Rhapsody's main lesson: in-domain signal beats generic judgment).

### Scoring rubric (1-5 each)

**Hook (first 3 s, would a stranger stop scrolling?)**
- 5: first sentence alone creates a question or tension: a surprising claim, number, stake, or reversal ("Putting up more housing fixes the water crisis.")
- 4: clear bold statement or story opener with stakes ("This building caught fire in 2023.")
- 3: on-topic but flat; needs the second sentence to grab
- 2: starts mid-idea, with filler (so, yeah, and), or a question to the guest
- 1: greeting, logistics, "can you see my screen"

**Emotion (words, Claude)**
- 5: raw reaction, danger, relief, humor landing, vulnerability, conflict
- 3: conviction or excitement about an idea
- 1: neutral explanation

**Emotion (audio, script)**: from the candidate's best sentence percentile in the episode: >=95th = 5, 85-95 = 4, 65-85 = 3, 40-65 = 2, <40 = 1. Add +1 (cap 5) if climax-boost > 1.3 or a listener reaction word falls inside or within 3 s after.

**Standalone clarity (makes sense with zero context?)**
- 5: a stranger gets the point and the payoff with no setup
- 4: needs one on-screen caption line of context (e.g. "Tim builds rental homes in Phoenix")
- 3: needs a one-sentence setup added from elsewhere (supercut)
- 2: relies on a visual, a slide, or an earlier "that/it/he" the viewer never saw
- 1: inside joke or continuation of a long thread

**Value / payoff**
- 5: concrete number, tip, or reversal the viewer can repeat to a friend ("$1,000 a month cheaper than a mortgage, no down payment")
- 3: a general lesson
- 1: no takeaway

### Example Claude prompt (adapt for pass A)

```
You are picking short-form clips (Reels/Shorts, 20-90 s) from a podcast episode.
Audience: <e.g. Phoenix real-estate investors and homeowners>. Brand voice: plain, positive, no hype.

Input:
- TRANSCRIPT: one sentence per line as  [S123 | 06:43.2] text
- AUDIO_HINTS: sentences where the speaker's voice got louder, higher, or faster than usual
  (percentile in this episode). High audio does NOT mean a good clip; it tells you where a story peaks.
- IGNORE: intro/outro, sponsor reads, "can you see my screen", greetings, contact info.

Find 12 candidate clips. Look for, in order of value for this audience:
1. Reversals or surprising facts (a common belief turned over, a number that shocks)
2. Story peaks: the climax or twist of an anecdote, plus the minimum setup to understand it
3. Concrete value: a number, rule, or tip someone could repeat to a friend
4. Strong opinions said with conviction
5. Genuine reactions: laughter, "wow", fear, relief

For each clip:
- Choose START and END sentence ids. Start on a sentence that works as the very first thing a
  stranger hears; never start on "so/and/but/yeah" or a pronoun with no referent. End on the payoff,
  not after it trails off.
- If the best hook comes after its setup, you may return two ranges (hook first, then setup+payoff).
- Score 1-5: hook, emotion_words, standalone, value (use the rubric definitions below).
- hook_line: the exact first sentence the viewer hears.
- reason: one plain sentence on why a stranger would watch to the end.
- context_caption: if standalone < 5, the one on-screen line that fixes it, else "".

<paste rubric>

Return JSON only:
{"clips":[{"ranges":[[S_start,S_end]],"hook_line":"","type":"reversal|story|value|opinion|reaction",
"hook":0,"emotion_words":0,"standalone":0,"value":0,"reason":"","context_caption":""}]}
Be harsh: most of an episode is not clip-worthy. A 3 is average, not good.
```

Then a script merges in audio scores, applies the weights and gates, snaps to word edges, and prints the ranked list for Patrik.

### What we should not copy
- Timestamps typed by the model (SamurAIGPT). Use indices.
- Fixed 30-45 s windows (open-clip-studio). Stories need room, or a supercut.
- Hand-built emotion word banks as the main emotion signal. Let Claude read tone; use audio as the physical check.
- A single opaque 0-100 "viral" number. Keep the four axes visible so Patrik can see why.

---

## Appendix: audio peak script (as run)

```python
"""Audio arousal curve + transcript pace -> top peaks. /usr/bin/python3 audio_peaks.py a.wav a.json"""
import sys, json, numpy as np, librosa
wav, tj = sys.argv[1], sys.argv[2]
y, sr = librosa.load(wav, sr=16000, mono=True)
HOP = 1600  # 0.1 s frames
rms = librosa.feature.rms(y=y, frame_length=3200, hop_length=HOP, center=True)[0]
db = 20*np.log10(rms + 1e-6)
f0, vflag, vprob = librosa.pyin(y, fmin=70, fmax=400, sr=sr, frame_length=2048,
                                hop_length=HOP, max_transition_rate=10)  # rate<=~20 or librosa errors at this hop
n = min(len(db), len(f0)); db, f0, vflag = db[:n], f0[:n], vflag[:n]
t = np.arange(n)*HOP/sr
semi = 12*np.log2(np.where(vflag & ~np.isnan(f0), f0, np.nan)/100.0)
speech = db > np.percentile(db, 30)  # crude VAD
d = json.load(open(tj)); words = [w for s in d['segments'] for w in s.get('words', [])]
wt = np.array([(w['start']+w['end'])/2 for w in words])
WIN, STEP = 10.0, 1.0
rows = []
for s0 in np.arange(0, t[-1]-WIN, STEP):
    m = (t >= s0) & (t < s0+WIN); sp = m & speech
    loud = np.mean(db[sp]) if sp.sum() > 20 else np.nan
    ps = semi[m]; ps = ps[~np.isnan(ps)]
    pitch = np.median(ps) if len(ps) > 15 else np.nan
    prange = (np.percentile(ps, 90)-np.percentile(ps, 10)) if len(ps) > 15 else np.nan
    pace = ((wt >= s0) & (wt < s0+WIN)).sum()/WIN*60
    rows.append((s0, loud, pitch, prange, pace))
R = np.array(rows)
def local_z(x, span=180):  # z vs +-90 s neighbourhood = each speaker vs their own baseline
    out = np.full_like(x, np.nan)
    for i in range(len(x)):
        w = x[max(0, i-span//2):i+span//2]; w = w[~np.isnan(w)]
        if len(w) > 10 and not np.isnan(x[i]): out[i] = (x[i]-np.median(w))/(np.std(w)+1e-6)
    return out
zl, zp, zr, zs = (local_z(R[:, k]) for k in (1, 2, 3, 4))
g = lambda z: np.nan_to_num(np.clip(z, -3, 3))
gl = (R[:, 1]-np.nanmedian(R[:, 1]))/np.nanstd(R[:, 1])
score = 0.40*g(zl) + 0.30*g(zp) + 0.15*g(zr) + 0.15*g(zs) + 0.25*g(gl)
# then: mask first/last 90 s, pick top-N with 30 s spacing, print transcript text in each window
```

Next improvements: per-sentence scoring instead of fixed 10 s windows; intro/outro mask; climax-boost per candidate; optional laughter detector (jrgillick, needs torch) once we decide it's worth the install.

## Sources

- [SamurAIGPT/AI-Youtube-Shorts-Generator](https://github.com/SamurAIGPT/AI-Youtube-Shorts-Generator) (`shorts_generator/highlights.py`)
- [paragbml/open-clip-studio](https://github.com/paragbml/open-clip-studio) (`server/services/viralityService.js`, `server/ml/acoustic_analyzer.py`)
- [GrepCut/OpenClipper](https://github.com/GrepCut/OpenClipper) (`src-tauri/src/mcp/ai_clips.rs`, `engine/transcript/word-boundaries.util.ts`)
- [Opus Clip: What is the Virality Score](https://help.opus.pro/docs/article/virality-score)
- [Rhapsody: A Dataset for Highlight Detection in Podcasts (arXiv 2505.19429)](https://arxiv.org/abs/2505.19429)
- [jrgillick/laughter-detection](https://github.com/jrgillick/laughter-detection)
- [Exploring audio-based stylistic variation in podcasts (Interspeech 2022)](https://www.isca-archive.org/interspeech_2022/martikainen22_interspeech.pdf)
