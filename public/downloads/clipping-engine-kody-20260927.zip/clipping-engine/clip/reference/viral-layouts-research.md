# Viral short-form layouts: spec catalog (research 2026-09-25)

These specs drive `scripts/clipkit/styles.py` and any new layout. The frame is 1080x1920 unless noted, with y measured from the top.

- **[spec]** marks a reproducible default I derived. The rest comes from sources: platform docs where possible, otherwise tool vendors (Opus Clip, Submagic, Captions) and agencies.
- Treat vendor numbers as practitioner consensus, not controlled studies.
- Re-confirm anything older than about 90 days before it drives a client pack.

## Cross-cutting facts

**Safe zones at 1080x1920**
- **House rule [spec]:**
  - Critical text lives in x 60–960, y 220–1400.
  - Captions sit in y 1100–1380.
  - Nothing important goes at y > 1420, in the right rail x > 960, or at y < 200.
- **Per platform:**
  - TikTok: top 108, bottom 320, right 120.
  - Reels: top 210, bottom 310, right 84.
  - Shorts: top 120, bottom 300, right 96.
  - LinkedIn: about 100 top and bottom.
  - Paid Reels: keep text at y ≤ 1248.

**Instagram grid.** It crops to 3:4 (1080x1440 center). Keep the cover headline and face inside y 240–1680.

**Lengths**
- Shorts up to 3 min; sweet spots around 13 s or around 60 s.
- Reels up to 3 min; 15–30 s for reach, 60–90 s for engagement.
- TikTok 60–180 s for substance; Creator Rewards needs 1 min+.
- Diary of a CEO clips run 65–140 s, with the payoff 55–80% of the way in.
- **Our defaults [spec]:** local business 20–45 s, podcast 45–90 s.

**LinkedIn**
- Use 4:5 (1080x1350).
- Mostly watched muted, so captions are mandatory.
- Vertical gets about 34% more engagement and dwell time than square (LinkedIn Creative Labs, secondary source).
- Median video length is about 51 s; 1–5 min videos get more likes.

**Captions and legibility**
- 69% of people watch with the sound off in public; 80% are more likely to finish a video with captions (Verizon, 2019).
- Body text at least 44 px at 1080 wide.
- For contrast: a 4 px stroke or an 80% opacity card.
- Pop captions 84–120 px caps; line captions 48–60 px.

**Hook and pacing**
- Put the value proposition in the first 3 s (TikTok: 63% of high-CTR ads do).
- Shorts analytics "viewed vs swiped": more than 70% swiped means the hook is broken.
- Change something visually every 3–6 s. DOAC cuts every 4–6 s, tighter near the payoff.

**Originality**
- Instagram and Meta demote accounts that mostly repost other people's content.
- Watermarks and credit lines don't count as transformation.
- Post from the client's own account, with real edits, and no other app's watermark.

**Encode.** 1080x1920, 30 fps, H.264 at 8–12 Mbps. A full-bleed crop from a 1080p 16:9 source upscales 1.78x, so prefer 4K sources.

## Caption treatments (clipkit `Captions`)

| ID | Treatment | Chunk | Look | Use |
| --- | --- | --- | --- | --- |
| pop | Single-word pop | 1–2 words, caps | Scales 70 → 112 → 100% over ~180 ms; accent color on keywords | Hype, coaches |
| karaoke | Active-word color | 2–4 words, 1–2 lines | Line appears whole, active word in the speaker's color | Default podcast |
| box | Active-word box | 3–6 words | Rounded brand box slides between words (80–120 ms) | Brand-first, clean |
| bar | Subtitle bar | 6–10 words, max 2 lines | 60–80% dark bar, sentence case, fade 150–250 ms | LinkedIn, serious topics |

Avoid the cheap tells: TheBoldFont with a neon stroke, emoji on every line, SFX on every word.

## The 15 layouts

For each: geometry, captions, motion, hook, and what separates the cheap version from the brand-first one.

1. **Full-bleed face + word-pop captions** (Hormozi / Submagic).
   - Face crop with eyes at y 620–760.
   - Captions at y 1180–1300.
   - Hook text for 0–3 s at y 260–520.
   - Zoom punches every 3–6 s; silence-cut jump cuts.
   - Brand-first: brand font, one accent color, a small logo bug.
2. **Active-speaker cuts + payoff banner** (Diary of a CEO clips).
   - Paper banner at y 250–430 for 0–5.5 s.
   - Karaoke captions at 60–70% height, a color per speaker.
   - Hard cuts every 4–6 s; reaction J-cuts; dry audio.
3. **Stacked two-speaker split.**
   - Two 1080x960 panes; captions boxed on the seam.
   - Active pane: brand border, other pane dimmed 25%.
   - Name chips; matched color grade.
4. **Letterboxed 16:9 + headline.**
   - Video 1080x608 at y around 656.
   - Headline at y 260–580, persistent.
   - Brand field or blurred background; rounded video card; progress bar.
   - Best for LinkedIn and low-res sources.
5. **Content on top, speaker below** (screenshare / reaction).
   - Content at y 0–1000, speaker below; seam captions.
   - Pan and zoom inside the content; highlight boxes.
6. **Text-post card over video.**
   - Card at x 60–960, y 220–700, radius 28; slides up over 0.4–0.6 s.
   - The post text is the hook (12–20 words).
   - Platform-neutral card, real client name and face. Never fake X or LinkedIn chrome or engagement counts.
7. **News / documentary explainer.**
   - Category chip, headline bar at y 290–470, lower third at y 1230–1370, citation chip.
   - The brand's own editorial system; no network look-alikes.
8. **B-roll / photo cutaway.**
   - A-roll with 1.5–4 s inserts every 5–10 s; Ken Burns 1.00 → 1.12.
   - Captions stay at the same y through every cut.
   - Use the client's own job footage, never generic stock.
9. **Listicle / numbered build.**
   - Title at y 230–420; list rows 100–120 px with a Ø72 number badge.
   - Items pop in on their spoken cue; earlier items dim to 45%.
   - An "n/5" counter.
10. **Green-screen creator over a visual.**
    - Cutout bottom-anchored at 50–60% height.
    - Background content at y 220–1000.
    - Needs per-frame masking (local: rembg, RVM, MediaPipe).
11. **Before / after.**
    - Stacked, a wipe (6 px divider with a brand handle, 1.2–2 s), or a sequential cut on the beat.
    - Matched framing; labels.
    - Med-spa claims caveat: check platform and advertising rules.
12. **Stat / number reveal.**
    - 260–400 px number, count-up 0.6–1.2 s with overshoot.
    - Frame dims about 60%; source line under it.
13. **Chat / notes UI.**
    - Bubbles in brand colors, typing indicator, then pop.
    - Clearly illustrative; never a fake real conversation.
14. **Street interview / mic flag.**
    - Persistent question card at y 230–420; answers cut every 2–5 s.
    - Name chips; a caption color per role.
15. **Minimal LinkedIn subtitle bar.**
    - 4:5 with a header bar at y 0–200 holding the thesis.
    - Speaker below; subtitle bar at y 1080–1240; progress bar.

**Modules.**
- Progress bar: 6–10 px under the top UI.
- Looping hook: the last line feeds back into the first frame; no end card.
- Hook card: 5–8 words.

**Hook archetypes:** contrarian claim, surprising number, redacted pull-forward, question card, "look at this" + visual, story cold open.

## Sources

PostPlanify safe zones 2026; KreateFlo; Behaviour Digital (Meta Reels ads); Boderia (IG 3:4 grid); PetaPixel (IG originality, Apr 2026); YouTube Help (Shorts); Fliki; Shortimize; TikTok Ads creative best practices; Bannerflow; Brandwatch; Magicpost; Teleprompter (LinkedIn stats); TechCrunch (LinkedIn vertical, Feb 2025); Forbes/Verizon (2019); Opus Clip help and blog; Submagic blog and API; Captions.ai styles; SendShort; Joyspace; WritePanda (DOAC edits); StartupSpells (Chris Williamson); Conbersa; Descript; PrePublish; Digital Zoom Studio; Overlaytext; Itnavideo; CapCut; Reelscraft; HeyGen HyperFrames; NoGood.
