# Brief: layout wireframe libraries (2 images)

We make branded vertical clips (9:16 Reels/TikTok/Shorts) from clients' long videos. Every clip right now uses the same layout, so a client's feed starts to look repetitive. We need a LIBRARY of layouts to rotate through: 8 clip layouts and 8 end-card layouts. Each one must still read as a proven viral short-form format, just with a different shape and composition.

These are WIREFRAMES, not branded designs: clean grayscale (white background panels, light and mid grays, thin dark outlines, simple sans-serif labels). Brand styling happens later, per client.

## Key colors (the only non-gray colors allowed, flat, crisp edges, no text inside)
- **Flat #00FF00 green** = live talking-head video goes here.
- **Flat #FF00FF magenta** = photo / stat card / checklist graphic goes here.
- **Flat #00FFFF cyan** = caption zone (word-by-word captions are drawn here, over whatever is behind it).
- Gray blocks = designed elements (hook headline, name bar, labels, stripes, icons). Put short placeholder words in them like "HOOK LINE 1 / HOOK LINE 2", "Name / Company", "LABEL".

## Rules for every panel
- 9:16 portrait panel.
- Bottom 12% of each panel: background only (app buttons sit there).
- Keep text and windows inside the central 84% of the width.
- Under each panel, a short label: number + layout name.
- Make the 8 layouts genuinely different in structure (window sizes, positions, overlaps, where the hook sits), not 8 near-duplicates.

## Image 1: 8 clip layouts, one sheet, 4 columns x 2 rows, landscape
1. **Classic stack.** Hook bar top; green video; cyan caption strip; magenta visual window; name bar.
2. **Full-bleed face.** Green fills almost the whole frame; hook as a floating card over the top of the green; cyan caption zone as a floating bar over the lower third of the green; small name chip.
3. **Letterboxed card + headline.** Big persistent headline block top third; green as a rounded 16:9 card in the middle; cyan captions under the card; small magenta chip/stat box below.
4. **Visual on top, speaker below.** Magenta large on top (about 45%); green below it; cyan caption strip on the seam between them; hook as a thin top banner.
5. **Text-post card.** Green fills the frame; a big gray "post card" with hook text overlaps the top 35% (card slightly rotated or offset); cyan captions low.
6. **Picture-in-picture cutaway.** Magenta fills most of the frame (the photo/B-roll is the star); green as a rounded inset (corner, about 40% width) with a ring; cyan captions across the lower middle; hook bar top.
7. **Listicle / numbered.** Green top half; below it a tall magenta panel for a numbered checklist; a gray "1/3" counter chip; cyan caption strip between.
8. **Stat reveal / split diagonal.** Green and magenta split by a diagonal seam (green upper-left, magenta lower-right); cyan caption bar crossing the seam; hook top-left.

Save as: /Users/aom-inhouse/aom-studio-transfer/AOM-EA/.claude/skills/clip/reference/wireframes/clip-layouts.png

## Image 2: 8 end-card layouts, one sheet, 4 columns x 2 rows, landscape
Each end card has: face slot(s) as flat #00FF00 circles or shapes, "Follow for more", show name, a link pill ("Full video: link in bio"), a logo placeholder circle, a tagline line. Optional flat #FF00FF area = background photo slot. Make all 8 different:
1. **Faces top, stacked text** (circle faces, centered column).
2. **Big hero face** (green fills the top 55% as a rectangle, text card below overlapping it).
3. **Split duo** (two tall green panels side by side for two hosts, text across the bottom).
4. **Photo background + card** (magenta fills the frame, a gray rounded card holds face circle + text).
5. **Follow CTA big** (huge "FOLLOW" type, small face circle, arrow pointing to where the follow button is on the right rail).
6. **Part 2 teaser** ("PART 2 →" style: next-topic headline, face circle, link pill).
7. **Minimal logo-first** (logo placeholder big in center, face circle small, one line + pill).
8. **Magazine cover** (green face fills frame like a cover, masthead show name across the top, cover lines on the side).

Save as: /Users/aom-inhouse/aom-studio-transfer/AOM-EA/.claude/skills/clip/reference/wireframes/end-card-layouts.png

Check before saving: all key colors perfectly flat and exact, labels spelled correctly, 8 distinct layouts per sheet. Do not edit other files, no git, no contact. Reply with the 2 saved paths.
