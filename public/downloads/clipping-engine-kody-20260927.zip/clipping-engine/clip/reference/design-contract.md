# Keep the design intact

## Reference and approval

Oak Street's fire, water, and TSMC samples are the approved craft benchmark. The realtor brand boards are useful reference artwork; their approximated renders were criticized. The last full-screen Kody experiment was proposed for review, not approved. These are different states.

For every prospect, keep an exact board/image path and a reference render. If the approved reference is missing, recover it from saved files or the conversation before guessing. “Use the brand colors” is not enough: preserve typography, sizes, relative positions, spacing, surfaces, and accents.

## Coherent kit

Use [design-standard.md](design-standard.md) as the cross-brand visual quality bar. Kody's generated main/ending pair is a candidate for art direction; it is not permission to copy its colors or monogram into another brand. Patrik's latest correction removes faint decorative underlines beneath captions.

One kit contains a hook treatment, caption treatment, speaker/name treatment, photo label, statistic/list treatment, and end card. Use only the components needed at each moment. A component board is a parts library, not an instruction to display every part at once.

Default to the successful reference's content hierarchy. A source whose strength is a live face can give that face more room; a story about a place or object can give the real imagery more room. Keep the brand family and prove this adaptation on actual footage before applying it to the batch. Avoid arbitrary layout rotation.

- Strong headline with intentional line breaks and at most one accent treatment.
- One main thing to read at a time. Captions may repeat speech; another quote panel should add context or take over emphasis, not duplicate every caption.
- Faces centered in their crops with headroom through the entire movement. Protect the whole head, not only eyes and mouth.
- A name/show bubble introduces the speaker early, stays readable for a few seconds, then leaves the picture clear. Use a gentle entrance and exit; reintroduce it only when the audience needs to identify a returning speaker.
- Text inside the platform's safe area. Quiet space for app controls is intentional; a large empty information panel is a defect.
- Use spare lower-panel space for a relevant image continuation or one useful visual beat. Put essential names and claims above the platform controls; decorative image may extend below them. Inspect at phone size so the fix does not become a crowded stack.
- Motion has a reason: introduce a fact, highlight a word, reveal a checklist item, or lead into the ending. Gentle background motion stays subordinate to content.
- End card starts while speech continues and retains the agreed photo or contour background, real names, show identity, and accurate CTA.

## Geometry before rendering

For a Figma-based layout, keep the Figma frame/node ID and a measured geometry revision with the brand proof. Compare the rendered zones and layer order with that frame. If the proof exposes a structural overlap, fix the editable Figma wireframe and remeasure before changing render code. Generated brand assets can change color, texture, and illustration within a role; they do not move captions, names, or footage regions by accident. Test Instagram/TikTok overlays separately because platform controls are outside the Figma frame.

Design for the final canvas. A 1024×1536 image is 2:3, not 9:16. Never stretch it or let a default cover-fit silently crop headline edges and brand elements. Generate at 9:16 or explicitly select a 9:16 crop after inspecting the artwork; store it in `template_crop` or `end_template_crop` as `[left, top, right, bottom]` in source pixels. The renderer checks the crop's aspect ratio. A crop is acceptable only when it preserves the intended art and all essential text.

For legacy chroma plates: green is live video, magenta supporting visuals, cyan captions. Check real pixels and mask edges after generation. A syntactically valid key is not evidence of a good layout. Use a consistent keyed region shape within a series. Do not fill leftover plate space with unplanned bars or decorative noise.

Code-rendered text is useful for changing captions, numbers, and animated lists. Match it against the board at actual size, including font weight, tracking, contrast, background shape and number style. If it looks like a weak approximation, repair or reuse the designed component itself. Do not quietly substitute a generic font.

## Design lock

Save `design-lock.json` beside `brand.json` with:

- `status`: draft or approved;
- `references`: exact paths and SHA-256 hashes of the selected board and applied proof;
- `approval`: null while draft; actual user statement, date, and conversation reference once approved;
- `canvas`: width and height;
- `family`: selected composition and where its components live;
- `figma`: frame URL/node ID and measured geometry revision when the family uses a Figma wireframe;
- `type`, `palette`, `captions`, `motion`, `end_card`;
- `allowed_variation`: footage, copy, facts, relevant photos, and supported visual beats within the selected family.

Changing the family means another look proof. Fixing spacing or implementing already requested corrections does not require another approval cycle. New episodes reuse the lock.
