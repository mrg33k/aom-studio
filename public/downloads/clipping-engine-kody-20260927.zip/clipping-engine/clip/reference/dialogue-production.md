# Dialogue production

1. **Source.** Inspect the full episode or transcript before choosing moments. Record the URL, actual resolution, and source time origin. Prefer client originals when available. For YouTube, `/opt/homebrew/bin/yt-dlp` is installed; after selection, `--download-sections "*START-END" --force-keyframes-at-cuts` can save bandwidth. The `youtube:player_client=tv_simple` extractor worked for 720p in the Oak Street round; verify it still works rather than assuming. Keep the original section start time with each cut.
2. **Transcribe.** `mlx_whisper <wav> --model mlx-community/whisper-large-v3-turbo --word-timestamps True --condition-on-previous-text False --output-format json`. ~80s for a 30-min episode. ALWAYS pass `--condition-on-previous-text False`: without it Whisper can loop one phrase over minutes of real speech.
3. **Find moments** (full research: `moment-ranking-research.md`).
   - Run `scripts/audio_peaks.py` (loudness, pitch, pace vs each speaker's baseline; mask first/last ~90s of intro/outro). Audio peaks are HINTS for where a story climaxes, never a reason to drop a calm stat moment.
   - Read the numbered-sentence transcript with the peaks alongside. Return 10-15 candidates as sentence ranges, each with hook line, type, reason.
   - Score 1-5 on hook, emotion (60% words / 40% audio), makes-sense-alone, value. Total = .35 hook + .25 emotion + .25 alone + .15 value. Drop anything scoring 2 or less on makes-sense-alone.
   - Stories can be stitched climax-first. Short facts 20-45s, stories 45-90s.
   - Skip: investment offers with returns (securities-advertising risk), speculation blaming people, "look at my screen" moments that need the visual.
4. **Radio edit, no cut-off words** (full audit: `boundary-audit-oak-fire.md`). Whisper times alone clipped 8 of 26 edges on the first sample.
   - Whisper is for text only. Word timing comes from forced alignment (`scripts/align_words.py`, WhisperX/torchaudio align). Spell out numbers before aligning. Add ~80 ms to aligned word ends.
   - Search the gap between words (prev end + 40 ms to next start - 20 ms, within ±300 ms of the planned cut) and snap to the quietest point.
   - Real pause: OUT 60-80 ms into it, IN 40-60 ms before the next word. No pause: cut at the deepest dip only if it's 8-10 dB below the speech around it; otherwise widen to the nearest real pause (keep the "Well," / "and then") or flag it.
   - Reject any cut more than ~25 dB above background or within 20 ms of a word start. Whisper hides "uh"s, so a gap in its word list isn't proof of silence.
   - Fades 20-30 ms at pauses, 10 ms crossfade inside continuous speech. Keep 80-150 ms of room sound when shortening pauses.
   - Workflow: write a plan (Whisper start of first word / end of last word per piece, plus speaker) → `scripts/snapcut.py` → `scripts/check_cuts.py` (stitches + re-transcribes + diffs). Overlapping talk (two people at once) has no clean cut; pick a different line.
   - `scripts/audit_boundaries.py` checks every edge. Always re-transcribe the final audio and diff it against the intended text.
   - Tag each segment's speaker.

## Rendering and inspection

1. **Render.** PIL frame-by-frame → ffmpeg (use `/usr/bin/python3`, it has numpy + Pillow). Audio: extract segments with `atrim` in the filter (never `-ss` output-seek + `afade`: the fade fires at the wrong time and mutes speech). Pad speech to full duration so the end card isn't cut. Loudness target ~ -14 LUFS.
2. **Verify (every render).**
   - Re-transcribe the render; the text must match the planned lines, first and last words whole.
   - Contact sheet across the whole clip + frames mid-animation at every speaker switch.
   - Check: no text off-frame, nothing covering a face, captions clear of tags/bubbles, end card fully visible.


Use the interpreter and tools actually installed. Prefer a full downloaded source with a recorded time origin; partial downloads must record their original start time. A successful transcript check does not detect frozen lips, poor framing, or a bad transition. Watch and listen to the rendered output. Do not patch a talking face with a held frame. Cover a damaged source transition with relevant real B-roll while preserving complete speech, or choose a clean boundary.
