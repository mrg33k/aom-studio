# Boundary audit: fire-sample-branded.mp4 (2026-09-25)

Source: `/tmp/clip-test/hq2.mp4`, segments from `wow3.py` SEGS. Audio measured at 48 kHz mono, RMS in 10 ms windows, lightly smoothed (30 ms). "dB" below = dB above the local noise floor (5th percentile of a +/-10 s window, about -63 to -74 dBFS). Speech peaks sit around +45 to +60; a real pause is under about +15.

Word boundaries were cross-checked two ways: the existing Whisper words (`hq2.json`) and a wav2vec2 forced alignment (torchaudio `WAV2VEC2_ASR_BASE_960H`, which is WhisperX's English model), saved in `aligned.json`. Scripts: `audit.py`, `audit3.py`, `align.py`, `bchk/build.py`.

## Headline

- **8 of 26 boundaries cut into a word.** Seg0 IN, seg3 IN, seg3 OUT, seg5 IN, seg6 IN, seg7 IN, seg8 OUT, seg9 IN.
- **1 more starts on a filler Whisper never transcribed.** Seg2 IN starts on the tail of an "uh" at 46.34-46.97. Whisper leaves fillers out, so a gap in its word list is not always silence.
- **6 minor ones.** These cut a decaying tail or the middle of a breath, or land 20-30 ms into a neighboring word.
- **Proof it's audible.** I rebuilt the joined audio (same atrim and fades) and re-transcribed it. The current cut is heard as "**We,** our investors...", "**And** we had a really good team", and "because we got..." (the start of "Well" is gone). With the fixes it reads "Our investors...", "And then we had...", "Well, because...", "ultimately, we got a brand new building".
- **Net length change:** 31.40 s becomes 31.66 s.

## Table

| Seg | Boundary | Now (s) | dB at cut | Verdict | Suggested (s) | dB after | Note |
|---|---|---|---|---|---|---|---|
| 0 | IN | 139.36 | +52 | **CLIPS**: starts mid "we" (stutter "we got we our") | **139.48** | +34 | dip between "we" and "our", 20 dB down; starts "our investors" |
| 0 | OUT | 142.84 | +11 | OK: in a 50 ms pause after "fire" | 142.83 | +11 | next speaker starts at 142.87, so the margin is tight |
| 1 | IN | 9.06 | -1 | OK: room tone; "This" starts at 9.26 | 9.18 (optional) | +2 | trims dead air |
| 1 | OUT | 12.24 | +19 | MINOR: cuts the fading tail of "twenty-three" | **12.30** | +2 | silence; "in" starts at 12.37 |
| 2 | IN | 46.80 | +38 | **FLAG**: starts on the fading end of an untranscribed "uh" | **47.07** | +1 | "nobody" starts at 47.14 |
| 2 | OUT | 47.98 | +8 | OK | 48.02 | +3 | more room for the "hurt" tail |
| 3 | IN | 48.12 | +41 | **CLIPS**: 30 ms after the next word starts (48.09); first consonant lost | **48.06** | -1 | or merge seg2 and seg3: the 140 ms removed is nearly all silence |
| 3 | OUT | 48.80 | +45 | **CLIPS**: cuts off the "-ly" of "thankfully" (ends about 48.86) | **48.86** | +37 | runs straight into "well" with no pause; this dip is the best spot, listen to confirm |
| 4 | IN | 158.14 | +14 | OK: faint end of a breath/murmur, then silence | 158.22 | -5 | clean room tone, 60 ms before "So" |
| 4 | OUT | 159.60 | +3 | OK | keep | | |
| 5 | IN | 160.36 | +47 | **CLIPS**: starts on the tail of "well" | **160.15** (keeps "Well,") | +26 | alternative is 160.44 (drops "well"), but that dip is shallow and risky |
| 5 | OUT | 163.84 | +11 | OK/minor: "it" still fading | 163.90 | +2 | "for" does not start until 164.2 |
| 6 | IN | 165.04 | +48 | **CLIPS**: mid first "got" of "we got we got" | **165.14** | +36 | dip between "got" and "we"; starts "we got our lost revenue" |
| 6 | OUT | 168.29 | +36 | MINOR: 20-30 ms into the start of "In" | 168.25 | +29 | "rent" and "In" run together with no pause |
| 7 | IN | 175.84 | +50 | **CLIPS**: mid "then" in unbroken speech | **175.56** ("and then we had") | +19 | the only real dip nearby; the "then/we" boundary at 175.91 has no dip |
| 7 | OUT | 179.79 | +8 | OK: pause | keep | | |
| 8 | IN | 132.54 | +40 | OK/borderline: at the dip between "that" and "And" | 132.52 | +38 | |
| 8 | OUT | 133.36 | +54 | **CLIPS**: mid "ultimately" (runs to about 133.50) | **133.62** | +21 | |
| 9 | IN | 134.62 | +57 | **CLIPS**: mid a drawn-out "we" (starts at 134.35) | **134.30** | +6 | seg8/9 join now sounds like "ultimate-ee got" |
| 9 | OUT | 137.00 | +14 | OK | 137.08 | +5 | full fade-out of the tail |
| 10 | IN | 144.00 | +23 | MINOR: starts 60 ms into a breath. Whisper stretched "It" over the breath; the real "It" starts at 144.46 | **144.39** (skip breath) | +8 | or 143.92 to keep the whole breath |
| 10 | OUT | 146.28 | +3 | OK | keep | | |
| 11 | IN | 155.22 | +50 | MINOR: about 30 ms of the end of "do" before "I" | 155.25 | +47 | continuous voicing, shallow dip |
| 11 | OUT | 157.62 | +12 | OK: short pause; next sound at 157.69 | keep | | |
| 12 | IN | 197.80 | +50 | MINOR/borderline: "yeah" slides into "you" | 197.83 | +47 | bottom of the dip |
| 12 | OUT | 200.66 | -5 | OK | keep | | |

Corrected SEGS (verified by re-transcription):

```
[(139.48,142.83),(9.18,12.30),(47.07,48.02),(48.06,48.86),(158.22,159.60),(160.15,163.90),
 (165.14,168.25),(175.56,179.79),(132.52,133.62),(134.30,137.08),(144.39,146.28),(155.25,157.62),(197.83,200.66)]
```

Caption side effect: wow3.py only puts a word in the captions if it sits fully inside a segment (`a <= start and end <= b+0.05`). So the drawn-out "we" (Whisper 133.60-134.90) is missing from the captions today. Seg5 and seg7 now start earlier, so "Well," and "and then" will show up in the captions. Map caption words from the aligned times, not the raw Whisper times.

## Why the current rule fails

"First word start - 0.12 s, clamped to the previous word's end" trusts Whisper word edges, and in this clip they were wrong by 60-300 ms. Examples: "It" stretched over a breath (144.12 vs the real 144.46), and "yeah"/"you" and "got"/"we" edges off by 60-100 ms. The clamp to the neighbor word does not help, because the neighbor's edge is wrong too. Whisper also drops fillers ("uh"), so a gap in the word list can still contain sound. Most failures here are internal stutter-removal cuts inside unbroken speech, where no pause exists and the only safe point is an energy dip found from the audio.

## Research: how to guarantee no word gets cut

- **Forced alignment beats Whisper timestamps.** WhisperX runs Whisper for the text, then aligns it to the audio with a wav2vec2 phoneme model. Its known gaps: numbers and symbols ("2023") can't be aligned unless you spell them out, and overlapping speech is weak. stable-ts improves Whisper timestamps with silence suppression (Silero VAD or loudness) and a `refine()` pass that mutes audio to find the latest start and earliest end that still hold. Montreal Forced Aligner is the most accurate at the phone level, but it is heavy (conda, Kaldi) and too much for this pipeline. torchaudio's `forced_align` with `WAV2VEC2_ASR_BASE_960H` already runs on this Mac: `/usr/bin/python3` has torch 2.8 (the function is deprecated there and is removed in torchaudio 2.9, so pin it or use WhisperX's copy). Note that CTC alignment catches word starts well but ends early, because it marks the peak rather than the fade.
- **VAD (Silero, webrtcvad)** finds speech vs. pause regions. It is good for "is there a real pause here", but at 30 ms frames with hangover it is too coarse to place a cut between words.
- **Energy snapping** is what editors and auto-editor effectively do. auto-editor cuts where loudness drops and keeps a default 0.2 s margin around loud parts. That works for pauses but can't tell words apart inside unbroken speech.
- **Open-source clippers** (AI-Youtube-Shorts-Generator, autocut-style tools) mostly take Whisper segment or word times as-is, sometimes with fixed padding, and do no boundary refinement. This is exactly the failure seen here.
- **How pro editors do it:** cut in the breath or pause, never mid-vowel. Put an outgoing cut after the word's tail has decayed (plosives and reverb tails run 50-150 ms past the "end"). Put an incoming cut just before the first consonant, 30-80 ms of pre-roll. Keep or remove breaths deliberately, not by accident. Fill the gaps with room tone so the background doesn't drop to digital silence. Use short crossfades, around 5-20 ms, to kill clicks; longer fades over speech are themselves audible.
- **Zero-crossing** only prevents clicks. A 10-20 ms fade does the same job, so it isn't needed on top.

## Recommended recipe (Mac, Python + ffmpeg)

1. **Get text from Whisper as now, then get timing from a forced alignment.** Spell out numbers before aligning; the WhisperX align step or the torchaudio snippet in `align.py` both work. Treat word starts as reliable. Treat word ends as a lower bound and add about 80 ms.
2. **Pick the cut region in word space, then snap in the audio.**
   - Search window for an OUT: from the aligned end of the last kept word + 40 ms to the aligned start of the next word - 20 ms, and never more than +/-300 ms from the planned cut.
   - Search window for an IN: from the end of the previous word + 40 ms to the start of the first kept word - 20 ms.
3. **Snap using 10 ms RMS against a local noise floor** (5th percentile over +/-10 s).
   - If the window holds a pause (at least 30 ms below floor+15 dB): put an OUT 60-80 ms into the pause, or at its middle if the pause is short. Put an IN 40-60 ms before the next onset, or at the middle.
   - If there is no pause (unbroken speech or a stutter): cut at the deepest energy dip in the window. If that dip is not at least 8-10 dB below the speech on both sides, flag the boundary for a human listen, or widen the cut to the nearest real pause (for example, keep the "and then" or the "Well,").
4. **Run a guard check after snapping.** Reject any cut above about floor+25 dB, or within 20 ms of a rising edge (a fast energy rise marks a word starting). Also run Silero VAD over the region so an untranscribed "uh" or breath is treated as sound, not silence.
5. **Fades:** 10-15 ms fade-in, 20-30 ms fade-out (the current values are fine). For internal joins inside continuous speech, use a 10 ms `acrossfade` instead of hard fades so the join doesn't pump.
6. **Room tone:** when you shorten a pause, don't let it drop to true silence. Keep 80-150 ms of the real pause, or lay a quiet room-tone bed under the whole clip.
7. **Verify automatically:** rebuild the audio, re-transcribe it, and compare the text to the intended text. An extra or partial word ("We, our...") or a missing word ("...ly") means a bad boundary. This caught every flagged join here.
