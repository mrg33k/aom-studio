Attach: podcast-cover.png, logo-stacked.png, current-clip-frame.jpg

---

I'm building a branded look for short vertical social clips (9:16, Reels/TikTok/Shorts) cut from a business podcast. Design a brand kit sheet I can hand to an editor so every clip for this client looks the same and clearly belongs to them.

Client: Oak Street Assets / Phoenix Prosperity Podcast, hosted by Tim Fergestad. Phoenix real estate investor. Multifamily and build-to-rent deals, passive investors. Tagline: "Steady Growth. Strong Returns." Tone: trustworthy, grounded, confident, a little warm. Not flashy, not crypto-bro, not hype.

Brand facts (use these exactly):
- Deep forest green #213F25
- Mid green #306D41
- Lime accent #79B228 (use sparingly, it's the "pop")
- Sage #99AEA0
- Near-black green #1B291F
- Warm cream / tan from the podcast cover
- Body font: Nunito Sans. Headline font: the slab serif on the podcast cover.
- Logo: the oak tree. Tree icon alone works as a small mark.

The third image is the current clip layout: hook title up top, the story photo in the top half, the "after" photo in the bottom half, a small round face-cam bubble, big word-by-word captions on the seam. Keep that structure. Restyle it into his brand.

Put these on one sheet, laid out as labeled components:
1. Hook title bar (top of frame, 2 lines max)
2. Caption style, showing one normal word and the active word highlighted
3. Photo label tag (e.g. "2023: THE FIRE" / "NOW: BRAND NEW")
4. Big stat card (e.g. "$1,000,000" counter moment)
5. Face-cam bubble ring
6. Name lower third ("Tim Fergestad, Oak Street Assets")
7. End card: "Follow for more" with the podcast name
8. One full 9:16 example frame using all of the above
9. Color and type rules in a small legend

Must NOT look like: generic MrBeast/Hormozi yellow-box captions, neon gradients, glossy 3D text, stock "finance bro" gold and black, or a Canva template. It should feel like his podcast cover grew into a video system.

Leave the logo and any real photos as simple placeholders. I'll drop the real ones in afterward.
