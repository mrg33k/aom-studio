# Prospect to sample pack

## 1. Intake and resume

Input: prospect or brand plus one or more video URLs, local files, a folder, or a playlist. Infer the show and brand from the sources, channels, linked sites, and existing project files. Ask only when the person/source is genuinely ambiguous or unavailable. Do not ask Patrik to choose moments, copy prompts, download assets, or operate the normal production steps. Read [run-modes.md](run-modes.md): demo is the 3–4 video default; full pass covers every viable non-duplicate story.

Attach the run to a mission. Reuse the prospect folder when it exists. Write `job.json` containing prospect, all source URLs/paths and time origins, mode, requested and selected clip counts, mission, brand folder, selected output formats, stage, and relative artifact paths. Keep old versions; write the new revision separately. Suggested stages: intake, opportunity-review, editing, look-review, rendering, final-review, complete, blocked. Record a concrete blocker and continue independent work.

Read `brand-kits/<slug>/design-lock.json` when present. Reuse its approved look and references for repeat work. Existing `brand.json` is render configuration; its presence alone does not mean approval. A new brand gets a draft design lock after the agent prepares the look. Record who approved what and when only after actual user feedback.

## 2. Select complete stories

Download or locate every source, inspect each at several points, and record its actual quality, speech, speakers, burned graphics, and time origin. Prefer client originals and the best accessible source. Do not label an upscaled 720p crop as native 1080p.

Read and listen across the complete source set. Use the dialogue-production procedure to inventory and rank all viable, distinct, executable moments before choosing the requested run size. Each needs a hook, enough context to follow it, and a payoff. Save `opportunities.json` and a readable `opportunities.md` with source ranges, intended transcript, visual idea, rank, cut feasibility, and factual or rights caveats. The demo shortlist is the best 3–4 varied moments; a full pass selects every viable non-duplicate moment. Keep numbers and meaning faithful to the speaker. If fewer good stories exist, deliver the strongest count and explain the shortfall rather than padding.

Create cuts and word alignment. Inspect original frames around every boundary. Prefer a clean alternate sentence or meaningful B-roll to a visibly frozen face. Verify final speech rather than trusting timestamps alone.

### Picture research for each beat

Write a short visual map before rendering: spoken line/time, the exact thing a picture should show, candidate image, source page, license, credit, and the planned screen label. Search the client's own usable media first, then free online sources with `scripts/find_images.py`, Wikimedia Commons, or another source whose license can be checked. Open the candidate and license page yourself; search ranking and an image filename are not proof of relevance or permission. Favor the actual place or action, not a generic scenic substitute. Do not reuse one photo under distinct claims merely to fill slots. If a beat lacks a truthful image, use a sourced stat, map, or designed text treatment. Never imply a stock or nearby-property image depicts the prospect's listing or exact venue. Keep credits on-screen when required and preserve the creator, license, and source URL in `credits.json`.

## 3. Establish the look once

Read `design-contract.md`. Gather 2–3 real brand references and identity assets. Inspect the existing GPT board before generating anything. If a usable board exists, refine and apply it; do not make a new brand from guessed colors.

Agent produces the kit and one representative proof: opening, normal caption, most demanding stat/list, and end-card frame, plus a short moving preview. Use real footage and final-length copy. Present the reference beside the actual output so differences in type, spacing, crop, and weight are visible.

Read `layout-library.md`. Choose a main structure and compatible ending that fit the footage and message. For a Figma-based variant, read the current frame and save its node ID, measured canvas boxes, crop, and layer order as a versioned geometry contract. Give ChatGPT image generation those separate roles and the prospect's actual identity references so it can create distinctive asset treatments without baking in captions, names, logos, or URLs that must stay accurate and editable. Save the Figma node, geometry revision, asset prompts/sources, and applied proof. If the rendered structure overlaps, change and remeasure the Figma master; do not hide a layout fix in prospect-specific offsets. Do not treat a new combination as approved because it passed a renderer check.

For a new brand or a changed visual family, label the proof and pack “draft look” until Patrik approves the design. Check the representative proof against the brand, Figma geometry, and platform controls before applying it across the requested demo or full pass, then keep working without a routine approval stop. Do not record an approved look or reuse it as approved for later jobs until Patrik actually accepts it. With prior approval for this exact look, reuse the saved lock directly.

Once approved, save the reference paths/hashes, palette, fonts, normalized layout zones, caption treatment, motion, end card, and dated approval evidence in `design-lock.json`. Update that file only when the user changes the look. A Claude/Codex proposal is not user evidence.

## 4. Build the pack

Default prospect pack, unless the request gives a different scope:

- A 9:16 video for each selected viable story: normally 3–4 for a demo, or every viable non-duplicate story for a full pass. Each has aligned captions, useful source-backed visual beats, and a coherent ending.
- One matching cover and posting caption/CTA for each video, with short readable copy and a useful real frame.
- Source links, photo credits, editable plans, the complete opportunity list, and a source-to-output inventory.

Keep these in the same brand family. Carousels, quote/stat cards, a montage, story set, or different aspect ratio are additional formats when requested or clearly appropriate; never invent claims to fill them. Do not silently grow a demo into an ongoing content calendar. Drafting copy is not permission to send or publish it.

## 5. Verify and package

Record checks in `qa.md`, with output paths and evidence:

- Planned versus built beats, target versus actual duration, dimensions, audio presence, and source resolution.
- First/last words and every join listened to; rendered transcript compared with intended lines.
- Captions timed correctly; no missing speaker, cropped head, covered face, duplicate title, clipped type, visible chroma color, or frozen lips.
- A name/show bubble appears during the introduction, remains readable, and is gone by ordinary speech. Any lower visual area carries a relevant beat without burying essential text under app controls. Confirm every external photo is distinct where the story changes, visually relevant, licensed for reuse, and properly credited.
- Inspect opening, ordinary speech, every visual change, number/list growth, every speaker change, start/middle/end of the end transition, and final frame. A sparse contact sheet alone is insufficient.
- Show the current output beside the approved reference at phone size. Compare layout proportions, type weight/line breaks, color, component shapes, face framing, and information density. Fix a mismatch rather than explaining it away.
- `render_clip.py` exits 2 on registered clashes or a plate with an unplanned aspect change. A zero exit covers only registered geometry; baked text and visual taste still need inspection.
- Record licenses/credits for external assets, and confirm that CTA wording matches the intended destination. Do not imply a link was installed in a prospect's bio.

Build `review.html` with the complete opportunity list, selected run scope, playable clips, covers, reference-versus-output, and visible review status. Link `job.json`, `qa.md`, and copy. The pack is complete when every selected video and requested companion artifact exists and is inspected; a script finishing or a plan being written is not a finished pack. For look-review runs, explicitly name the remaining batch and user decision.

## Reusable job record

Use this shape with actual values, not unfilled placeholders:

```json
{
  "prospect": "Kody Romero",
  "mission": "outreach:clipping-viability",
  "sources": [{"url": "https://www.youtube.com/watch?v=eONd3noAtU8", "file": "src/heat.mp4", "start_seconds": 84}],
  "mode": "demo",
  "requested_count": 4,
  "selected_count": 3,
  "stage": "rendering",
  "brand": "brand.json",
  "design_lock": "design-lock.json",
  "selected_opportunities": ["heat", "affordability", "summer"],
  "artifacts": {"opportunities": "opportunities.json", "review": "review.html", "qa": "qa.md", "plans": ["clip-heat.json"]},
  "remaining": ["Render and inspect the selected demo", "Review the draft brand look"]
}
```
