# One shoot, many posts: format recipes, the post menu, and MAYA

## Operating principle (Patrik, 2026-09-25)

**The web decides the format. The footage decides the story. GPT decides the look only when we're unsure. We do the matching.**

1. **Formats are a known list.** We don't invent them. This file, `viral-layouts-research.md` and `formats-saves-shares-and-emotion.md` are the library. Refresh it on a schedule, not per job. Re-confirm any recipe older than about 90 days.
2. **Our edge is reading the footage.** Find the emotional peaks and the real story opportunities: problem, tension, payoff, people, place, parts, numbers, proof. It takes intelligence, not just loudness detection.
3. **Connect the dots.** Every story beat is matched to the formats it can feed.
4. **GPT only as a reference.** If we catch ourselves inventing what should look good, we get a GPT reference (`gpt-image-generation.md`), then match it in code (`type-style.md`) to keep control and keep moving.

Every GPT reference joins the client's kit for good, so GPT calls per client should trend to zero.

**Agent line:** the agent ships Moments, carousels, cards and montages. Patrik hand-edits the main story reel.

## MAYA: most advanced, yet acceptable

A post ships only if it passes every check.

| Check | Advanced | Acceptable |
| --- | --- | --- |
| Format | One the niche rarely does well (video carousel, loop, POV) | One the platform already rewards; no gimmicks |
| Hook | Surprising first frame or line | Understood in under 2 s without context |
| Look | Motion text, graded footage, the client's GPT series style | Same series every time; recognizable at a glance |
| Idea | One sharp idea | Never two ideas fighting |
| Footage | Best 4–8 s of action, tight | Clean source only, never pre-captioned |
| Claims | Real numbers and specifics | Nothing the client hasn't confirmed |
| Mix | Saves, shares, comments and trust across the week | Not five of one format in a row |

For trades clients (Ambition), "acceptable" also means the tough, legit crew tone. No memes that undercut trust.

## Formats built around what agents do well

Agents can't make story edits the way Patrik does yet. They can pick a moment, grade it, frame it and annotate it. These formats need only those four skills.

| Format | What it is | Why it keeps people |
| --- | --- | --- |
| **Moments** | One continuous 3–5 s shot, graded, slow push-in, no cuts, loops. The building block for everything below. | Beautiful and short, so people rewatch |
| **Moment montage** | 4–6 Moments hard-cut on the beat of a track, headline in the client's type | Rhythm does the editing; no story decisions |
| **Postcard carousel** | Each slide is a Moment or graded still in a postcard frame: border, location stamp ("FASHION SQUARE · SCOTTSDALE"), date, short note | Series identity; reads like a job journal |
| **Learning carousel** | Each slide teaches one point, and the image does the teaching: circles and arrows on the actual part, magnified insets, labels, split before/after | You read the picture, not a paragraph |
| **Zoom-in carousel** | Same 4K frame on every slide, closer each time, ending on the detail | Every swipe gets closer |
| **Panorama carousel** | One wide image across 3–5 slides, each seam cutting mid-object | The seam is the hook |
| **Spot the problem** | Slide 1 asks, slide 2 circles the answer | Comments, then saves |

**What keeps people swiping** in every carousel:
- Slide 1 promises what the last slide pays off.
- Something runs across the slide edge (a line, an arrow, the panorama).
- A progress mark ("2/6").
- One idea per slide.
- The last slide works as a screenshot.

**Platform notes**
- Instagram carousels can mix video slides with images (up to 20). LinkedIn organic posts can't, so ship there as one stitched 4:5 video or a PDF document.
- TikTok photo mode takes images only.

## Full recipe list

| Format | Needs from the shoot | Drives |
| --- | --- | --- |
| Main story reel | Whole job + narration | Reach, trust (Patrik edits) |
| Video carousel "How we fixed it" | 5–8 sequential step shots | Saves |
| Before / during / after carousel | Problem, work and result shots in matching framing | Shares, saves |
| POV clip, 7–15 s | Hands-on footage; text-only hook | Shares |
| Satisfying loop, 4–8 s | Continuous motion (fan spin-up, wire nut, crane set) | Replays |
| "What's this part?" | One clear part close-up | Comments |
| Tip / quote card | One strong spoken line or fact | Saves |
| Listicle video | 3–5 shots that each prove a point | Saves |
| Photo dump carousel | 8–10 stills (RAW photos or 4K frame grabs) | Profile visits |
| Project spotlight (LinkedIn, 4:5) | Location, scope, result | B2B trust |
| Crew / culture | People + names (with consent) | Hiring, trust |
| Story set with poll | 3 strong frames | DM replies |
| Cover / thumbnail set | Best frames | Click-through |

## Shoot → menu workflow

1. **Index the shoot.** Tag every raw clip: action, people, place, parts, and the best 4–8 s Moment. Transcribe anything said. For Ambition, the social-clips mission's Gemini shot-scoring pipeline already exists; reuse it.
2. **Story map** (one page, saved per shoot): problem, fix, result, people, place, parts, numbers, quotes, emotional peaks. It also gets reused for captions, blog posts, Google Business updates and ads.
3. **Match recipes.** Only formats the footage has ingredients for make the menu.
4. **Draft the menu.** 10–14 posts, each with its clips, first-frame hook, metric and platform, balanced across metrics.
5. **Patrik picks.** Cross out, reorder, rewrite hooks.
6. **Build.** One GPT bulk template grid for the picked formats, then code keys the clips into the windows, sets the text in the client's `type_style`, animates, exports and verifies.

## Worked example: Élephante (Ambition, shot 2026-09-01)

**Story:** a fine-dining restaurant's rooftop unit burned out mid-service. The crew bypassed it, kept the dining room cold, swapped the fan motor control board and the compressor control board, and fired it back up. Location: Fashion Square, Scottsdale.

**Draft menu**
1. Main edit (Patrik).
2. Video carousel: 6 steps.
3. POV "dinner rush, AC down".
4. Fan spin-up loop.
5. "What's this board?"
6. Tip card: "Every mistake costs thousands" (the tech's line).
7. Burned vs new carousel.
8. "3 signs your rooftop unit is about to fail".
9. Postcard / photo dump "A day at Fashion Square".
10. LinkedIn case study (confirm the "no downtime for guests" claim first).
11. Story poll "Close or keep serving?"
12. Meet the tech (name + consent needed).
13. Covers.

**First test:** 20 Moments + one postcard carousel + one learning carousel ("What burned out on this rooftop unit").

**Raw footage:** `/Volumes/SS8TB/Ambition Mechanical Services/20260901 Elephante/`
- `Ronin4D/`: 53 clips, about 100 GB, possibly ProRes RAW.
- `S5iiX/`: 18 MOV clips + 64 RW2 stills.
