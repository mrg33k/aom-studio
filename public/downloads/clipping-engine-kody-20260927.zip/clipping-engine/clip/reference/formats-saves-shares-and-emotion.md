# What each format drives, and how to read emotion in footage (research 2026-09-25)

## Platform signals

- **Instagram.** Mosseri names the top signals as watch time, likes per reach and **sends per reach**. Sends matter most for reach beyond followers.
  - Trial Reels test a post with non-followers first.
  - Recycled, watermarked or unoriginal content is demoted.
- **Facebook.** The July 2025 crackdown cuts reach for accounts that repost others' content. Original content roughly doubled views in H2 2025.
- **TikTok.** Official factors: interactions (shares, favorites/saves, completion), video info, device.
  - TikTok also reads spoken words and on-screen text for search, so say the keyword aloud and put it on screen.
- **YouTube Shorts.** Since Mar 31 2025 every play counts as a view; "engaged views" still drive monetization. Use "viewed vs swiped away" to judge the hook.
- **LinkedIn.**
  - Dwell time is a ranking signal (LinkedIn engineering).
  - Third-party claims, directional only: comments weigh most, saves count about 5x a like, link posts get about 60% less reach.

## Benchmarks

**Instagram (Socialinsider, 2025–2026)**

| | Carousel | Reel | Single image |
| --- | --- | --- | --- |
| Engagement rate by reach | 0.55% | 0.52% | 0.37% |
| Median saves | **37** | 35 | 10 |
| Median shares | 3 | **5** | 1 |
| Median comments | 25 | **33** | 20 |

In short: **Reels drive comments and shares; carousels drive saves.**
- Metricool 2026: carousels get about 9x the saves of single images.
- Stories: reach peaks at 6–13 frames; 24% of viewers exit on frame 1.

**LinkedIn engagement rate by format**

| Format | Socialinsider | Buffer (Mar 2026) |
| --- | --- | --- |
| Documents / carousels | 7.0% | 21.8% |
| Video | 6.0% | 7.35% |
| Image | 5.3% | – |
| Text | 4.5% | – |

**Other platforms (Buffer 2026)**
- TikTok: video 3.39%, photo carousels 1.92%.
- X: text posts perform best.

## Which format drives which metric

| Format | Main driver |
| --- | --- |
| Carousel / LinkedIn document, cheat sheet, checklist, stat card | **Saves** |
| Tutorial clip | Saves + completion |
| Relatable, "tag someone", meme, before/after | **Sends** |
| Hot take, A vs B, "what would you do?" | **Comments** |
| Story poll / question sticker | Replies (DM leads) |
| Audiogram, lone quote card | Low reach; deprioritize |

## Psychology

**Sharing research (Berger & Milkman, 6,956 NYT articles).** Effect on the odds of an article being shared:
- Anger +34%
- Awe +30%
- Practical utility +25%
- Surprise +14%
- Sadness −16%

High-arousal emotion drives shares; low arousal suppresses them.

**Saves = utility for the saver's future self.**
- Name a problem and promise the complete answer.
- Number the items; one idea per slide.
- Make the last slide a screenshot-able recap.
- Caption cue: "Save this for your next…"

**Shares = social currency.**
- Address a specific person or type: "send this to the owner who still…".
- Humor, awe or vindication.
- Under 20 s, one idea that forwards without explanation.

**Comments = an opinion gap.** Leave the claim slightly open.

## Assets per episode or shoot (agency norm: 15–20 pieces)

| Asset | Qty |
| --- | --- |
| Vertical clips | 5–10 |
| Hot-take text-on-video | 1–3 |
| Lessons carousel (1080x1350 or 1080x1440, 7–10 slides) | 1–2 |
| LinkedIn PDF document (8–12 slides) | 1 |
| Stat card | 1–2 |
| Checklist | 1 |
| Quote cards (as a carousel) | 2–4 |
| Story set with poll (6–10 frames) | 1 |
| Covers | 2–3 |
| Trailer | 1 |

Retainers in the market run about $1.5k–$25k/month.

## Emotion and emphasis detection (moment picking)

**Commercial-license traps (don't ship these in paid work)**
- audeering arousal/valence/dominance model: CC-BY-NC-SA.
- openSMILE open-source build: no commercial product use.
- py-feat: some weights are non-commercial.

**Safe stack, all local on a Mac**

| Job | Tool | Notes |
| --- | --- | --- |
| Transcript | mlx_whisper / whispermlx | – |
| Diarization | pyannote community-1 | CC-BY-4.0; exclusive mode makes word alignment easy |
| Emotion | emotion2vec+ via FunASR | 9 classes, 50 Hz frame-level; check the weights' license |
| Laughter | jrgillick/laughter-detection (MIT) or YAMNet | A listener's laugh is the strongest cue |
| Prosody | librosa (pyin, rms) | Energy, pitch, pace vs the speaker's own baseline (`moment_map.py`, `audio_peaks.py`) |
| Face | MediaPipe Face Landmarker blendshapes (Apache 2.0) | Smiles, brows |
| Cuts | PySceneDetect | Camera changes |

**API options**
- Hume Expression Measurement (prosody, many dimensions).
- AssemblyAI or Deepgram sentiment (text-based, English only).

**Starting score, to tune against real results:**

```
score = 0.45·LLM + 0.20·arousal_z + 0.15·laughter + 0.10·(pitch_var_z + loudness_z)/2 + 0.10·face
```

**Research note (Rhapsody 2025).** Zero-shot LLMs are weak at highlight detection alone; text + audio beats text only. So: the LLM reads meaning, audio says whether it landed, and Patrik gets the final say.

**Don't cut people off.**
- Snap cuts to word boundaries plus real pauses.
- Never start on "and / so / but" unless the hook is rewritten.
- End on a falling pitch.
- Turn gaps of 150 ms or less are not a safe cut.
- Include a laugh if it starts within 1.5 s of the end.
- See `reference/boundary-audit-oak-fire.md` and `snapcut.py` for the tested rules.

**Open-source clippers, for reference**
- SamurAIGPT: LLM over the transcript with 8 virality criteria.
- ClipsAI: WhisperX + topic segmentation.
- OpusClip Virality Score: Hook, Flow, Value, Trend.

## Sources

Socialinsider Instagram/LinkedIn benchmarks; Buffer 2026 format data; Metricool 2026; Hootsuite; Influencer Marketing Hub; TechCrunch (Shorts views, Meta crackdown); YouTube Help; Sprout Social; LinkedIn Engineering (dwell time); Meta newsroom (Mar 2026); Berger & Milkman 2012; Stivers et al. 2009; Hugging Face model cards (emotion2vec, audeering, SpeechBrain, pyannote); Hume; AssemblyAI; Deepgram; WhisperX; jrgillick; YAMNet; MediaPipe; py-feat; PySceneDetect; SamurAIGPT; ClipsAI; OpusClip help.
