# Type styles: match reusable animated type

Use this technique for editable captions, numbers, and text that benefits from animation. Compare the result against the client's reference at the same size. Use the generated component directly when code reconstruction loses the intended weight or details. This reference is an implementation option; the approved design contract decides the look.

## How a GPT headline is built

The GPT headlines are a standard recipe. Each piece maps to one setting in `brand.json` under `"type_style"`.

| Piece | Setting | Ambition value |
| --- | --- | --- |
| Heavy condensed italic | `font` (bundled open-license fonts: BarlowCondensed-BlackItalic, SairaExtraCondensed-Black, BigShouldersDisplay-Black, Anton, Oswald...) | BarlowCondensed-BlackItalic |
| Extra slant | `skew` (0 to 0.2) | 0.05 |
| Squeeze or widen | `squash` (<1 narrower, >1 wider) | 1.04 |
| White fading to light gray | `fill`, `fill_bottom` | #F4F4F4 to #C9CDD4 |
| Print wear (specks, scratches) | `distress` (0 = clean, 0.35 = heavy) | 0.16 |
| Torn red banner behind the key line | `slab.color`, `slab.skew`, `slab.rough` (edge raggedness in px), `slab.wear`, `slab.pad` | #D8261F, 0.03, 3, 0.08, [30, 10] |
| Line spacing, second line a bit narrower | `line_gap`, `second_line_width` | 0.02, 0.94 |
| Red side bar + short sentence | `sentence.font`, `.size`, `.bar` | Inter-SemiBold, 40, #D8261F |

## Matching a new client (once, about 20 minutes)

1. Take 2–3 of the client's approved GPT posts.
2. Try the closest bundled fonts side by side against a GPT crop (`test/match.py` pattern: reference on the left, ours on the right, same size).
3. Tune in this order: `skew` and `squash` until letter shapes match, then `distress`, then the banner. Stop when you can't tell at phone size.
4. Save the block in `brand-kits/<client>/brand.json`, plus the comparison image as `type-match.jpg`.
5. If no bundled font is close, add an open-license one (Google Fonts via npm `@fontsource/<name>`, converted to TTF with fontTools). Never use a font the client can't legally use.

## Use

```python
from clipkit.typestyle import Headline, sentence_block
hl = Headline(brand, [{"text": "No cooling?", "slab": True}, {"text": "Fast response."}], measure=930)
hl.draw(canvas, 62, 90)                   # static (posts, carousels)
hl.draw(canvas, 62, 90, t, start=0.2)     # animated (clips)
sentence_block(canvas, brand, "Downtime costs more than repairs.", 70, 90 + hl.height + 34, 670, t, 0.75)
```

Each line is sized to fill the measure, the way GPT stacks them. The banner line can run bigger with `slab_scale`. Any line can set its own `width` (0–1).
