# Clipping design standard

Use this for every brand. The Kody [main and ending reference](../../../../corner/users/aom/projects/outreach/missions/clipping-viability/deliverables/kody-proof/figma-trial/DESIGNED-REFERENCE.md) shows the intended level of art direction, but its navy, gold, serif, desert imagery, and AR mark belong to that concept, not to every prospect.

## What each frame must do

1. **One primary read.** At each spoken beat, the viewer should know whether to read the speaker, the caption, a fact, or a visual. A headline may replace a caption's emphasis, but it should not repeat the same words in a second competing panel.
2. **Human first when a person is the story.** Keep the active face large and intact. Put a brief name/show bubble near that face; let it leave after the introduction. Restore it only when identity matters again.
3. **Captions are designed type.** Match spoken words exactly, break lines at meaningful phrases, and use a clear hierarchy with at most one colored emphasis. Do not add faint underlines or decorative rules beneath caption text. A section edge can be defined by contrast, crop, or space without drawing under the words.
4. **The supporting visual proves or explains the line.** Use the actual place, action, product, map, or sourced number when possible. Let the image connect to the caption and brand zones through crop, tone, or overlap. Do not drop an unrelated stock image into a leftover rectangle.
5. **The lower frame earns its space.** A quiet footer is fine; a large empty dark block is not. Integrate the brand into the image or give it a compact field, keeping essential identity and CTA above platform controls.

## Spacing and brand adaptation

- Start with a consistent alignment and spacing rhythm; the current 1080×1920 Figma studies use 24 px steps, 12 columns, 96 px side offsets, and 24 px gutters. Adapt those numbers to the chosen master rather than forcing them onto every composition. Optically center visible glyphs, not just text boxes.
- Establish three clear text levels: primary message, supporting identity/fact, and utility. Use the prospect's real typography or a faithful pairing; do not carry another brand's font, color, monogram, or shape into the next job.
- Use one accent with purpose. It may identify a number, a name, or an action. Repeated gold lines, pills, or shadows are decoration unless they improve reading.
- Treat image generation as art direction or slot-specific assets. Keep real footage, exact captions, names, logos, URLs, and sourced claims editable. Check generated people and places against originals before any production use.
- Test a frame at phone size with the longest real line, real names, animated states, and Instagram/TikTok overlays. A beautiful empty template or one still frame is not proof of a usable clipping design.

## Quality gate for a new brand look

Save a representative proof with an opening, ordinary caption, demanding fact or visual beat, and ending. Compare it beside the brand's real references and the chosen Figma geometry. Fix collisions, unreadable type, weak hierarchy, or off-brand imagery before saving an approved `design-lock.json`. The Kody generated concept remains a draft until Patrik chooses it and an editable, source-accurate proof passes these checks.
