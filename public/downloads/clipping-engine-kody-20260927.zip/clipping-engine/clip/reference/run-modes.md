# Prospect intake, opportunity list, and run modes

The smallest useful request is a prospect or brand plus one source video. Accept a URL, local video, folder, playlist, or several source files. An existing approved brand kit can replace fresh identity research. Do the source and brand discovery yourself; request a missing URL or access only when it is genuinely unavailable.

## First output: the opportunity list

Inspect the complete supplied source set before deciding how many clips it can support. Save `opportunities.json` and a short readable `opportunities.md`. Each candidate needs a stable ID, source file/URL, exact in/out range and source time origin, speaker, exact hook/claim, what context makes it understandable, payoff, estimated final duration, visual support, cut feasibility, and any fact or rights caveat. Give it a simple rank and explain the rank in ordinary language. Mark each as `viable`, `needs-source`, or `reject`; never pad a count with a weak fragment.

Show the viable opportunities to Patrik in the review page before or while building the pack. A candidate list is a production map, not a promise that every idea is publishable. If the source has only two clean stories, report two. If it has twenty, show the full list and say which will be made now.

## Choose the run size

| Mode | Selection | Deliverable |
|---|---|---|
| Demo | Default when the user asks for a sample or does not name a size. Choose the best **3–4** viable, distinct stories across the supplied source set. | 3–4 finished draft videos, matching covers and posting copy, or the strongest smaller count when the source cannot support four. |
| Full pass | Use when the user asks for all useful clips, a full pass, or ongoing batch production. Select every viable, non-duplicate story. | All selected videos in one coherent brand family, plus matching covers, posting copy, and a source-to-output inventory. No arbitrary fixed clip count. |

The user can request a different count. A short source may yield fewer viable clips; a large source collection can yield many. Select the run size once in `job.json` (`mode`, `requested_count`, `selected_count`), then keep an honest ledger of selected, produced, and rejected candidates.

For a new brand or a changed look, create a concrete look proof using real footage and the chosen structural layout before scaling it to the batch. If that proof passes the design and platform checks, continue the authorized demo or full pass as a **draft look**; do not interrupt the run merely to obtain an approval label. Patrik's later look decision applies to the visual family, not each individual clip. Save `design-lock.json` as approved only after his actual approval; until then the review page clearly says draft and keeps reference/source files so changes can be applied across the pack.

## Match structure to story

Choose a compatible main/ending pair from [layout-library.md](layout-library.md) and its option catalog. The format follows the footage: a face-led thought can use a large speaker field; a place or process can give evidence more room; a strong number can take a fact stage. Use controlled variations inside one prospect's brand family so the pack feels related without repeating an identical card. A novel GPT composition is an exploration until it has a Figma frame, measured geometry, a real-footage proof, and platform checks.

## Final handoff

`review.html` should show the complete opportunity list, which candidates were selected, playable videos, covers, copy, source links/credits, and the look/reference status. `job.json` records mode, sources, selected candidate IDs, stage, design lock, and artifact paths. `qa.md` names the frames and joins inspected. A full pass is complete only when every selected candidate is rendered and inspected; a demo is complete when its selected 3–4 (or honest smaller count) are rendered and inspected. Do not claim a full pass because the opportunity list was written.
