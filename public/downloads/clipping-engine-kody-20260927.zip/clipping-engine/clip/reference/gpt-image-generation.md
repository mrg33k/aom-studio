# Generate the client's kit

The agent makes the brand assets. Use the client's real logo, channel art, website or existing posts as references; preserve identity rather than inventing a replacement brand. Inspect the saved board and applied proof before requesting a generation.

## Available route

Use the current host's image generation capability when available, following its skill and tool instructions. It can use the saved reference images directly. If the user specifically asks for ChatGPT computer use, use the currently available UI tools in that client's existing conversation. Discover the current UI instead of relying on old menu names, model names, or permission workarounds.

Prefer the already authorized membership route. Do not silently switch to a paid external API or buy credits. If access is blocked, report the specific blocker and continue source, cuts, copy, and credits. Do not hand normal prompt-writing work back to Patrik. Never claim a route costs no credits based on an old session note.

## One coherent design

Create one board per new brand, then a production component or plate only where needed. A compact board can show the hook, captions, label, stat/list, speaker/name treatment, and end card in one family. Do not generate eight unrelated layouts by default. Existing accepted components should be reused. When the structure comes from Figma, supply the measured role boxes and request art for those slots as separate assets; ChatGPT should add the prospect's visual identity, not redraw the wireframe's spacing.

Give exact text, brand references, real output aspect ratio, text-safe zones, and the intended use. Ask for crisp type with the same visual weight as the reference. For overlays, request true transparency. For legacy keyed plates, specify exact flat green video, magenta visual, and cyan caption areas, with nothing drawn inside the keys. Inspect the result; do not assume the requested dimensions or transparency were honored.

A 9:16 video needs 9:16 artwork or a deliberate inspected crop. Record crop coordinates in the clip plan. Do not cut off design elements to force a board or 2:3 poster into a video.

Save the prompt, output, reference paths, and any chosen crop with the client's kit. Use a single-change edit to fix a concrete defect; keep the accepted parts. The brand board must then be shown beside a frame rendered with real footage. That comparison is the approval artifact, not the image generation alone.
