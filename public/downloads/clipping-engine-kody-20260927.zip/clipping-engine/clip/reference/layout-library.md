# Clipping layout library

Read [design-standard.md](design-standard.md) for the quality bar shared by every brand. The reusable option recipes live in [option-recipes.json](option-recipes.json); `scripts/build_layout_options.py` enumerates their compatible draft combinations. The current inventory at `corner/users/aom/projects/outreach/missions/clipping-viability/deliverables/layout-library/draft-options.json` has 110 main combinations, four ending families, and 260 compatible main/ending pairs. Those counts describe **ideas**, not 110 finished Figma templates. Select by story and footage, then promote only the strongest options through Figma geometry, real-source proof, and platform QA.

## What a template contains

A template is a composition, not a finished brand. Store the 1080×1920 geometry and layer order for named roles: speaker, speaker name, captions, supporting image or fact, headline when needed, and brand footer. Keep each role separate so a prospect's assets and copy can be replaced without remaking the arrangement. The visible design should be large and readable on a phone.

Patrik is building the master wireframes in the [`CLIPS REELZ` Figma page](https://www.figma.com/design/S8pJxyZEVhk5H3Y2GuGKbl/AOM-Kit-%25E2%2580%2594-Department-Console-v1). Four main-story frames and two editable ending frames are present. Their node IDs and measured zones are in `corner/users/aom/projects/outreach/missions/clipping-viability/deliverables/layout-library/figma-wireframes.json`; the versioning and composition rules are in `figma-engine-contract.md` beside it. Figma is the spacing source for a Figma-based variant. Read current frame properties before using stored measurements because Patrik can keep editing the file.

The earlier six-main/two-end sketches and web editor are historical seeds, not exact Figma geometry. Their raw positions and three notes are archived at `corner/users/aom/projects/outreach/missions/clipping-viability/deliverables/layout-library/patrik-raw-layout-draft-20260926.json`. The separate `patrik-aligned-candidate-v1.json` preview still has overlaps and is not an approved template. Do not copy its coordinates into a prospect render. Preserve all sources and record which specific Figma frame or historical seed a new composition follows.

## The seed families

| Seed | Composition | Name location |
|---|---|
| Main 1 | Speaker, captions, supporting scene, small brand footer | Beside the speaker's face |
| Main 2 | Speaker, captions, supporting scene, fuller brand footer | Upper edge of speaker frame |
| Main 3 | Headline, rounded supporting scene, caption, speaker | By speaker |
| Main 4 | Headline, one stage switching between speaker video and supporting graphic, captions | By speaker while visible |
| Main 5 | Supporting scene, speaker bubble, captions and supporting text | With speaker bubble |
| Main 6 | Speaker, captions, supporting scene, fuller brand footer | Upper speaker badge |
| End 1 | Portrait or logo, follow information, episode CTA | End identity stack |
| End 2 | Logo and clear follow/website CTA | No speaker required |

Patrik's pinned notes refine the structures: Main 3's supporting image needs a visible rounded top and real space beneath the headline, with the correct layer order. Main 4 uses one media stage that switches between the original speaker video and supporting graphics; a permanent diagonal split is the wrong interpretation. Main 5 needs meaningful visual icons or graphics with its supporting text, placed clear of Instagram and TikTok controls. The edited Main 3 and Main 4 name tags were moved outside the canvas during exploration; keep speaker identity near the visible face in any applied version.

Use one main family and a compatible end family for a prospect. A deliberate story beat can switch supporting imagery or put a sourced statistic in that role. Do not rotate layouts merely to make a pack look varied. Keep speaker names close to their faces, captions legible, and essential copy clear of platform controls.

For each opportunity list, shortlist two or three structurally different options with a reason tied to the actual footage and supporting evidence. Pick one visual family for the prospect's initial pack, then vary relevant support media, accent emphasis, crop, or media phase within it. Track recent approved families per brand so another source can feel fresh without breaking recognition. The library can grow from new Figma drawings and GPT explorations, but a fresh idea starts as `draft`, never as a production-ready template.

The original Figma endings were `28:66` (portrait, episode CTA, elevated footer) and `28:90` (brand mark, follow, contact link). Patrik has since edited the endings into two portrait variants, currently `28:66` and `28:103`. The old ending measurements in the manifest are historical; inspect and remeasure the current frames before rendering. Story 1 still puts its identity footer at y=1613–1920 and needs a measured safe-area revision before production use. Treat the Kody stills as a design test, not as approval of either prospect look or a finished video.

Use a 24 px baseline rhythm and 12-column guide on the 1080 px canvas, with 96 px side offsets and 24 px gutters. These guides are installed on the two current Figma endings. Use them to align edges and choose related gaps, then optically center actual glyph shapes within their text slots. A grid does not justify equal gaps everywhere: keep each identity stack tight, give the CTA a deliberate pause, and leave the platform-control area free of essential copy. Verify the result at phone size, with current prospect text; do not treat a centered placeholder as proof that a longer brand name fits.

## Measure and maintain the master

For a Figma-based version, record frame node ID, canvas, each role's x/y/width/height in canvas coordinates, parent transforms, clipping, layer order, text fit, and media phases. Figma inspector values for nested layers are parent-relative; convert them through their parents. Do not guess an unmeasured box. Check text and face movement against the Instagram/TikTok overlays as a separate constraint. If a structural overlap appears, revise or duplicate the Figma frame and export a new geometry version before changing the renderer. The web preview can expose a problem, but it is not the source of spacing truth.

## Create prospect-specific assets

For each prospect, gather real identity references, logos, colors, typography, image style, and footage before prompting ChatGPT image generation. Give it the selected Figma frame's role map, measured bounds, and exact aspect ratios, then request **separate assets** for background, supporting illustration or treatment, name badge, caption treatment, footer, and end card where needed. Ask for an authentic visual idea tied to the speaker and topic. Keep live footage, factual captions, names, logos, and URLs editable outside the generated art unless the generated text is inspected letter by letter. Do not embed another client's palette or wordmark in a structural template. Generated art may fill a role; it does not silently move that role.

Apply those assets to actual footage and show a phone-size look proof. Compare it with the prospect's real brand references and selected Figma frame. Check collisions, text fit, face crop, and platform overlays as a complete composition. Record the frame node and geometry revision, asset provenance, motion, and approved reference hashes in `design-lock.json` only after Patrik approves the new brand look.

## Grow the library without losing judgment

Record every candidate with `id`, Figma node or historical origin, geometry revision, `status` (draft, measured, tested, approved), role geometry, layer order, safe-area result, intended footage type, compatible end cards, and a link to a real-footage proof. Combine role variations only when the hierarchy remains clear: speaker placement, name treatment, caption zone, supporting visual, and footer are independent axes but not every combination is useful. Generate candidate combinations in the backend, reject collisions and unsafe type automatically, then review the survivors at phone size. GPT may propose new compositions, but make a versioned Figma frame before treating one as a reusable template. Preserve earlier versions so future reimaginings do not erase an accepted design.
