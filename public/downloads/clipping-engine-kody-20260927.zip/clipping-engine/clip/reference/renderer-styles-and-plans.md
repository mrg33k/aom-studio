# clipkit renderer: styles, clip plans, stills packs

`scripts/render.py` + `scripts/clipkit/` + `scripts/stills.py` were built 2026-09-25 in a cloud session. They sit beside Patrik's `render_clip.py`, the live-speaker renderer with the tested clash registry, rather than replacing it.

**Status**
- **Works:** end to end on test footage (10 styles, 9:16 / 4:5 / 1:1, stills pack, audio assembly).
- **Originally tested on a captioned export.** Inspect the actual source for conflicting burned graphics and use clean ranges, originals, or relevant B-roll. Re-verify each selected render.
- **Engine scope:** this document describes `render.py`/clipkit. `render_clip.py`, `render_post.py`, and `render_reel.py` have separate plate support. Use the renderer that can reproduce the approved design; do not assume their schemas are interchangeable.
- **Merge plan:** fold `render_clip.py`'s clash registry (overlays never overlap) into clipkit, or port the clipkit styles into `render_clip.py`. Don't maintain two renderers long term.

## Commands

```bash
python3 scripts/render.py --list
python3 scripts/render.py plan.json --brand brand-kits/<c>/brand.json --styles all --times 2,9,20 --out sheet.jpg   # style frames first
python3 scripts/render.py plan.json --brand ... --style listicle --aspect 4:5 --out clip.mp4
python3 scripts/stills.py pack.json --brand ... --out stills/      # carousels, quote/stat/checklist, covers, story set
python3 scripts/find_focus.py plan.json --write                    # face framing per segment (OpenCV)
python3 scripts/moment_map.py media.mp4 words.json --out moment_map [--emotion]
```

## Styles (clipkit/styles.py)

| Style | Family | Aspects |
| --- | --- | --- |
| bold-pop | Full-bleed face, word-pop captions, zoom punches | 9:16, 4:5 |
| podcast-cut | Active-speaker cuts + payoff banner; `question` = street Q&A card | 9:16, 4:5 |
| split-stack | Two stacked panes, seam captions (one speaker: wide + tight) | 9:16 |
| letterbox | 16:9 on the brand field + persistent headline + progress bar | 9:16, 4:5, 1:1 |
| post-card | Platform-neutral post card over the clip | 9:16, 4:5 |
| newsroom | Chip + headline + lower third + citation | 9:16, 4:5 |
| listicle | Numbered build over a brand panel, speaker below | 9:16, 4:5 |
| linkedin-minimal | Header bar + subtitle bar | 4:5, 9:16, 1:1 |
| signature | Brand field, story card, face bubbles (Oak Street look) | 9:16 |
| screen-top | Content on top, speaker below | 9:16, 4:5 |

**Beats that work in any style:** `stat` (count-up takeover), `before_after` (wipe), `list_takeover`, `broll` (image or video insert with Ken Burns). `list` feeds the listicle.

## Clip plan (plan.json)

```json
{
  "transcript": "words.json",
  "sources": {"a": {"path": "cam_a.mp4", "offset": 0}},
  "speakers": {"tim": {"name": "Tim Fergestad", "title": "Oak Street Assets", "focus": [0.5, 0.4], "side": "right"}},
  "segments": [{"in": 139.36, "out": 142.84, "src": "a", "speaker": "tim"}],
  "hook": "...", "headline": "...", "banner": "...", "category": "...", "post": "...", "question": "...",
  "emphasis": ["words", "to", "punch"], "highlight": ["headline", "words", "in", "accent"],
  "beats": [{"type": "stat", "t": 3.2, "value": 1000000, "prefix": "$", "label": "...", "dur": 2.6},
            {"type": "list", "title": "...", "items": ["..."], "cues": [13.9, 15.2]},
            {"type": "broll", "src": "photo.jpg", "t": 6.0, "dur": 2.5},
            {"type": "before_after", "before": "a.jpg", "after": "b.jpg", "t": 10, "dur": 3.2}],
  "end_card": true
}
```

- Segment times are in transcript time; `offset` maps each source file onto it.
- Beat times are in output time.
- Paths are relative to the plan.

## Brand file additions used by clipkit

- `roles`: bg, surface, accent, accent2, text, ink, paper, muted, bar, caption_text.
- `type`: display, headline, caption, body, number, cta.
- `style`: energy (calm / standard / punchy), radius, texture (contours / grain / halftone / none), caption_case, headline_case, grade.
- `assets`: logo, reference_board.
- `type_style`: see `type-style.md`.
- Fonts resolve from `fonts/` first, then the system font folders.
- The template is in `brand-kits/_template/brand.json`.
