# Clipping engine handoff

This archive contains the current `clip` skill core, the design standard and option recipes, the draft layout inventory, Kody design references, and the actual Kody review clip.

## Start here

- `clip/SKILL.md`: entry point. Give it a prospect or brand plus one or more source videos. It produces a ranked opportunity list and either a 3–4 video demo or a full pass of viable stories.
- `clip/reference/design-standard.md`: the visual quality standard, including Patrik's correction to avoid faint caption underlines.
- `clip/reference/layout-library.md` and `clip/reference/option-recipes.json`: how reusable structures vary without copying a prospect's identity. `library/draft-options.json` lists 110 **draft** main combinations and four ending families. These are options to test, not finished templates.
- `references/kody-designed-main-v2.jpg` and `references/kody-designed-ending.jpg`: the art-direction pair. Their matching Instagram images show the platform-control check. The generated frames are visual targets; use real footage and editable text in production.
- `video/kody-current-review-clip.mp4`: the existing 30-second, 1080×1920 Kody clip. It predates the newly designed reference and has not been re-edited to match it.

The portable skill excludes `brand-kits/`, so another client's saved assets are not bundled. It includes the skill's instructions, scripts, fonts, and general references. `library/ENGINE-OVERVIEW.md` explains what is operational now and what still needs a real prospect pilot.
