# Clipping engine, R20

## 1. Shared design standard

The canonical cross-brand standard is `.claude/skills/clip/reference/design-standard.md`. It governs hierarchy, captions, faces/name bubbles, supporting visuals, lower-frame use, typography, platform controls, and real-source proof. Patrik's correction is explicit: no faint decorative underlines beneath captions. The Kody R19/R20 reference demonstrates craft and layout integration, while its palette and monogram remain brand-specific draft art.

## 2. Option library

`catalog.json` indexes the historical wireframes and the current Figma source. `.claude/skills/clip/reference/option-recipes.json` defines eight main composition families, four ending families, and compatible role treatments. `draft-options.json` currently enumerates **110 draft main combinations and 260 compatible main/ending pairs**. These are searchable candidate structures, not 110 designed or approved frames. A candidate becomes reusable geometry only after it is drawn in Figma, measured, tested against real footage and platform controls, and reviewed at phone size. The library can keep adding new families without copying another prospect's brand.

## 3. Brand and source run

The `clip` skill now accepts a brand/prospect plus one or many video sources. It first creates a full opportunity list with exact source ranges, claims, context, visual needs, and viability. A demo selects the best 3–4 distinct viable clips; a full pass selects every viable non-duplicate clip. The run then adapts one coherent design family to the actual brand, produces videos/covers/copy, and packages the results with credits and QA. A new look remains draft until Patrik approves it, but the authorized demo or full pass continues without a routine approval stop.

## Current boundary

This round makes the skill and option inventory operational as instructions and searchable metadata. It does **not** make all 110 variants into Figma frames or demonstrate a completed brand-to-video full pass. The next production pilot should run the updated skill on a fresh prospect with a real source, inspect its opportunity list, and test whether the chosen layout survives actual footage and captions.
